extends Control
signal debug_pressed(id: int)
signal action_pressed
# Touch controls: left side = floating joystick, right side drag = camera, round button = jump.

var move_vec: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var jump_pressed: bool = false
var run_held: bool = false
var jump_held: bool = false
var action_label: String = ""    # "" = action button hidden
var vehicle_mode: bool = false   # true while driving: joystick is replaced by arrow buttons (set by main.gd)
var zoom_dir: float = 0.0        # -1 = camera closer (hold "-"), +1 = camera further (hold "+")

const JOY_RADIUS: float = 95.0
const JUMP_RADIUS: float = 64.0
const ACTION_RADIUS: float = 56.0
const ZOOM_RADIUS: float = 38.0
const ARROW_RADIUS: float = 58.0

var _joy_id: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _look_id: int = -1
var _jump_id: int = -1
var _action_id: int = -1
var _zoom_id: int = -1
var _arrow_ids := PackedInt32Array([-1, -1, -1, -1])      # left, right, gas, brake/reverse
var _arrow_held := [false, false, false, false]
var _steer_axis: float = 0.0
var _prev_vehicle_mode: bool = false
var debug_labels: Array = ["Clear", "Cloudy", "Rain", "Post", "+3h"]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size
	if vehicle_mode != _prev_vehicle_mode:          # switching between walking and driving: drop every held control
		_prev_vehicle_mode = vehicle_mode
		_joy_id = -1
		run_held = false
		_steer_axis = 0.0
		move_vec = Vector2.ZERO
		for i in range(4):
			_arrow_ids[i] = -1
			_arrow_held[i] = false
	if vehicle_mode:
		var target: float = (1.0 if _arrow_held[1] else 0.0) - (1.0 if _arrow_held[0] else 0.0)
		_steer_axis = move_toward(_steer_axis, target, (5.0 if target != 0.0 else 8.0) * delta)   # smooth steering
		move_vec = Vector2(_steer_axis, (1.0 if _arrow_held[3] else 0.0) - (1.0 if _arrow_held[2] else 0.0))
	queue_redraw()

func _debug_rect(i: int) -> Rect2:
	var w: float = 96.0
	var gap: float = 8.0
	var total: float = float(debug_labels.size()) * w + float(debug_labels.size() - 1) * gap
	return Rect2(size.x - total - 16.0 + float(i) * (w + gap), 52.0, w, 44.0)

func _action_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 275.0)

func _jump_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 130.0)

func _zoom_center(sign_dir: float) -> Vector2:
	# "-" (closer) left, "+" (further) right, below the weather buttons
	return Vector2(size.x - 130.0 + sign_dir * 60.0, 175.0)

func _arrow_center(i: int) -> Vector2:
	match i:
		0: return Vector2(150.0, size.y - 110.0)             # steer left
		1: return Vector2(330.0, size.y - 110.0)             # steer right
		2: return Vector2(size.x - 300.0, size.y - 235.0)    # gas
		_: return Vector2(size.x - 300.0, size.y - 95.0)     # brake / reverse
	return Vector2.ZERO

func _idle_joy_center() -> Vector2:
	return Vector2(170.0, size.y - 160.0)

func _arrow_hit(t: InputEventScreenTouch) -> bool:
	for i in range(4):
		if _arrow_ids[i] == -1 and t.position.distance_to(_arrow_center(i)) < ARROW_RADIUS * 1.25:
			_arrow_ids[i] = t.index
			_arrow_held[i] = true
			return true
	return false

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed:
			var hit_debug: bool = false
			for i in range(debug_labels.size()):
				if _debug_rect(i).has_point(t.position):
					debug_pressed.emit(i)
					hit_debug = true
			if hit_debug:
				pass
			elif _zoom_id == -1 and t.position.distance_to(_zoom_center(-1.0)) < ZOOM_RADIUS * 1.3:
				_zoom_id = t.index
				zoom_dir = -1.0
			elif _zoom_id == -1 and t.position.distance_to(_zoom_center(1.0)) < ZOOM_RADIUS * 1.3:
				_zoom_id = t.index
				zoom_dir = 1.0
			elif vehicle_mode and _arrow_hit(t):
				pass
			elif action_label != "" and _action_id == -1 and t.position.distance_to(_action_center()) < ACTION_RADIUS * 1.3:
				_action_id = t.index
				action_pressed.emit()
			elif _jump_id == -1 and t.position.distance_to(_jump_center()) < JUMP_RADIUS * 1.4:
				_jump_id = t.index
				jump_pressed = true
				jump_held = true
			elif not vehicle_mode and _joy_id == -1 and t.position.x < size.x * 0.42 and t.position.y > size.y * 0.25:
				_joy_id = t.index
				_joy_origin = t.position
				_joy_pos = t.position
				move_vec = Vector2.ZERO
				run_held = false
			elif _look_id == -1 and (vehicle_mode or t.position.x >= size.x * 0.42):
				_look_id = t.index
		else:
			if t.index == _joy_id:
				_joy_id = -1
				move_vec = Vector2.ZERO
				run_held = false
			elif t.index == _look_id:
				_look_id = -1
			elif t.index == _jump_id:
				_jump_id = -1
				jump_held = false
			elif t.index == _action_id:
				_action_id = -1
			elif t.index == _zoom_id:
				_zoom_id = -1
				zoom_dir = 0.0
			else:
				for i in range(4):
					if t.index == _arrow_ids[i]:
						_arrow_ids[i] = -1
						_arrow_held[i] = false
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if d.index == _joy_id:
			_joy_pos = d.position
			var delta_v: Vector2 = (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
			move_vec = delta_v / JOY_RADIUS
			# Sprint is activated only by pushing the movement joystick almost fully forward.
			run_held = move_vec.y <= -0.88 and move_vec.length() >= 0.88
		elif d.index == _look_id:
			look_delta += d.relative

func _draw() -> void:
	var base_c: Vector2 = _idle_joy_center()
	var knob_c: Vector2 = base_c
	var alpha: float = 0.25
	if _joy_id != -1:
		base_c = _joy_origin
		knob_c = _joy_origin + (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
		alpha = 0.5
	if not vehicle_mode:
		draw_circle(base_c, JOY_RADIUS, Color(1, 1, 1, alpha * 0.45))
		draw_arc(base_c, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, alpha + 0.2), 3.0)
		draw_circle(knob_c, 38.0, Color(1, 1, 1, alpha + 0.2))
	else:
		for i in range(4):
			var ac2: Vector2 = _arrow_center(i)
			var held: bool = _arrow_held[i]
			var col: Color = Color(1, 1, 1, 0.6 if held else 0.3)
			if i == 2:
				col = Color(0.5, 1.0, 0.5, 0.65 if held else 0.35)
			elif i == 3:
				col = Color(1.0, 0.55, 0.45, 0.65 if held else 0.35)
			draw_circle(ac2, ARROW_RADIUS, Color(col.r, col.g, col.b, col.a * 0.55))
			draw_arc(ac2, ARROW_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.85), 3.0)
			var dirs: Array = [Vector2(-1, 0), Vector2(1, 0), Vector2(0, -1), Vector2(0, 1)]
			var d: Vector2 = dirs[i]
			var p: Vector2 = Vector2(-d.y, d.x)
			var tri := PackedVector2Array([ac2 + d * 26.0, ac2 - d * 18.0 + p * 24.0, ac2 - d * 18.0 - p * 24.0])
			draw_colored_polygon(tri, Color(1, 1, 1, 0.95))
	var jc: Vector2 = _jump_center()
	var ja: float = 0.55 if _jump_id != -1 else 0.3
	draw_circle(jc, JUMP_RADIUS, Color(1, 1, 1, ja * 0.6))
	draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ja + 0.25), 3.0)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, jc + Vector2(-JUMP_RADIUS, 9.0), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 26, Color(1, 1, 1, 0.95))

	if action_label != "":
		var ac: Vector2 = _action_center()
		draw_circle(ac, ACTION_RADIUS, Color(1.0, 0.85, 0.3, 0.45))
		draw_arc(ac, ACTION_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.9), 3.0)
		draw_string(font, ac + Vector2(-ACTION_RADIUS, 8.0), action_label, HORIZONTAL_ALIGNMENT_CENTER, ACTION_RADIUS * 2.0, 22, Color(1, 1, 1, 1))

	for sd in [-1.0, 1.0]:
		var zc: Vector2 = _zoom_center(sd)
		var za: float = 0.55 if (_zoom_id != -1 and zoom_dir == sd) else 0.3
		draw_circle(zc, ZOOM_RADIUS, Color(0, 0, 0, za))
		draw_arc(zc, ZOOM_RADIUS, 0.0, TAU, 40, Color(1, 1, 1, 0.8), 3.0)
		draw_string(font, zc + Vector2(-ZOOM_RADIUS, 14.0), "+" if sd > 0.0 else "-", HORIZONTAL_ALIGNMENT_CENTER, ZOOM_RADIUS * 2.0, 40, Color(1, 1, 1, 0.95))
	for i in range(debug_labels.size()):
		var r: Rect2 = _debug_rect(i)
		draw_rect(r, Color(0, 0, 0, 0.45), true)
		draw_rect(r, Color(1, 1, 1, 0.5), false, 2.0)
		draw_string(font, r.position + Vector2(0.0, 29.0), str(debug_labels[i]), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 22, Color(1, 1, 1, 0.95))
