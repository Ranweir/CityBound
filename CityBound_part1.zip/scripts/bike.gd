extends CharacterBody3D
# GTA SA NRG-500 (BMW S1000RR livery) - arcade motorbike on the heightfield terrain.
#  * two-wheel spring/damper suspension (heave + pitch), the body leans into corners (lean angle from lateral acceleration)
#  * the front fork steers around the real rake axis, both wheels spin
#  * joystick up/down = throttle / brake-reverse, left/right = steer, JUMP button = brake
# Full quality model: ~30k triangles, original textures (see tools/convert_bike.py).

const BikeMeta = preload("res://scripts/bike_meta.gd")

@export var max_speed: float = 42.0         # m/s (~151 km/h)
@export var reverse_speed: float = 2.5
@export var accel: float = 17.0
@export var brake_decel: float = 28.0
@export var coast_decel: float = 2.5
@export var max_steer_low: float = 0.5      # rad of fork angle at standstill
@export var max_lat_acc: float = 10.5       # m/s^2 cornering limit -> steering gets finer with speed
@export var gravity: float = 22.0
@export var lean_gravity: float = 9.8       # lean angle = atan(lateral acc / lean_gravity)
@export var max_lean: float = 0.85          # rad (~49 deg)
@export var spring_damping: float = 7.0     # per wheel
@export var susp_ext_rest: float = 0.12     # suspension extension when parked (m)
@export var susp_ext_max: float = 0.26      # full droop (m)
@export var paint_gloss: bool = true
@export var enter_range: float = 4.5        # how close the player must be to get on

const BUMP_K: float = 500.0
const INERTIA_PITCH: float = 0.8
const SELF_LAYER: int = 1 << 19

var world = null              # map_builder.gd instance (set by main.gd) - used for terrain height
var ui = null                 # touch_ui.gd instance (set by main.gd)
var driven: bool = false
var heading: float = 0.0      # yaw (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0    # fork angle, + = turn left
var grip: float = 1.0         # surface grip 0.15..1 (set by main.gd from the terrain under the bike)
var lean: float = 0.0         # body roll, + = leaning left
var water_pitch: float = 0.0  # extra body tilt while wading (set by main.gd)
var water_roll: float = 0.0
var pitch: float = 0.0        # + = nose up
var pitch_vel: float = 0.0
var ride_y: float = 0.0
var vy: float = 0.0
var ext := PackedFloat32Array([0.12, 0.12])    # suspension extension: [front, rear]
var prev_speed: float = 0.0
var long_acc: float = 0.0
var wheel_spin: float = 0.0
var wheelspin_rate: float = 0.0
var mud_amount: float = 0.0
var mud_splats: Array[MeshInstance3D] = []

var visual: Node3D = null
var fork_pivot: Node3D = null
var front_wheel: Node3D = null      # moves along the fork when the suspension works
var front_spinner: Node3D = null
var rear_spinner: Node3D = null
var rake_axis: Vector3 = Vector3.UP
var front_rest: Vector3 = Vector3.ZERO

func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	collision_mask = 2            # props / boundary only; the terrain is handled by the wheels
	heading = rotation.y
	ride_y = global_position.y
	ext[0] = susp_ext_rest
	ext[1] = susp_ext_rest
	_build_collision()
	_build_visual()

func _ground(x: float, z: float) -> float:
	if world != null:
		return world.get_height(x, z)
	return 0.0

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# narrow hull (the visual leans, the collision stays upright)
	var pts := PackedVector3Array([
		Vector3(-0.22, 0.30, -1.12), Vector3(0.22, 0.30, -1.12), Vector3(-0.22, 0.30, 1.12), Vector3(0.22, 0.30, 1.12),
		Vector3(-0.30, 0.80, -0.80), Vector3(0.30, 0.80, -0.80), Vector3(-0.30, 0.80, 0.95), Vector3(0.30, 0.80, 0.95),
		Vector3(-0.20, 1.15, -0.45), Vector3(0.20, 1.15, -0.45), Vector3(-0.20, 1.15, 0.60), Vector3(0.20, 1.15, 0.60),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _find_mesh(root: Node, mesh_name: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name) == mesh_name:
			return (c as MeshInstance3D).mesh
	return null

func _mesh_node(mesh: Mesh, node_name: String, parent: Node3D) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = mesh
	mi.layers = SELF_LAYER
	parent.add_child(mi)
	return mi

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/bike/nrg500.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var fork_mesh: Mesh = _find_mesh(inst, "Fork")
	var wf_mesh: Mesh = _find_mesh(inst, "WheelF")
	var wr_mesh: Mesh = _find_mesh(inst, "WheelR")
	inst.free()
	if body_mesh == null or fork_mesh == null or wf_mesh == null or wr_mesh == null:
		push_error("nrg500.glb: Body / Fork / WheelF / WheelR mesh not found")
		return
	for m in [body_mesh, fork_mesh, wf_mesh, wr_mesh]:
		_style_mesh(m)

	_mesh_node(body_mesh, "Body", visual)

	# front end: fork + handlebar + mudguard rotate around the steering axis (pivot -> front wheel centre)
	rake_axis = (BikeMeta.FORK_PIVOT - BikeMeta.WHEEL_F).normalized()
	fork_pivot = Node3D.new()
	fork_pivot.name = "ForkPivot"
	fork_pivot.position = BikeMeta.FORK_PIVOT
	visual.add_child(fork_pivot)
	_mesh_node(fork_mesh, "Fork", fork_pivot)
	front_wheel = Node3D.new()
	front_wheel.name = "FrontWheel"
	front_rest = BikeMeta.WHEEL_F - BikeMeta.FORK_PIVOT
	front_wheel.position = front_rest
	fork_pivot.add_child(front_wheel)
	front_spinner = Node3D.new()
	front_wheel.add_child(front_spinner)
	_mesh_node(wf_mesh, "WheelF", front_spinner)

	var rear := Node3D.new()
	rear.name = "RearWheel"
	rear.position = BikeMeta.WHEEL_R
	visual.add_child(rear)
	rear_spinner = Node3D.new()
	rear.add_child(rear_spinner)
	_mesh_node(wr_mesh, "WheelR", rear_spinner)
	# Small brown mud clods on the lower fairing; their visibility follows accumulated mud.
	var mud_mat := StandardMaterial3D.new()
	mud_mat.albedo_color = Color(0.20, 0.105, 0.045, 0.88)
	mud_mat.roughness = 1.0
	for spot in [Vector3(-0.24, 0.42, -0.34), Vector3(0.23, 0.48, -0.18), Vector3(-0.19, 0.28, 0.38), Vector3(0.20, 0.30, 0.42), Vector3(0.0, 0.55, 0.22)]:
		var blob := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.075
		sphere.height = 0.12
		blob.mesh = sphere
		blob.material_override = mud_mat
		blob.position = spot
		blob.scale = Vector3(1.0, 0.55, 1.25)
		blob.visible = false
		visual.add_child(blob)
		mud_splats.append(blob)

func _style_mesh(mesh: Mesh) -> void:
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		match m.resource_name:
			"remap", "cbe7aed0":                 # livery: glossy clear-coated paint
				m.metallic = 0.40
				m.roughness = 0.10
				m.metallic_specular = 1.0
				if paint_gloss:
					m.clearcoat_enabled = true
					m.clearcoat = 1.0
					m.clearcoat_roughness = 0.0
					m.rim_enabled = true
					m.rim = 0.3
					m.rim_tint = 0.5
			"56a89c22", "423471ca":              # engine / frame / metal parts
				m.metallic = 0.7
				m.roughness = 0.28
			"84041073":                          # tyre + rim
				m.metallic = 0.0
				m.roughness = 0.75
				m.metallic_specular = 0.2
			"de2f4ea2":                          # brake disc / sprocket
				m.metallic = 0.85
				m.roughness = 0.3
			"lob_steklo":                        # windscreen
				m.roughness = 0.0
				m.metallic = 0.5
				m.metallic_specular = 1.0
				m.cull_mode = BaseMaterial3D.CULL_DISABLED

func _read_input() -> Vector3:
	# returns (throttle, steer, brake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var br: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			br = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		br = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), br)

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var throttle: float = inp.x
	var braking: bool = inp.z > 0.5

	# ---- speed
	var brake_cap: float = minf(brake_decel, clampf(grip, 0.15, 1.0) * 30.0)      # loose ground = longer braking
	if braking:
		speed = move_toward(speed, 0.0, brake_cap * delta)
	elif throttle > 0.05:
		if speed < -0.5:
			speed += brake_cap * delta
		else:
			var ratio: float = clampf(speed / max_speed, 0.0, 1.0)
			# Low-grip mud spins the driven rear tyre; only the grip-limited share moves the bike.
			var grip_now: float = clampf(grip, 0.12, 1.0)
			var drive_efficiency: float = lerpf(0.62, 1.0, smoothstep(0.10, 0.82, grip_now))
			# Rear-wheel drive: low grip makes the powered rear tyre spin rapidly while the chassis still creeps forward.
			var spin_target: float = throttle * (1.0 - grip_now) * (16.0 + absf(speed) * 1.15)
			wheelspin_rate = lerpf(wheelspin_rate, spin_target, 1.0 - exp(-12.0 * delta))
			speed += accel * throttle * drive_efficiency * (1.0 - ratio * ratio) * delta + 0.4 * delta * drive_efficiency
	elif throttle < -0.05:
		if speed > 0.5:
			speed -= brake_cap * (-throttle) * delta
		else:
			speed -= accel * 0.4 * (-throttle) * delta
	else:
		speed = move_toward(speed, 0.0, coast_decel * delta)
		wheelspin_rate = move_toward(wheelspin_rate, 0.0, 8.0 * delta)

	# ---- terrain slope: gravity along the hill, cliffs block the way
	var fwd: Vector3 = forward_vector()
	var pos: Vector3 = global_position
	var half: float = BikeMeta.WHEELBASE * 0.5 + 0.2
	var gc: float = _ground(pos.x, pos.z)
	var f_pt: Vector3 = pos + fwd * half
	var r_pt: Vector3 = pos - fwd * half
	var slope_body: float = (_ground(f_pt.x, f_pt.z) - _ground(r_pt.x, r_pt.z)) / (2.0 * half)     # + = nose up
	if absf(speed) > 0.8 or absf(throttle) > 0.05:
		speed -= gravity * 0.4 * slope_body / sqrt(1.0 + slope_body * slope_body) * delta
	var dirn: float = 1.0 if speed >= 0.0 else -1.0
	var lead: Vector3 = pos + fwd * dirn * 2.0
	if (_ground(lead.x, lead.z) - gc) / 2.0 > 1.2:                    # steeper than ~50 deg ahead
		speed = move_toward(speed, 0.0, 70.0 * delta)
	speed = clampf(speed, -reverse_speed, max_speed)

	# ---- steering: the fork angle gets smaller with speed so the lateral acceleration stays inside the grip limit
	var v2: float = maxf(speed * speed, 1.0)
	var lat_limit: float = max_lat_acc * clampf(grip, 0.25, 1.0)      # less cornering grip on mud / wet ground
	var steer_limit: float = minf(max_steer_low, atan(lat_limit * BikeMeta.WHEELBASE / v2))
	var steer_target: float = -inp.y * steer_limit      # positive angle = turn left
	steer_now = move_toward(steer_now, steer_target, 3.2 * delta)
	heading += speed / BikeMeta.WHEELBASE * tan(steer_now) * delta
	rotation.y = heading
	fwd = forward_vector()

	# ---- horizontal movement only (props / boundary collide, height comes from the suspension)
	var cs: float = 1.0 / sqrt(1.0 + slope_body * slope_body)
	velocity = Vector3(fwd.x * speed * cs, 0.0, fwd.z * speed * cs)
	global_position.y = ride_y
	move_and_slide()
	global_position.y = ride_y
	var hv: float = velocity.x * fwd.x + velocity.z * fwd.z
	speed = hv / maxf(cs, 0.3)

	# ---- lean into the corner
	var lat_acc: float = speed * speed * tan(steer_now) / BikeMeta.WHEELBASE   # + = turning left
	var lean_target: float = clampf(atan(lat_acc / lean_gravity), -max_lean, max_lean)
	lean = lerpf(lean, lean_target, 1.0 - exp(-7.0 * delta))

	# ---- pitch from acceleration / braking
	var la_raw: float = clampf((speed - prev_speed) / maxf(delta, 0.0001), -30.0, 30.0)
	long_acc = lerpf(long_acc, la_raw, 0.15)
	prev_speed = speed
	_suspension(delta, long_acc * 0.5)

	_update_visual(delta)

# 2 springs (front + rear wheel): terrain sampled in 3 spots per wheel, bump / rebound damping, progressive bump stop.
func _suspension(delta: float, pitch_torque: float) -> void:
	var body_basis: Basis = Basis(Vector3.UP, heading) * Basis(Vector3.RIGHT, pitch)
	var pos: Vector3 = global_position
	var k: float = gravity / (2.0 * maxf(susp_ext_max - susp_ext_rest, 0.05))   # static load = gravity
	var c_bump: float = spring_damping * 0.8
	var c_reb: float = spring_damping * 1.5
	var fw: Vector3 = Vector3(-sin(heading), 0.0, -cos(heading))
	var fsum: float = 0.0
	var tp: float = pitch_torque
	var contacts: int = 0
	var wheels: Array = [BikeMeta.WHEEL_F, BikeMeta.WHEEL_R]
	var radii: Array = [BikeMeta.RADIUS_F, BikeMeta.RADIUS_R]
	for i in range(2):
		var w: Vector3 = wheels[i]
		var a: Vector3 = pos + body_basis * Vector3(w.x, w.y + susp_ext_rest, w.z)
		var g0: float = _ground(a.x, a.z)
		var gf: float = _ground(a.x + fw.x * 0.25, a.z + fw.z * 0.25)
		var gb: float = _ground(a.x - fw.x * 0.25, a.z - fw.z * 0.25)
		var g: float = maxf(g0, 0.5 * (gf + gb))                  # tyre envelope
		var raw: float = a.y - float(radii[i]) - g
		var e: float = clampf(raw, 0.0, susp_ext_max)
		var rate: float = clampf((e - ext[i]) / maxf(delta, 0.0001), -12.0, 12.0)
		var f: float = 0.0
		if raw < susp_ext_max:
			contacts += 1
			var c: float = c_reb if rate > 0.0 else c_bump
			f = maxf(k * (susp_ext_max - e) - c * rate, 0.0)
			var stop: float = maxf(0.04 - e, 0.0) / 0.04          # progressive bump stop in the last 4 cm
			f += stop * stop * 40.0
			if raw < 0.0:
				f += BUMP_K * (-raw) - 25.0 * minf(vy, 0.0)
		ext[i] = e
		fsum += f
		tp += -w.z * f
	vy += (fsum - gravity) * delta
	pitch_vel += tp / INERTIA_PITCH * delta
	pitch_vel *= exp(-(0.6 if contacts == 0 else 1.6) * delta)
	pitch += pitch_vel * delta
	if absf(pitch) > 1.0:
		pitch = clampf(pitch, -1.0, 1.0)
		pitch_vel = 0.0
	ride_y += vy * delta
	var gc: float = _ground(pos.x, pos.z)
	if ride_y < gc - 0.6:                                        # never fall through the map
		ride_y = gc + 0.2
		vy = 0.0
	global_position.y = ride_y

func _update_visual(delta: float) -> void:
	if visual == null:
		return
	# lean + pitch both pivot on the ground line between the wheels
	visual.basis = Basis(Vector3.RIGHT, pitch + water_pitch) * Basis(Vector3.BACK, lean + water_roll)
	wheel_spin = wrapf(wheel_spin - (speed / BikeMeta.RADIUS_R + wheelspin_rate) * delta, -TAU, TAU)
	rear_spinner.rotation.x = wheel_spin
	front_spinner.rotation.x = wrapf(-(speed / BikeMeta.RADIUS_F) * delta + front_spinner.rotation.x, -TAU, TAU)
	for i in range(mud_splats.size()):
		mud_splats[i].visible = mud_amount > (0.12 + float(i) * 0.12)
	fork_pivot.basis = Basis(rake_axis, steer_now)
	# suspension travel: the front wheel slides along the fork, the rear wheel moves vertically
	var dy_f: float = susp_ext_rest - ext[0]
	front_wheel.position = front_rest + rake_axis * (dy_f / maxf(rake_axis.y, 0.3))
	rear_spinner.get_parent().position.y = BikeMeta.WHEEL_R.y + susp_ext_rest - ext[1]
