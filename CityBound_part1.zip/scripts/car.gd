extends CharacterBody3D
# Ford F-150 Raptor - driving model v3
#  * tyres: Pacejka-style lateral force with slip-angle relaxation (tyres need a moment to build / lose grip),
#    load transfer (braking loads the nose, throttle loads the tail, lift-off in a corner lets the tail swing),
#    friction circle (throttle / brakes eat cornering grip), rear-biased 4x4 drive, handbrake locks the rear.
#  * driver aids like GTA: countersteer assist + stability assist (catch a slide, no endless spinning).
#  * suspension: 4 corners, spring rate follows the load of each corner, bump / rebound damping as damping ratios,
#    progressive spring, anti-roll bars, pitch / roll torque from the tyre forces (dive, squat, body roll).
#  * tyre smoke / dust and skid marks while the tyres slide.
# Joystick up/down = throttle/brake-reverse, left/right = steer, JUMP button = handbrake.

const CarMeta = preload("res://scripts/car_meta.gd")

@export var max_speed: float = 34.0         # m/s (~122 km/h)
@export var reverse_speed: float = 8.0
@export var accel: float = 9.5              # engine pull (m/s^2) at low speed; tyres limit it on loose ground
@export var brake_decel: float = 15.0       # brake demand (m/s^2); the tyres limit it to ~1 g
@export var coast_decel: float = 2.5
@export var max_steer_low: float = 0.60     # rad of front-wheel angle at standstill
@export var max_steer_high: float = 0.14    # rad at top speed
@export var gravity: float = 22.0           # suspension / jump gravity (arcade scale). Tyres use real 9.81
@export var full_quality: bool = true                         # false = lighter model (~42k triangles)
@export var paint_color: Color = Color(0.88, 0.89, 0.92)      # body colour

const GLASS_MATS := ["pered_steklo", "lob_steklo", "zad_steklo", "LensFront", "fara_pered", "fara_zad"]
const SELF_LAYER: int = 1 << 19     # car meshes live on layer 20 so the reflection probe does not capture the car itself
const G_REAL: float = 9.81
const SKID_POOL: int = 72
const SKID_SPACING: float = 0.48

@export var use_reflection_probe: bool = false     # live reflections cost a lot on phones; sky reflections stay on
@export var enable_fx: bool = true                 # tyre smoke / dust + skid marks

# ---- handling (tyre model)
@export var grip_accel: float = 9.0                # tyre grip at mu = 1 (m/s^2, ~0.92 g). Total cornering is a bit higher (rear bias)
@export var cg_front_ratio: float = 0.46           # CG distance from front axle / wheelbase (<0.5 = front-heavy pickup)
@export var cg_height: float = 0.8                 # m, drives weight transfer under braking / acceleration
@export var yaw_inertia: float = 3.0               # m^2 (mass = 1); higher = lazier rotation
@export var tire_stiff: float = 11.0               # cornering stiffness; higher = snappier, less forgiving
@export var tire_relax: float = 0.9                # m, tyre relaxation length: grip builds up over this distance (smoother, less twitchy)
@export var rear_grip_bias: float = 1.3            # rear grip vs front: >1 = stable (understeer), ~1 = neutral, <1 = tail-happy
@export var handbrake_rear_grip: float = 0.38      # rear grip left while the handbrake is held
@export var handbrake_decel: float = 4.0           # rear brakes only: sliding keeps its speed
@export var drive_grip_gain: float = 1.25          # how much more than grip_accel the drivetrain can put down (4x4: all four tyres pull)
@export var drive_circle: float = 0.6            # how much of the driving force counts against cornering grip (1 = full simulation, lower = easier to steer on throttle)
@export var rear_drive_share: float = 0.5          # 4x4: base torque split to the rear axle (0.5 = 50 / 50, the rest goes to the front)
@export var awd_adaptive: float = 0.6              # centre-diff behaviour: 0 = fixed split, 1 = torque follows the axle that has more grip (mud, water, slopes)
@export var steer_overshoot: float = 1.25          # steering lock at speed = the angle the tyres can use x this (>1 allows understeer slides)
@export var countersteer_assist: float = 0.7       # 0 = none, 1 = strong: wheels turn into the slide automatically
@export var stability_assist: float = 1.5          # 0 = none: pulls the nose back to the direction of travel (stops endless spins)

# ---- suspension
@export var susp_ext_rest: float = 0.25            # suspension extension when parked (m)
@export var susp_ext_max: float = 0.50             # full droop (m)
@export var damping_bump: float = 0.45             # damping ratio while compressing (soft: swallows bumps)
@export var damping_rebound: float = 0.85          # damping ratio while extending (firm: stops the body bouncing)
@export var spring_progressive: float = 3.0        # springs get stiffer deep in the travel (big hits do not bottom out)
@export var arb_front: float = 7.0                 # anti-roll bar stiffness (force per m of left/right compression difference)
@export var arb_rear: float = 4.0
@export var body_motion: float = 1.15               # exaggeration of dive / squat / roll (1 = physically exact, 2-3 = GTA look)
@export var roll_arm: float = 0.6                  # m, CG height above the roll centre

const BUMP_K: float = 500.0                        # bump-stop stiffness
const INERTIA_PITCH: float = 3.0
const INERTIA_ROLL: float = 0.8

var world = null              # map_builder.gd instance (set by main.gd) - used for terrain height
var probe: ReflectionProbe = null
var probe_timer: float = 0.0
var ride_y: float = 0.0       # body height (world Y of the body origin)
var vy: float = 0.0
var pitch: float = 0.0        # + = nose up
var roll: float = 0.0         # + = right side up
var pitch_vel: float = 0.0
var roll_vel: float = 0.0
var ext := PackedFloat32Array([0.25, 0.25, 0.25, 0.25])   # current suspension extension per wheel
var wheel_contact := PackedByteArray([1, 1, 1, 1])        # 1 = wheel touches the ground
var ground_k: float = 1.0     # smoothed share of wheels on the ground (0 = airborne)
var prev_speed: float = 0.0
var long_acc: float = 0.0
var water_pitch: float = 0.0  # extra body tilt while wading (set by main.gd): bow wave + floating sway
var water_roll: float = 0.0
var ui = null                # touch_ui.gd instance (set by main.gd)
var enter_range: float = 7.0  # how close the player must be to get in
var driven: bool = false      # true while the player sits in the car
var heading: float = 0.0      # yaw in radians (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0
var steer_in: float = 0.0     # smoothed steering input (-1..1)
var throttle_s: float = 0.0   # smoothed throttle / brake pedal (-1..1)
var grip: float = 1.0         # surface grip 0.15..1 (set by main.gd from the terrain under the car)
var lat_speed: float = 0.0    # sideways velocity in the car frame, + = sliding left (m/s)
var yaw_rate: float = 0.0     # rad/s, + = turning left
var alpha_f: float = 0.0      # front / rear tyre slip angle (filtered, rad)
var alpha_r: float = 0.0
var lat_acc_f: float = 0.0    # filtered lateral acceleration (feeds body roll)
var slip_extra: float = 0.0   # wheelspin amount 0..1 (visual)
var cam_slide: float = 0.0    # smoothed body slip angle (rad): main.gd swings the camera with it
var wheel_spin_rear: float = 0.0
var visual: Node3D = null
var wheel_pivots: Array = []
var wheel_spinners: Array = []
var wheel_spin: float = 0.0

# tyre smoke / skid marks
var smoke: Array = []
var skid_nodes: Array = []
var skid_age := PackedFloat32Array()
var skid_next: int = 0
var skid_last: Array = []
var _skid_mat: StandardMaterial3D = null

var engine_audio: AudioStreamPlayer3D = null
var engine_rpm: float = 0.0

func _setup_vehicle_audio() -> void:
	engine_audio = AudioStreamPlayer3D.new()
	engine_audio.name = "Ford_F150_V8_Engine"
	engine_audio.stream = load("res://assets/audio/f150_v8_engine.wav")
	engine_audio.volume_db = -7.0
	engine_audio.unit_size = 8.0
	engine_audio.max_distance = 110.0
	engine_audio.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	if engine_audio.stream is AudioStreamWAV:
		(engine_audio.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
	add_child(engine_audio)
	engine_audio.play()

func _update_vehicle_audio(delta: float) -> void:
	if engine_audio == null:
		return
	var speed_ratio: float = clampf(absf(speed) / maxf(max_speed, 1.0), 0.0, 1.0)
	var load: float = clampf(absf(throttle_s), 0.0, 1.0)
	var target_rpm: float = lerpf(float(850), float(6200), pow(speed_ratio, 0.78))
	target_rpm += load * 1900
	if absf(speed) < 0.6 and load < 0.04:
		target_rpm = 850
	engine_rpm = lerpf(engine_rpm, clampf(target_rpm, float(850), float(8100)), 1.0 - exp(-4.5 * delta))
	engine_audio.pitch_scale = clampf(engine_rpm / float(1700), 0.62, 2.25)
	engine_audio.volume_db = lerpf(-15.0, -3.0, clampf(0.18 + speed_ratio * 0.52 + load * 0.45, 0.0, 1.0))

func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING   # no floor logic: height comes from the suspension
	collision_mask = 2        # only props / boundary (layer 2). The terrain is handled by the wheels.
	heading = rotation.y
	ride_y = global_position.y
	for i in range(4):
		ext[i] = susp_ext_rest
	_build_collision()
	_build_visual()
	_setup_vehicle_audio()
	if use_reflection_probe:
		_build_reflection_probe()
	if enable_fx:
		_build_fx()

func _ground(x: float, z: float) -> float:
	if world != null:
		return world.get_height(x, z)
	return 0.0

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# convex hull: low belly between the wheels, wide at bumper height, narrow cab on top
	var pts := PackedVector3Array([
		Vector3(-1.05, 0.40, -2.2), Vector3(1.05, 0.40, -2.2), Vector3(-1.05, 0.40, 2.3), Vector3(1.05, 0.40, 2.3),
		Vector3(-1.15, 0.55, -3.0), Vector3(1.15, 0.55, -3.0), Vector3(-1.15, 0.55, 3.25), Vector3(1.15, 0.55, 3.25),
		Vector3(-1.1, 1.55, -3.0), Vector3(1.1, 1.55, -3.0), Vector3(-1.1, 1.55, 3.25), Vector3(1.1, 1.55, 3.25),
		Vector3(-1.0, 2.4, -0.8), Vector3(1.0, 2.4, -0.8), Vector3(-1.0, 2.4, 0.9), Vector3(1.0, 2.4, 0.9),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _build_reflection_probe() -> void:
	# live reflections of terrain, trees and sky on the paint and glass
	probe = ReflectionProbe.new()
	probe.name = "ReflectionProbe"
	probe.position = Vector3(0.0, 1.3, 0.0)
	probe.size = Vector3(40.0, 20.0, 40.0)
	probe.origin_offset = Vector3.ZERO
	probe.box_projection = false
	probe.interior = false
	probe.max_distance = 120.0
	probe.intensity = 1.0
	probe.cull_mask = 0xFFFFF & ~SELF_LAYER
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	add_child(probe)

func _find_mesh(root: Node, prefix: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name).begins_with(prefix):
			return (c as MeshInstance3D).mesh
	return null

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/car/f150.glb" if full_quality else "res://assets/car/f150_lite.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var wheel_mesh: Mesh = _find_mesh(inst, "Wheel")
	inst.free()
	_style_mesh(body_mesh)
	_style_mesh(wheel_mesh)
	if body_mesh == null or wheel_mesh == null:
		push_error("f150.glb: Body/Wheel mesh not found")
		return
	var body := MeshInstance3D.new()
	body.name = "Body"
	body.mesh = body_mesh
	body.layers = SELF_LAYER
	visual.add_child(body)
	for wp in CarMeta.WHEELS:
		var pos: Vector3 = wp
		var pivot := Node3D.new()
		pivot.position = pos
		visual.add_child(pivot)
		var spinner := Node3D.new()
		pivot.add_child(spinner)
		var wm := MeshInstance3D.new()
		wm.mesh = wheel_mesh
		wm.layers = SELF_LAYER
		if pos.x < 0.0:
			wm.rotation.y = PI      # the wheel mesh is modelled for the right side
		spinner.add_child(wm)
		wheel_pivots.append(pivot)
		wheel_spinners.append(spinner)

func _style_mesh(mesh: Mesh) -> void:
	# glossy clear-coated paint; tyres are pure rubber (no sky reflection)
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		if m.resource_name == "Paint":
			m.albedo_color = paint_color
			m.metallic = 0.82
			m.roughness = 0.08
			m.metallic_specular = 1.0
			m.clearcoat_enabled = true
			m.clearcoat = 1.0
			m.clearcoat_roughness = 0.0
			m.rim_enabled = true          # fake fresnel sheen on the paint edges
			m.rim = 0.35
			m.rim_tint = 0.5
		elif m.resource_name in GLASS_MATS:
			m.roughness = 0.0
			m.metallic = 0.55
			m.metallic_specular = 1.0
		elif m.resource_name == "Tyre":
			m.metallic = 0.0
			m.roughness = 1.0
			m.metallic_specular = 0.0

func _read_input() -> Vector3:
	# returns (throttle, steer, handbrake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var hb: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			hb = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		hb = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), hb)


# ---------------------------------------------------------------------------------------------------------------
# tyre smoke / dust and skid marks
func _build_fx() -> void:
	var soft := GradientTexture2D.new()
	var gg := Gradient.new()
	gg.set_color(0, Color(1, 1, 1, 1))
	gg.set_color(1, Color(1, 1, 1, 0))
	gg.add_point(0.55, Color(1, 1, 1, 0.8))
	soft.gradient = gg
	soft.fill = GradientTexture2D.FILL_RADIAL
	soft.fill_from = Vector2(0.5, 0.5)
	soft.fill_to = Vector2(1.0, 0.5)
	soft.width = 64
	soft.height = 64
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 0.0))
	ramp.set_color(1, Color(1, 1, 1, 0.0))
	ramp.add_point(0.15, Color(1, 1, 1, 0.8))
	var grow := Curve.new()
	grow.add_point(Vector2(0.0, 0.5))
	grow.add_point(Vector2(1.0, 2.2))
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = soft
	mat.vertex_color_use_as_albedo = true
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mat.billboard_keep_scale = true
	mat.disable_receive_shadows = true
	var quad := QuadMesh.new()
	quad.size = Vector2(1.0, 1.0)
	quad.material = mat
	for i in range(4):
		var p := CPUParticles3D.new()
		p.top_level = true
		p.amount = 14
		p.lifetime = 1.4
		p.lifetime_randomness = 0.3
		p.local_coords = false
		p.emitting = false
		p.direction = Vector3(0.0, 1.0, 0.0)
		p.spread = 40.0
		p.gravity = Vector3(0.0, 0.5, 0.0)
		p.initial_velocity_min = 0.5
		p.initial_velocity_max = 1.6
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		p.emission_sphere_radius = 0.2
		p.scale_amount_min = 0.9
		p.scale_amount_max = 1.5
		p.scale_amount_curve = grow
		p.color_ramp = ramp
		p.color = Color(0.9, 0.9, 0.9, 0.5)
		p.mesh = quad
		p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(p)
		smoke.append(p)
		skid_last.append(Vector3(1.0e9, 1.0e9, 1.0e9))
	_skid_mat = StandardMaterial3D.new()
	_skid_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_skid_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_skid_mat.albedo_color = Color(0.03, 0.03, 0.03, 0.5)
	_skid_mat.disable_receive_shadows = true
	_skid_mat.render_priority = 1
	var pm := PlaneMesh.new()
	pm.size = Vector2(0.30, SKID_SPACING + 0.04)
	pm.material = _skid_mat
	skid_age.resize(SKID_POOL)
	for i in range(SKID_POOL):
		var mi := MeshInstance3D.new()
		mi.mesh = pm
		mi.top_level = true
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		skid_nodes.append(mi)
		skid_age[i] = 999.0

func _ground_normal(x: float, z: float) -> Vector3:
	var hx: float = _ground(x + 0.4, z) - _ground(x - 0.4, z)
	var hz: float = _ground(x, z + 0.4) - _ground(x, z - 0.4)
	return Vector3(-hx, 0.8, -hz).normalized()

func _place_skid(pos: Vector3, dir: Vector3) -> void:
	var n: Vector3 = _ground_normal(pos.x, pos.z)
	var zx: Vector3 = dir - n * dir.dot(n)
	if zx.length() < 0.01:
		return
	zx = zx.normalized()
	var xx: Vector3 = n.cross(zx).normalized()
	var mi: MeshInstance3D = skid_nodes[skid_next]
	mi.global_transform = Transform3D(Basis(xx, n, zx), pos)
	mi.transparency = 0.0
	mi.visible = true
	skid_age[skid_next] = 0.0
	skid_next = (skid_next + 1) % SKID_POOL

func _update_fx(delta: float, handbrake: bool, mu: float, air_k: float) -> void:
	if smoke.is_empty() or visual == null:
		return
	var v_abs: float = absf(speed)
	# fade old skid marks (about 14 s)
	for i in range(SKID_POOL):
		if skid_age[i] < 900.0:
			skid_age[i] += delta
			var t: float = skid_age[i] / 14.0
			var mi: MeshInstance3D = skid_nodes[i]
			if t >= 1.0:
				mi.visible = false
				skid_age[i] = 999.0
			else:
				mi.transparency = clampf(t * t, 0.0, 1.0)
	# how hard each axle is sliding (0..1)
	var move_k: float = clampf(maxf(v_abs, absf(lat_speed)) / 3.0, 0.0, 1.0)
	var sl_f: float = clampf((absf(alpha_f) - 0.09) / 0.10, 0.0, 1.0) * move_k * air_k
	var sl_r: float = clampf((absf(alpha_r) - 0.09) / 0.10, 0.0, 1.0) * move_k * air_k
	if handbrake and v_abs > 2.0:
		sl_r = maxf(sl_r, 0.9)
	sl_r = maxf(sl_r, slip_extra * 0.9)
	var loose: bool = mu < 0.6
	var vh := Vector3(velocity.x, 0.0, velocity.z)
	var dirn: Vector3 = vh.normalized() if vh.length() > 0.5 else forward_vector()
	for i in range(4):
		var s: float = sl_f if i < 2 else sl_r
		var p: CPUParticles3D = smoke[i]
		var emit: bool = s > 0.2 and wheel_contact[i] == 1
		p.emitting = emit
		var pv := wheel_pivots[i] as Node3D
		var wp: Vector3 = visual.to_global(pv.position + Vector3(0.0, 0.06 - CarMeta.WHEEL_RADIUS, 0.0))
		p.global_position = wp
		if emit:
			if loose:
				p.color = Color(0.62, 0.52, 0.38, 0.25 + 0.4 * s)       # dust
			else:
				p.color = Color(0.9, 0.9, 0.9, 0.2 + 0.45 * s)          # tyre smoke
			if not loose and s > 0.45:
				var gp := Vector3(wp.x, _ground(wp.x, wp.z) + 0.07, wp.z)
				var last: Vector3 = skid_last[i]
				if gp.distance_to(last) > SKID_SPACING:
					_place_skid(gp, dirn)
					skid_last[i] = gp
				continue
		skid_last[i] = Vector3(1.0e9, 1.0e9, 1.0e9)

# ---------------------------------------------------------------------------------------------------------------
# Pacejka-style lateral tyre force (magic formula without the curvature term): rises with slip angle, peaks around 8 deg,
# then falls to ~60-70% once the tyre slides.
func _tire(alpha: float, cap: float) -> float:
	return -cap * sin(1.6 * atan(tire_stiff * alpha))

# friction circle: grip left for cornering when the axle already uses part of its grip for driving / braking
func _circle(budget: float, fx: float) -> float:
	var r: float = clampf(fx / maxf(budget, 0.5), 0.0, 1.0)
	return budget * (0.30 + 0.70 * sqrt(1.0 - r * r))

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var parked: bool = not driven                  # nobody inside: parking brake holds the car
	var handbrake: bool = inp.z > 0.5 and driven
	var mu: float = clampf(grip, 0.15, 1.0)
	var wb: float = CarMeta.WHEELBASE
	var a_cg: float = wb * cg_front_ratio          # CG -> front axle
	var b_cg: float = wb - a_cg                    # CG -> rear axle
	var grip_cap: float = mu * grip_accel          # what all four tyres together can deliver (m/s^2)
	var drive_cap: float = grip_cap * drive_grip_gain
	var v_abs: float = absf(speed)
	var air_k: float = clampf(ground_k * 1.34, 0.0, 1.0)     # airborne: the tyres push on nothing

	# ---- pedals (smoothed: the engine and brakes do not react instantly)
	var thr_target: float = 0.0 if parked else inp.x
	throttle_s = move_toward(throttle_s, thr_target, (5.0 if absf(thr_target) > absf(throttle_s) else 9.0) * delta)

	# ---- load transfer: throttle loads the rear axle, braking the front
	var n_rear: float = clampf(cg_front_ratio + cg_height / wb * long_acc / G_REAL, 0.25, 0.75)
	var n_front: float = 1.0 - n_rear

	# ---- longitudinal: engine / brakes, limited by what the tyres hold
	var drive: float = 0.0
	var brake: float = 0.0
	var wheelspin: float = 0.0
	if parked:
		speed = move_toward(speed, 0.0, brake_decel * 1.3 * delta)
	else:
		if throttle_s > 0.05:
			if speed < -0.5:
				brake = minf(brake_decel, grip_cap * 1.05)
				speed += brake * delta
			else:
				var ratio: float = clampf(speed / max_speed, 0.0, 1.0)
				var a_eng: float = accel * throttle_s * (1.0 - ratio * ratio) + 0.5
				if handbrake:
					a_eng *= 0.5
				drive = minf(a_eng, drive_cap)
				speed += drive * delta
				wheelspin = clampf((a_eng - drive_cap) / maxf(accel, 1.0), 0.0, 1.0)
		elif throttle_s < -0.05:
			if speed > 0.5:
				brake = minf(brake_decel * (-throttle_s), grip_cap * 1.05)
				speed -= brake * delta
			else:
				drive = minf(accel * 0.6 * (-throttle_s), drive_cap)
				speed -= drive * delta
		else:
			speed = move_toward(speed, 0.0, coast_decel * delta)
		if handbrake:
			speed = move_toward(speed, 0.0, handbrake_decel * delta)
	slip_extra = lerpf(slip_extra, wheelspin, 1.0 - exp(-8.0 * delta))

	# ---- terrain slope: gravity along the hill, and cliffs block the way
	var fwd: Vector3 = forward_vector()
	var pos: Vector3 = global_position
	var gc: float = _ground(pos.x, pos.z)
	var f_pt: Vector3 = pos + fwd * 1.9
	var r_pt: Vector3 = pos - fwd * 1.9
	var slope_body: float = (_ground(f_pt.x, f_pt.z) - _ground(r_pt.x, r_pt.z)) / 3.8     # + = nose up
	if absf(speed) > 0.8 or absf(throttle_s) > 0.05:
		speed -= gravity * 0.4 * slope_body / sqrt(1.0 + slope_body * slope_body) * delta
	var dirn: float = 1.0 if speed >= 0.0 else -1.0
	var lead: Vector3 = pos + fwd * dirn * 3.0
	if (_ground(lead.x, lead.z) - gc) / 3.0 > 1.2:                    # steeper than ~50 deg ahead
		speed = move_toward(speed, 0.0, 70.0 * delta)
	speed = clampf(speed, -reverse_speed, max_speed)
	v_abs = absf(speed)
	var v_tot: float = sqrt(speed * speed + lat_speed * lat_speed)

	# ---- body slip angle (angle between where the nose points and where the car really goes)
	var beta: float = atan2(lat_speed, maxf(v_abs, 1.0)) if speed > 0.0 else 0.0

	# ---- steering: lock shrinks with speed; a little past what the tyres hold = understeer slide.
	#      Countersteer assist: when the tail steps out the front wheels turn into the slide by themselves.
	var in_rate: float = 6.0 if absf(inp.y) > 0.01 else 9.0
	steer_in = move_toward(steer_in, inp.y, in_rate * delta)
	var grip_angle: float = atan(wb * grip_cap * steer_overshoot / maxf(v_abs * v_abs, 1.0))
	var steer_limit: float = clampf(grip_angle, max_steer_high, max_steer_low)
	var beta_ex: float = signf(beta) * maxf(absf(beta) - 0.10, 0.0)
	var assist: float = countersteer_assist * 1.4 * beta_ex * smoothstep(4.0, 9.0, v_tot) * (0.35 if handbrake else 1.0)
	var steer_target: float = clampf(-steer_in * steer_limit + assist, -max_steer_low, max_steer_low)   # positive angle = turn left
	var steer_rate: float = lerpf(2.8, 1.6, clampf(v_abs / max_speed, 0.0, 1.0))
	if absf(steer_target) < absf(steer_now):
		steer_rate *= 1.6                                   # self-centering is quicker than turning in
	steer_now = move_toward(steer_now, steer_target, steer_rate * delta)

	# ---- grip budget of each axle (load x friction), reduced by what the axle already spends on driving / braking
	var rear_mu: float = mu * rear_grip_bias
	if handbrake and v_abs > 1.0:
		rear_mu = mu * handbrake_rear_grip
	if parked:
		rear_mu = maxf(rear_mu, 1.0)                 # parked: tyres hold, no sliding
	var bud_f: float = mu * grip_accel * n_front
	var bud_r: float = rear_mu * grip_accel * n_rear
	# 4x4 centre differential: the base split is shifted towards the axle with more grip (load x friction), so a slipping
	# axle does not waste the torque. awd_adaptive = 0 gives a fixed split.
	var rs: float = lerpf(rear_drive_share, clampf(bud_r / maxf(bud_f + bud_r, 0.001), 0.3, 0.7), awd_adaptive)
	var fx_f: float = drive * (1.0 - rs) * drive_circle + brake * 0.65
	var fx_r: float = drive * rs * drive_circle + brake * 0.35
	var cap_f: float = _circle(bud_f, fx_f)
	var cap_r: float = _circle(bud_r, fx_r)

	# ---- cross-slope: gravity pulls the car down a camber, the tyres have to hold it
	var side_force: float = 0.0
	if v_tot > 2.0:
		var left_v: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))
		var cross: float = (_ground(pos.x + left_v.x, pos.z + left_v.z) - _ground(pos.x - left_v.x, pos.z - left_v.z)) * 0.5
		side_force = -G_REAL * 0.8 * cross

	# ---- handling: front / rear axle slip angles -> lateral tyre forces -> yaw + sideways slide
	var tan_st: float = tan(steer_now)
	var sub: int = 3
	var dt: float = delta / float(sub)
	var lat_force: float = 0.0
	var vref: float = maxf(v_abs, 2.0)
	for _i in range(sub):
		var s_f: float = (lat_speed + a_cg * yaw_rate) - speed * tan_st
		var s_r: float = lat_speed - b_cg * yaw_rate
		var k_rel: float = minf(1.0, vref * dt / tire_relax)       # tyre relaxation: slip angle builds up over ~1 m of rolling
		alpha_f += (atan2(s_f, vref) - alpha_f) * k_rel
		alpha_r += (atan2(s_r, vref) - alpha_r) * k_rel
		var ff: float = _tire(alpha_f, cap_f) * air_k
		var fr: float = _tire(alpha_r, cap_r) * air_k
		lat_force = ff + fr
		lat_speed += (lat_force - speed * yaw_rate + side_force) * dt
		yaw_rate += (a_cg * ff - b_cg * fr) / yaw_inertia * dt
		yaw_rate *= exp(-0.12 * dt)
		speed += yaw_rate * lat_speed * dt                                # frame rotation coupling

	# stability assist: past ~8 deg of body slip the nose is pulled back towards the direction of travel
	var sb: float = sin(atan2(lat_speed, maxf(speed, 0.5)))
	var dz: float = signf(sb) * maxf(absf(sb) - 0.14, 0.0)
	if not handbrake and not parked:
		yaw_rate += stability_assist * 6.0 * dz * (1.0 - 0.5 * maxf(throttle_s, 0.0)) * smoothstep(3.0, 8.0, v_tot) * delta
	# sliding scrubs speed off (tyre force has a component against the direction of travel)
	speed = move_toward(speed, 0.0, absf(lat_force) * absf(sin(beta)) * delta)
	# crawling speed: tyre slip angles are meaningless -> follow the simple bicycle geometry
	v_tot = sqrt(speed * speed + lat_speed * lat_speed)
	var kin: float = 1.0 - smoothstep(2.0, 6.5, v_tot)
	yaw_rate = lerpf(yaw_rate, speed / wb * tan_st, kin)
	lat_speed = lerpf(lat_speed, 0.0, kin * clampf(10.0 * delta, 0.0, 1.0))
	yaw_rate = clampf(yaw_rate, -3.5, 3.5)
	lat_speed = clampf(lat_speed, -26.0, 26.0)
	lat_acc_f = lerpf(lat_acc_f, lat_force, 1.0 - exp(-9.0 * delta))
	cam_slide = lerpf(cam_slide, clampf(beta, -0.6, 0.6), 1.0 - exp(-3.0 * delta))

	heading += yaw_rate * delta
	rotation.y = heading
	fwd = forward_vector()
	var left: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))

	# ---- horizontal movement only (props / boundary collide, height is done by the suspension)
	var cs: float = 1.0 / sqrt(1.0 + slope_body * slope_body)           # slope speed -> ground-plane speed
	velocity = fwd * (speed * cs) + left * lat_speed
	velocity.y = 0.0
	global_position.y = ride_y
	move_and_slide()
	global_position.y = ride_y
	speed = velocity.dot(fwd) / maxf(cs, 0.3)                           # trees / rocks slow the car down
	lat_speed = velocity.dot(left)

	# ---- body motion from acceleration / cornering (tyre forces act at CG height -> dive, squat, roll)
	var la_raw: float = clampf((speed - prev_speed) / maxf(delta, 0.0001), -20.0, 20.0)
	long_acc = lerpf(long_acc, la_raw, 0.15)
	prev_speed = speed
	_suspension(delta, long_acc * cg_height * body_motion, -lat_acc_f * roll_arm * body_motion)

	_update_visual(delta, handbrake)
	_update_vehicle_audio(delta)
	if enable_fx:
		_update_fx(delta, handbrake, mu, air_k)

	# optional live reflection probe (off by default)
	if probe != null:
		probe_timer += delta
		if probe_timer > 1.5 and (absf(speed) > 1.0 or probe_timer > 4.0):
			probe_timer = 0.0
			probe.update_mode = ReflectionProbe.UPDATE_ALWAYS
			await get_tree().process_frame
			probe.update_mode = ReflectionProbe.UPDATE_ONCE

# 4 corner springs. Each corner's spring rate follows its share of the weight (front-heavy truck = stiffer front),
# damping is a damping ratio (bump soft / rebound firm), springs stiffen deep in the travel, anti-roll bars couple left / right.
# Each wheel attach point is compared with the terrain under the wheel (3 taps = the tyre rolls over small bumps).
func _suspension(delta: float, pitch_torque: float, roll_torque: float) -> void:
	var yaw_basis := Basis(Vector3.UP, heading)
	var body_basis: Basis = yaw_basis * Basis(Vector3.RIGHT, pitch) * Basis(Vector3.BACK, roll)
	var pos: Vector3 = global_position
	var wb: float = CarMeta.WHEELBASE
	var defl: float = maxf(susp_ext_max - susp_ext_rest, 0.05)           # static deflection (m)
	var omega: float = sqrt(gravity / defl)                              # natural frequency of every corner
	var cg_z: float = (CarMeta.WHEELS[0] as Vector3).z + wb * cg_front_ratio
	var fw: Vector3 = Vector3(-sin(heading), 0.0, -cos(heading))
	var fs := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])
	var comp := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])
	var touching := PackedByteArray([0, 0, 0, 0])
	var contacts: int = 0
	for i in range(4):
		var w: Vector3 = CarMeta.WHEELS[i]
		var corner: float = 0.5 * ((1.0 - cg_front_ratio) if i < 2 else cg_front_ratio)    # share of the weight on this corner
		var k: float = corner * gravity / defl
		var a: Vector3 = pos + body_basis * Vector3(w.x, w.y + susp_ext_rest, w.z)
		var g0: float = _ground(a.x, a.z)
		var gf: float = _ground(a.x + fw.x * 0.28, a.z + fw.z * 0.28)
		var gb: float = _ground(a.x - fw.x * 0.28, a.z - fw.z * 0.28)
		var g: float = maxf(g0, 0.5 * (gf + gb))                  # tyre envelope: bridges holes, climbs bumps earlier
		var raw: float = a.y - CarMeta.WHEEL_RADIUS - g           # distance wheel-bottom to ground if fully compressed
		var e: float = clampf(raw, 0.0, susp_ext_max)
		var rate: float = clampf((e - ext[i]) / maxf(delta, 0.0001), -12.0, 12.0)
		var f: float = 0.0
		if raw < susp_ext_max:                                   # wheel touches the ground
			contacts += 1
			touching[i] = 1
			var c: float = 2.0 * (damping_rebound if rate > 0.0 else damping_bump) * corner * omega
			var cm: float = susp_ext_max - e                      # compression
			var cr: float = cm / susp_ext_max
			var cr0: float = defl / susp_ext_max
			var prog: float = 1.0 + spring_progressive * maxf(cr * cr - cr0 * cr0, 0.0)
			f = k * cm * prog - c * rate
			var stop: float = maxf(0.07 - e, 0.0) / 0.07          # progressive bump stop in the last 7 cm
			f += stop * stop * 45.0
			if raw < 0.0:
				f += BUMP_K * (-raw) - 25.0 * minf(vy, 0.0)      # hard stop
			comp[i] = cm
		ext[i] = e
		fs[i] = f
	# anti-roll bars: couple left / right wheel of each axle
	var d_front: float = (comp[0] - comp[1]) * arb_front
	var d_rear: float = (comp[2] - comp[3]) * arb_rear
	fs[0] += d_front
	fs[1] -= d_front
	fs[2] += d_rear
	fs[3] -= d_rear
	var fsum: float = 0.0
	var tp: float = pitch_torque
	var tr: float = roll_torque
	for i in range(4):
		var w2: Vector3 = CarMeta.WHEELS[i]
		var fi: float = maxf(fs[i], 0.0) if touching[i] == 1 else 0.0
		fsum += fi
		tp += -(w2.z - cg_z) * fi                                # torques about the centre of gravity
		tr += w2.x * fi
	vy += (fsum - gravity) * delta
	pitch_vel += tp / INERTIA_PITCH * delta
	roll_vel += tr / INERTIA_ROLL * delta
	var damp: float = exp(-(0.6 if contacts == 0 else 1.0) * delta)
	pitch_vel *= damp
	roll_vel *= damp
	pitch += pitch_vel * delta
	roll += roll_vel * delta
	if absf(pitch) > 1.0:
		pitch = clampf(pitch, -1.0, 1.0)
		pitch_vel = 0.0
	if absf(roll) > 0.9:
		roll = clampf(roll, -0.9, 0.9)
		roll_vel = 0.0
	ride_y += vy * delta
	var gc: float = _ground(pos.x, pos.z)
	if ride_y < gc - 0.6:                                        # safety: never fall through the map
		ride_y = gc + 0.2
		vy = 0.0
	global_position.y = ride_y
	wheel_contact = touching
	ground_k = lerpf(ground_k, float(contacts) / 4.0, 1.0 - exp(-12.0 * delta))

func _update_visual(delta: float, handbrake: bool = false) -> void:
	if visual == null:
		return
	visual.basis = Basis(Vector3.RIGHT, pitch + water_pitch) * Basis(Vector3.BACK, roll + water_roll)
	wheel_spin = wrapf(wheel_spin - speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	# rear wheels: spin faster under wheelspin, stop when the handbrake locks them
	var rear_speed: float = speed + signf(speed if absf(speed) > 0.5 else 1.0) * slip_extra * 9.0
	if handbrake and absf(speed) > 1.0:
		rear_speed = speed * 0.1
	wheel_spin_rear = wrapf(wheel_spin_rear - rear_speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	for i in range(wheel_spinners.size()):
		(wheel_spinners[i] as Node3D).rotation.x = wheel_spin if i < 2 else wheel_spin_rear
		var pv := wheel_pivots[i] as Node3D
		var w: Vector3 = CarMeta.WHEELS[i]
		pv.position.y = w.y + susp_ext_rest - ext[i]           # wheels follow the ground, body rides on springs
		if i < 2:
			pv.rotation.y = steer_now
