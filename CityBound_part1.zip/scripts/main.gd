extends Node3D
# City Bound: offroad terrain, one rideable vehicle (NRG-500 motorbike), time cycle and weather.

const MapBuilder = preload("res://scripts/map_builder.gd")
const BikeMetaS = preload("res://scripts/bike_meta.gd")

var world = null
var player = null
var bike = null
var vehicle = null  # the bike currently being driven, null = on foot
var look_idle: float = 10.0
var ui = null
var tc = null
var cam_pivot: Node3D = null
var spring: SpringArm3D = null
var cam: Camera3D = null
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var cam_base_len: float = 4.2
var cam_zoom: float = 1.0
var hud: Label = null
var hud_timer: float = 0.0
var base_accel: Dictionary = {}
var base_max: Dictionary = {}
var sink: Dictionary = {}
var surf: Dictionary = {}
var water_fx: Dictionary = {}
var wade: Dictionary = {}
var pond_base: float = 0.0
var pond_mesh: MeshInstance3D = null
var _wsync: float = 0.0
var player_fx_on: bool = false
var rut_last: Dictionary = {}
var foot_dist: float = 0.0
var foot_side: float = 1.0
var ocean_audio: AudioStreamPlayer = null

func _ready() -> void:
	_setup_ambient_audio()
	_make_timecyc()
	world = MapBuilder.new()
	world.name = "World"
	world.weather_manager = tc
	add_child(world)
	_setup_water_sync()
	_make_player()
	_make_bike()
	_make_water_fx()
	_make_camera()
	_make_ui()
	bike.ui = ui

func _setup_ambient_audio() -> void:
	ocean_audio = AudioStreamPlayer.new()
	ocean_audio.name = "Beach_Ambience"
	ocean_audio.stream = load("res://assets/audio/ocean_ambience.wav")
	ocean_audio.volume_db = -19.0
	if ocean_audio.stream is AudioStreamWAV:
		(ocean_audio.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
	add_child(ocean_audio)
	ocean_audio.play()

func _setup_water_sync() -> void:
	if world == null:
		return
	world.set_process(false)
	if "_pond_level" in world:
		pond_base = float(world._pond_level)
	pond_mesh = world.get_node_or_null("PondWater") as MeshInstance3D

func _sync_water(delta: float) -> void:
	_wsync += delta
	if _wsync < 0.1 or tc == null or world == null:
		return
	_wsync = 0.0
	var rain: float = tc.get_rain_amount()
	if world.terrain_mat != null:
		world.terrain_mat.set_shader_parameter("rain_intensity", rain)
	if world.water_mat != null:
		world.water_mat.set_shader_parameter("rain_intensity", rain)
	var rise: float = 0.06 * tc.get_standing_water()
	if "_pond_level" in world:
		world._pond_level = pond_base + rise
	if pond_mesh != null:
		pond_mesh.position.y = rise

func _make_timecyc() -> void:
	tc = load("res://scripts/TimeCycWeatherManager.gd").new()
	tc.name = "TimeCycWeatherManager"
	tc.time_of_day = 16.6
	tc.day_length_seconds = 1080.0
	tc.fog_density_scale = 0.45
	add_child(tc)
	if tc.sun_light != null:
		tc.sun_light.directional_shadow_max_distance = 90.0

func _on_debug(id: int) -> void:
	if id >= 0 and id <= 3:
		tc.set_weather(id)
	elif id == 4:
		tc.set_time(tc.time_of_day + 3.0)

func _make_player() -> void:
	player = load("res://scripts/player.gd").new()
	player.position = world.spawn_position
	player.world = world
	add_child(player)
	cam_yaw = world.spawn_yaw
	player.model.rotation.y = cam_yaw + PI

func _make_bike() -> void:
	# NRG-500 parked beside the player spawn point.
	bike = load("res://scripts/bike.gd").new()
	var fwd := Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw))
	var right: Vector3 = fwd.cross(Vector3.UP)
	bike.position = world.get_safe_position(world.spawn_position + fwd * 3.0 + right * 3.2, 0.4)
	bike.rotation.y = world.spawn_yaw
	bike.world = world
	add_child(bike)
	base_accel[bike] = bike.accel
	base_max[bike] = bike.max_speed
	sink[bike] = 0.0

func _make_water_fx() -> void:
	var sun = tc.sun_light if tc != null else null
	var fx_bike = load("res://scripts/water_fx.gd").new()
	fx_bike.name = "WaterFxBike"
	add_child(fx_bike)
	fx_bike.setup(bike, world, sun, [BikeMetaS.WHEEL_F, BikeMetaS.WHEEL_R], Vector3(0.0, 0.0, -1.0), 1.0, 0.35, 0.72, 1)
	water_fx[bike] = fx_bike
	# Character wading effects: feet splashes, rings, waist wake and pond wake.
	var fx_p = load("res://scripts/water_fx.gd").new()
	fx_p.name = "WaterFxPlayer"
	add_child(fx_p)
	fx_p.setup(player, world, sun, [Vector3(-0.2, 0.0, 0.0), Vector3(0.2, 0.0, 0.0)], Vector3(0.0, 0.0, -0.45), 0.45, 0.4, 0.3, 2, 2.5, true)
	water_fx[player] = fx_p

func _nearest_vehicle():
	if bike == null:
		return null
	var d: float = player.global_position.distance_to(bike.global_position)
	return bike if d < bike.enter_range else null

func _on_action() -> void:
	if vehicle != null:
		_exit_vehicle()
	else:
		var v = _nearest_vehicle()
		if v != null:
			_enter_vehicle(v)

func _enter_vehicle(v) -> void:
	vehicle = v
	v.driven = true
	player.start_riding(bike)
	spring.add_excluded_object(v.get_rid())
	cam_base_len = 5.8
	cam_pitch = -0.22
	ui.jump_pressed = false

func _exit_vehicle() -> void:
	var v = vehicle
	vehicle = null
	v.driven = false
	player.stop_riding()
	var left: Vector3 = -v.forward_vector().cross(Vector3.UP)
	player.global_position = v.global_position + left * 1.5 + Vector3(0.0, 0.8, 0.0)
	player.model.rotation.y = v.heading + PI
	spring.remove_excluded_object(v.get_rid())
	cam_base_len = 4.2
	cam_pitch = -0.28
	ui.jump_pressed = false

func _make_camera() -> void:
	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam_pivot.global_position = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	spring = SpringArm3D.new()
	spring.spring_length = 4.2
	spring.margin = 0.25
	spring.collision_mask = 1
	cam_pivot.add_child(spring)
	spring.add_excluded_object(player.get_rid())
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 600.0
	# Keep layer 20 visible for the motorbike model.
	cam.cull_mask = 0xFFFFF
	spring.add_child(cam)
	cam.make_current()
	player.cam_pivot = cam_pivot

func _make_vignette() -> void:
	var vl := CanvasLayer.new()
	vl.layer = 0
	add_child(vl)
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	gr.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0.6)])
	var gt := GradientTexture2D.new()
	gt.gradient = gr
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 64
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	vl.add_child(tr)

func _make_ui() -> void:
	_make_vignette()
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = load("res://scripts/touch_ui.gd").new()
	layer.add_child(ui)
	player.ui = ui
	ui.debug_pressed.connect(_on_debug)
	ui.action_pressed.connect(_on_action)
	hud = Label.new()
	hud.position = Vector2(20.0, 14.0)
	hud.add_theme_font_size_override("font_size", 22)
	hud.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hud.add_theme_constant_override("outline_size", 6)
	layer.add_child(hud)

func _stamp_ruts(delta: float) -> void:
	var pts: Array = [BikeMetaS.WHEEL_F, BikeMetaS.WHEEL_R]
	var moving: bool = absf(bike.speed) > 0.5
	var yb := Basis(Vector3.UP, bike.rotation.y)
	for i in range(pts.size()):
		var lp: Vector3 = pts[i]
		var wp: Vector3 = bike.global_position + yb * Vector3(lp.x, 0.0, lp.z)
		var key: int = i
		if moving:
			if rut_last.has(key):
				world.press_rut_line(rut_last[key], wp, 0.13, 0.6 * delta, 1.0)
			rut_last[key] = wp
		else:
			rut_last.erase(key)
	if vehicle == null and player.is_on_floor():
		var hv := Vector2(player.velocity.x, player.velocity.z)
		if hv.length() > 0.25:
			foot_dist += hv.length() * delta
			if foot_dist > 0.55:
				foot_dist = 0.0
				foot_side = -foot_side
				var side := Vector3(hv.y, 0.0, -hv.x).normalized()
				var foot_pos: Vector3 = player.global_position + side * (0.13 * foot_side)
				var travel_dir := Vector3(hv.x, 0.0, hv.y).normalized()
				world.press_footprint(foot_pos, travel_dir, 0.48)
	world.flush_ruts(delta)

func _physics_process(delta: float) -> void:
	if bike == null or world == null:
		return
	_stamp_ruts(delta)
	var s: Dictionary = world.get_surface_state_at(bike.global_position)
	# Sample the water independently at both tyres. This makes the bike react to
	# entering/exiting water nose-first instead of treating the whole bike as one point.
	var fwd: Vector3 = bike.forward_vector()
	var wheel_f: Vector3 = bike.global_position + fwd * 0.79
	var wheel_r: Vector3 = bike.global_position - fwd * 0.79
	var sf: Dictionary = world.get_surface_state_at(wheel_f)
	var sr: Dictionary = world.get_surface_state_at(wheel_r)
	var front_depth: float = float(sf["water_depth"])
	var rear_depth: float = float(sr["water_depth"])
	var wheel_depth: float = (front_depth + rear_depth) * 0.5
	var water_depth: float = maxf(float(s["water_depth"]), wheel_depth)
	s["water_depth"] = water_depth
	var surface_y: float = float(s["water_surface"])
	if front_depth > 0.02:
		surface_y = maxf(surface_y, float(sf["water_surface"]))
	if rear_depth > 0.02:
		surface_y = maxf(surface_y, float(sr["water_surface"]))
	s["water_surface"] = surface_y
	var trac: float = float(s["traction_multiplier"])
	var dn: float = clampf(water_depth / 1.15, 0.0, 1.0)
	var wk: float = lerpf(float(wade.get(bike, 1.0)), lerpf(1.0, 0.34, dn), 1.0 - exp(-2.8 * delta))
	wade[bike] = wk
	var spd_abs: float = absf(bike.speed)
	var thin: float = smoothstep(0.02, 0.08, water_depth) * (1.0 - smoothstep(0.25, 0.55, water_depth))
	var aqua: float = thin * smoothstep(4.0, 18.0, spd_abs)
	var float_k: float = dn * dn
	bike.grip = trac * (1.0 - 0.48 * aqua) * lerpf(1.0, 0.48, float_k)
	bike.accel = base_accel[bike] * lerpf(0.42, 1.0, trac) * lerpf(1.0, 0.62, dn)
	bike.max_speed = maxf(base_max[bike] * lerpf(0.42, 1.0, trac) * wk, 2.0)
	# Water resistance rises non-linearly with immersion and speed, like a bow pushing water.
	bike.speed *= maxf(0.0, 1.0 - float(s["drag_factor"]) * (0.8 + dn) * delta)
	var hyd: float = minf(absf(bike.speed), (0.035 + 0.045 * dn) * dn * bike.speed * bike.speed * delta)
	bike.speed -= signf(bike.speed) * hyd
	bike.accel *= lerpf(1.0, 0.48, smoothstep(0.25, 1.0, water_depth))
	sink[bike] = lerpf(float(sink[bike]), minf(float(s["sink_amount"]) + dn * 0.22, 0.72), 1.0 - exp(-4.0 * delta))
	var tt: float = Time.get_ticks_msec() * 0.001
	var spd01: float = clampf(absf(bike.speed) / 12.0, 0.0, 1.0)
	var k_w: float = 1.0 - exp(-4.5 * delta)
	# Nose rises slightly when the front tyre meets deeper water; uneven depth rocks the chassis.
	var nose_impact: float = clampf(front_depth - rear_depth, -0.6, 0.6)
	var target_pitch: float = dn * (0.004 * sin(tt * 1.4) + 0.012 * spd01) - 0.025 * nose_impact
	bike.water_pitch = lerpf(bike.water_pitch, target_pitch - 0.02 * dn * clampf(bike.speed / 12.0, -1.0, 0.0), k_w)
	bike.water_roll = lerpf(bike.water_roll, dn * 0.008 * sin(tt * 1.9 + 1.3), k_w)
	if bike.visual != null:
		bike.visual.position.y = -float(sink[bike]) + dn * (0.035 + 0.018 * sin(tt * 2.3))
	if water_fx.has(bike):
		water_fx[bike].update(delta, s)
	if vehicle == bike:
		surf = s
	if water_fx.has(player):
		if vehicle == null:
			water_fx[player].update(delta, world.get_surface_state_at(player.global_position))
			player_fx_on = true
		elif player_fx_on:
			water_fx[player].stop()
			player_fx_on = false

func _process(delta: float) -> void:
	_sync_water(delta)
	if ui == null or player == null:
		return
	var ld: Vector2 = ui.look_delta
	ui.look_delta = Vector2.ZERO
	if Input.is_key_pressed(KEY_1):
		tc.set_weather(0)
	elif Input.is_key_pressed(KEY_2):
		tc.set_weather(1)
	elif Input.is_key_pressed(KEY_3):
		tc.set_weather(2)
	elif Input.is_key_pressed(KEY_4):
		tc.set_weather(3)
	if Input.is_key_pressed(KEY_Q):
		ld.x -= 400.0 * delta
	if Input.is_key_pressed(KEY_E):
		ld.x += 400.0 * delta
	if ld.length() > 0.5:
		look_idle = 0.0
	else:
		look_idle += delta
	if ui.zoom_dir != 0.0:
		cam_zoom = clampf(cam_zoom * exp(ui.zoom_dir * 0.9 * delta), 0.35, 2.5)
	spring.spring_length = cam_base_len * cam_zoom
	cam_yaw -= ld.x * 0.0045
	cam_pitch = clampf(cam_pitch - ld.y * 0.0045, -1.15, 0.45)
	var target: Vector3 = player.global_position + Vector3(0.0, 1.55, 0.0)
	if vehicle != null:
		target = vehicle.global_position + Vector3(0.0, 1.7, 0.0)
		if absf(vehicle.speed) > 1.5 and look_idle > 1.2:
			var want: float = vehicle.heading if vehicle.speed > 0.0 else vehicle.heading + PI
			cam_yaw = lerp_angle(cam_yaw, want, 1.0 - exp(-1.8 * delta))
		ui.action_label = "EXIT"
	else:
		ui.action_label = "ENTER" if _nearest_vehicle() != null else ""
	ui.vehicle_mode = vehicle != null
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	cam_pivot.global_position = cam_pivot.global_position.lerp(target, 1.0 - exp(-16.0 * delta))
	hud_timer += delta
	if hud_timer > 0.4:
		hud_timer = 0.0
		hud.text = "[v13]  FPS: %d   %s   %s   Wet: %d%%" % [Engine.get_frames_per_second(), tc.get_time_string(), tc.get_weather_name(), int(tc.road_wetness * 100.0)]
		if vehicle != null:
			hud.text += "   %d km/h   NRG-500" % int(vehicle.speed_kmh())
			if not surf.is_empty():
				hud.text += "   mud %d cm  water %d cm" % [int(float(surf["mud_depth"]) * 100.0), int(float(surf["water_depth"]) * 100.0)]
