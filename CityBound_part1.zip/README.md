# City Bound (Godot 4.3, Android)

Open-world exploration game with a Vice City-inspired island, a character, day/night cycle and changing weather. Rideable vehicles: NRG-500 motorbike, Ford F-150 4x4 pickup and KamAZ-5320 6x6 truck.

## Build the APK
1. Upload `CityBound_part1.zip` and `CityBound_part2.zip` to the repository root.
2. Use the updated `.github/workflows/build.yml` workflow.
3. Open the Actions tab and wait for **Build Android APK** to finish.
4. Download `CityBound-apk` from the workflow Artifacts and install the APK.

## Controls
- Left side: joystick to walk; hold RUN while moving to run.
- ENTER / EXIT appears when close to the Ford F-150, NRG-500 motorbike or KamAZ-5320 truck.
- While riding: arrow buttons steer, accelerate and brake/reverse; JUMP acts as the brake.
- Right side drag: camera; + / - buttons adjust camera distance.
- PC: WASD / arrows to move or ride, Space for jump/brake, Q/E to rotate the camera.
- Top-right buttons and PC keys 1-4 change weather; +3h advances the time.

## Vehicles
- `assets/car/f150.glb` is the Ford F-150; `scripts/car.gd` handles its 4x4 driving, suspension and tyre effects.
- `assets/truck/kamaz.glb` is the KamAZ-5320 6x6; `scripts/truck.gd` handles its heavy-truck driving, suspension and mud effects.
- Both vehicle models use render layer 20; the gameplay camera includes layer 20 (`cam.cull_mask = 0xFFFFF`) so the truck remains visible.

## Motorbike
- `assets/bike/nrg500.glb` is the NRG-500 model.
- `scripts/bike.gd` handles the two-wheel suspension, steering, lean and wheel rotation.
- `scripts/bike_meta.gd` stores wheel positions and geometry.
- The player sits on the bike while riding (`player.gd` -> `start_riding`).

## World, weather and water
- `scripts/map_builder.gd` and `scripts/world_builder.gd` build the offroad map, terrain and vegetation.
- `scripts/TimeCycWeatherManager.gd` controls the time cycle and Clear / Overcast / Rain / Post-rain weather.
- `scripts/water_fx.gd` handles splashes, ripples and wake effects for the car, bike, truck and character.
- `shaders/terrain_realistic.gdshader`, `shaders/grass.gdshader` and `shaders/sky_clouds.gdshader` provide terrain, grass and sky effects.

## Vice City-inspired island update
- Expanded procedural world to 600 x 600 metres.
- Added pastel downtown blocks, grid roads, beach promenade, palm accents, airport apron and marina piers.
- Water shader/material is preserved from the existing project; turquoise water settings are unchanged.
- All city geometry is generated at runtime with original procedural meshes/materials.
