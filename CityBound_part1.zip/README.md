# City Bound (Godot 4.3, Android)

Tropical beach exploration game with a 200 x 200 metre coastal world, broad sandy shoreline, ocean, vegetation, dirt tracks, a character, day/night cycle and changing weather. The NRG-500 motorbike is the only rideable vehicle in this build; the Ford F-150 car and KamAZ truck have been removed.

## Build the APK
1. Upload `CityBound_part1.zip` and `CityBound_part2.zip` to the repository root.
2. Use the updated `.github/workflows/build.yml` workflow.
3. Open the Actions tab and wait for **Build Android APK** to finish.
4. Download `CityBound-apk` from the workflow Artifacts and install the APK.

## Controls
- Left side: joystick movement.
- ENTER / EXIT appears when close to the NRG-500 motorbike.
- While riding: arrow buttons steer, accelerate and brake/reverse; JUMP acts as the brake.
- Right side drag: camera; + / - buttons adjust camera distance.
- PC: WASD / arrows to move or ride, Space for jump/brake, Q/E to rotate the camera.
- Top-right buttons and PC keys 1-4 change weather; +3h advances the time.

## Motorbike
- `assets/bike/nrg500.glb` is the NRG-500 model.
- `scripts/bike.gd` handles the two-wheel suspension, steering, lean and wheel rotation.
- `scripts/bike_meta.gd` stores wheel positions and geometry.
- The player sits on the bike while riding (`player.gd` -> `start_riding`).

## World, weather and water
- `scripts/map_builder.gd` and `scripts/world_builder.gd` build the expanded 200 x 200 metre coastal map, terrain and vegetation. The terrain uses a 500 x 500 cell grid with 0.4 m spacing.
- `scripts/TimeCycWeatherManager.gd` controls the time cycle and Clear / Overcast / Rain / Post-rain weather.
- `scripts/water_fx.gd` handles splashes, ripples and wake effects for the bike and the character.
- `shaders/terrain_realistic.gdshader`, `shaders/grass.gdshader` and `shaders/sky_clouds.gdshader` provide terrain, grass and sky effects. Dedicated seamless sand and compacted-soil albedo/normal maps are in `assets/tex/pbr/`.
