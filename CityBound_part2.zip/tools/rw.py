import struct,sys
def chunks(d,o,end):
    while o+12<=end:
        t,s,v=struct.unpack_from('<III',d,o)
        yield t,o+12,s,v
        o+=12+s
names={1:'Struct',2:'String',3:'Ext',6:'Texture',7:'Material',8:'MatList',0xE:'FrameList',0xF:'Geometry',0x10:'Clump',0x14:'Atomic',0x15:'TexNative',0x16:'TXD',0x1A:'GeoList',0x116:'Skin',0x11E:'HAnim',0x50E:'BinMesh',0x253F2FE:'FrameName',0x253F2F8:'2dfx',0x510:'NightCol'}
def dump(d,o,end,depth=0,maxd=3):
    for t,p,s,v in chunks(d,o,end):
        print('  '*depth+f'{names.get(t,hex(t))} size={s}')
        if depth<maxd and t in (0x10,0xE,0x1A,0xF,7,8,3,0x16,0x15,6,0x14):
            dump(d,p,p+s,depth+1,maxd)
if __name__=='__main__':
    d=open(sys.argv[1],'rb').read()
    dump(d,0,len(d),0,int(sys.argv[2]))
