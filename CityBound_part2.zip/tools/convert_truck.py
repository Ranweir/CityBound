"""GTA SA truck (KamAZ-5320 6x6, barracks.dff + barracks.txd) -> assets/truck/kamaz.glb + scripts/truck_meta.gd

Usage: python3 tools/convert_truck.py <barracks.dff> <barracks.txd> [out_dir_of_project]
Full quality: every visible part is kept at full triangle count and the textures keep their ORIGINAL size
(no down-scaling). Damage variants (_dam), the low-LOD hull and the optional cargo extras (tilt, machine gun) are skipped.
Output is baked in Godot axes (Y up, front = -Z). Origin = ground, halfway between the front axle and the middle of the rear bogie.
Meshes: Body + six separate wheels (WheelFL, WheelFR, WheelML, WheelMR, WheelRL, WheelRR), each centred on its own axle.
"""
import sys, os, io, json, struct
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dff import parse_dff
from rw import chunks
from convert import GLB

DFF = sys.argv[1] if len(sys.argv) > 1 else 'barracks.dff'
TXD = sys.argv[2] if len(sys.argv) > 2 else 'barracks.txd'
OUT = sys.argv[3] if len(sys.argv) > 3 else '.'


def load_txd_full(path):
    """same as convert.load_txd but WITHOUT the half-size down-scaling of big textures; names are lower-cased"""
    d = open(path, 'rb').read(); tex = {}
    for t, p, s, v in chunks(d, 12, len(d)):
        if t != 0x15: continue
        st = p + 12
        name = d[st + 8:st + 40].split(b'\0')[0].decode('latin1')
        raster, fourcc, w, h, depth, mips, rtype, comp = struct.unpack_from('<IIHHBBBB', d, st + 72)
        dsz, = struct.unpack_from('<I', d, st + 88); data = d[st + 92:st + 92 + dsz]
        if comp not in (8, 9, 12):
            print('skip unsupported texture', name, comp); continue
        hdr = b'DDS ' + struct.pack('<7I', 124, 0x81007, h, w, len(data), 0, 1) + b'\0' * 44
        hdr += struct.pack('<2I4s5I', 32, 4, struct.pack('<I', fourcc), 0, 0, 0, 0, 0) + struct.pack('<5I', 0x1000, 0, 0, 0, 0)
        img = Image.open(io.BytesIO(hdr + data)); img.load(); img = img.convert('RGBA')
        has_alpha = comp != 8
        if has_alpha and np.array(img)[:, :, 3].min() >= 250: has_alpha = False
        if not has_alpha: img = img.convert('RGB')
        tex[name.lower()] = (img, has_alpha)
    return tex


fr, ge, at = parse_dff(DFF)
tex = load_txd_full(TXD)
FI = {}
for i, f in enumerate(fr):
    FI.setdefault(f['name'], i)
atom = {fi: gi for fi, gi in at}


def local(i):
    R = fr[i]['rot'].T.copy(); p = fr[i]['pos'].copy()
    if fr[i]['parent'] < 0:               # root frame offset is ignored (GTA does the same)
        R = np.eye(3); p = np.zeros(3)
    return R, p
def world(i):
    R, p = local(i)
    par = fr[i]['parent']
    if par < 0: return R, p
    Rp, pp = world(par)
    return Rp @ R, Rp @ p + pp

WHEEL_FRAMES = {'WheelFL': 'wheel_lf', 'WheelFR': 'wheel_rf', 'WheelML': 'wheel_lb', 'WheelMR': 'wheel_rb', 'WheelRL': 'wheel_lm', 'WheelRR': 'wheel_rm'}
# wheel_lb / wheel_rb sit at the second axle (y=-1.49), wheel_lm / wheel_rm at the third (y=-2.84)
BODY_NAMES = ['chassis', 'chassis1', 'èíòåðüåð', 'ïëàòôîðìà', 'boot_ok', 'bump_front_ok', 'bump_rear_ok', 'bonnet_ok',
              'dvorleft', 'dvorright', 'steeringok', 'speedook', 'tahook', 'oil', 'petrolok', 'temperature', 'ampers', 'rvolts',
              'hour', 'minute', 'windscreen_ok']
BODY_IDX = []
for n in BODY_NAMES:
    BODY_IDX.append(FI[n])
BODY_IDX += [55, 58]                      # the two doors: the left door frame is also named 'door_rf_ok', so they are taken by frame index

# wheel centres (world, DFF axes: x right, y forward, z up)
wc = {k: world(FI[v])[1] for k, v in WHEEL_FRAMES.items()}
# the model frames are the true wheel centres (bounding boxes confirm it)
GROUND_Z = min(world(FI[v])[1][2] for v in WHEEL_FRAMES.values()) - 0.53   # tyre radius 0.53 (from the mesh bbox)
y_front = wc['WheelFL'][1]
y_bogie = 0.5 * (wc['WheelML'][1] + wc['WheelRL'][1])
YMID = 0.5 * (y_front + y_bogie)


def to_g(p):
    p = np.asarray(p, float)
    if p.ndim > 1:
        return np.array([p[..., 0], p[..., 2] - GROUND_Z, -(p[..., 1] - YMID)]).T
    return np.array([p[0], p[2] - GROUND_Z, -(p[1] - YMID)])
def to_gdir(n):
    n = np.asarray(n, float); return np.array([n[:, 0], n[:, 2], -n[:, 1]]).T

G = GLB(); images = []; textures = []; materials = []; mat_key = {}
GLASS = 'kamaz_mixer_glass_diff1out'
def get_material(m):
    name = (m['tex'] or 'plain').lower()
    col = m['color']
    key = (name, None if name in tex else col)
    if key in mat_key: return mat_key[key]
    mat = dict(name=name, pbrMetallicRoughness=dict(metallicFactor=0.0, roughnessFactor=0.78))
    if name in tex:
        img, al = tex[name]
        b = io.BytesIO(); img.save(b, 'PNG')
        images.append(dict(bufferView=G.view(b.getvalue()), mimeType='image/png', name=name))
        textures.append(dict(source=len(images) - 1, sampler=0))
        mat['pbrMetallicRoughness']['baseColorTexture'] = dict(index=len(textures) - 1)
        if al: mat['alphaMode'] = 'MASK'; mat['alphaCutoff'] = 0.5; mat['doubleSided'] = True
    else:
        mat['pbrMetallicRoughness']['baseColorFactor'] = [c / 255.0 for c in col[:3]] + [1.0]
        if name.startswith('vehiclelights'):
            mat['emissiveFactor'] = [c / 255.0 * 0.25 for c in col[:3]]
    if name == GLASS:                       # windscreen / door windows: dark tinted glass
        mat['alphaMode'] = 'BLEND'; mat['doubleSided'] = True
        mat['pbrMetallicRoughness'] = dict(metallicFactor=0.2, roughnessFactor=0.05, baseColorFactor=[0.16, 0.2, 0.19, 0.32])
    materials.append(mat); mat_key[key] = len(materials) - 1
    return mat_key[key]

def strip_to_tris(ind):
    out = []
    for i in range(len(ind) - 2):
        a, b, c = ind[i], ind[i + 1], ind[i + 2]
        if a == b or b == c or a == c: continue
        out.append((a, c, b) if i % 2 else (a, b, c))
    return np.array(out, dtype=np.uint32)

def build_prims(frame_ids, centre):
    prims = []; total = 0
    for fi in frame_ids:
        g = ge[atom[fi]]
        R, p = world(fi)
        V = to_g(g['verts'].astype(float) @ R.T + p) - centre
        N = to_gdir(g['normals'].astype(float) @ R.T)
        N /= np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-9)   # the wheel frames are scaled: renormalise
        UV = g['uv'].astype('<f4')
        V = V.astype('<f4'); N = N.astype('<f4')
        pos = G.accessor(V, 5126, 'VEC3', 34962, True); nor = G.accessor(N, 5126, 'VEC3', 34962)
        uv = G.accessor(UV, 5126, 'VEC2', 34962)
        for mi, ind in g['mesh']['meshes']:
            tri = strip_to_tris(ind) if g['mesh']['strip'] else ind.astype('<u4').reshape(-1, 3)
            fnorm = np.cross(V[tri[:, 1]] - V[tri[:, 0]], V[tri[:, 2]] - V[tri[:, 0]])
            if np.mean(np.sum(fnorm * N[tri[:, 0]], 1) > 0) < 0.5:
                tri = tri[:, [0, 2, 1]]
            ia = G.accessor(tri.astype('<u4').reshape(-1), 5125, 'SCALAR', 34963)
            prims.append(dict(attributes=dict(POSITION=pos, NORMAL=nor, TEXCOORD_0=uv), indices=ia, material=get_material(g['mats'][mi])))
            total += len(tri)
    return prims, total

meshes = []; nodes = []; stats = {}
centres = {'Body': np.zeros(3)}
for k in WHEEL_FRAMES: centres[k] = to_g(wc[k])
groups = {'Body': BODY_IDX}
for k, v in WHEEL_FRAMES.items(): groups[k] = [FI[v]]
for gname, ids in groups.items():
    prims, tt = build_prims(ids, centres[gname])
    meshes.append(dict(name=gname, primitives=prims))
    nodes.append(dict(name=gname, mesh=len(meshes) - 1, translation=[float(x) for x in centres[gname]]))
    stats[gname] = tt

gltf = dict(asset=dict(version='2.0', generator='truck-convert'), scene=0, scenes=[dict(nodes=list(range(len(nodes))))],
            nodes=nodes, meshes=meshes, materials=materials, textures=textures, images=images,
            samplers=[dict(magFilter=9729, minFilter=9987, wrapS=10497, wrapT=10497)],
            accessors=G.acc, bufferViews=G.bv, buffers=[dict(byteLength=len(G.bin))])
js = json.dumps(gltf).encode(); js += b' ' * ((4 - len(js) % 4) % 4)
binb = bytes(G.bin) + b'\0' * ((4 - len(G.bin) % 4) % 4)
os.makedirs(os.path.join(OUT, 'assets/truck'), exist_ok=True)
with open(os.path.join(OUT, 'assets/truck/kamaz.glb'), 'wb') as f:
    f.write(struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(binb)))
    f.write(struct.pack('<I4s', len(js), b'JSON') + js); f.write(struct.pack('<I4s', len(binb), b'BIN\0') + binb)

def gv(v): return 'Vector3(%.4f, %.4f, %.4f)' % tuple(v)
order = ['WheelFL', 'WheelFR', 'WheelML', 'WheelMR', 'WheelRL', 'WheelRR']
rad = float(centres['WheelFL'][1])
seat = to_g(world(FI['ped_frontseat'])[1])
meta = "# Generated by tools/convert_truck.py from the GTA SA KamAZ-5320 model - metres, Godot axes (-Z = front), origin = ground, halfway\n"
meta += "# between the front axle and the middle of the rear bogie.\nextends RefCounted\n\n"
meta += "# 6x6: front axle, middle axle, rear axle (left, right of each)\nconst WHEELS: Array = [\n"
labels = ['front left', 'front right', 'middle left', 'middle right', 'rear left', 'rear right']
for k, lb in zip(order, labels):
    meta += "\t%s,   # %s\n" % (gv(centres[k]), lb)
meta += "]\n"
meta += "const WHEEL_RADIUS: float = %.4f\n" % rad
meta += "const WHEELBASE: float = %.4f      # front axle -> middle of the rear bogie\n" % (centres['WheelRL'][2] * 0.0 + (0.5 * (centres['WheelML'][2] + centres['WheelRL'][2]) - centres['WheelFL'][2]))
meta += "const BOGIE_SPACING: float = %.4f   # middle axle -> rear axle\n" % (centres['WheelRL'][2] - centres['WheelML'][2])
meta += "const SEAT: Vector3 = %s\n" % gv(seat)
open(os.path.join(OUT, 'scripts/truck_meta.gd'), 'w').write(meta)
print('triangles', stats, 'total', sum(stats.values()))
print('glb bytes', os.path.getsize(os.path.join(OUT, 'assets/truck/kamaz.glb')))
print(meta)
