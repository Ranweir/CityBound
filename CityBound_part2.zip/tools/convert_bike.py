"""GTA SA bike (NRG-500 .dff + .txd) -> assets/bike/nrg500.glb + scripts/bike_meta.gd

Usage: python3 tools/convert_bike.py <bike.dff> <bike.txd> [out_dir_of_project]
Full quality: every LOD0 mesh is kept at full triangle count, textures keep their original size.
Output is baked in Godot axes (Y up, front = -Z). Origin = ground, halfway between the two wheels.
"""
import sys, os, io, json, struct
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dff import parse_dff
from convert import load_txd, GLB

DFF = sys.argv[1] if len(sys.argv) > 1 else 'bike.dff'
TXD = sys.argv[2] if len(sys.argv) > 2 else 'bike.txd'
OUT = sys.argv[3] if len(sys.argv) > 3 else '.'

fr, ge, at = parse_dff(DFF)
tex = load_txd(TXD)                       # no down-scaling for these small textures
FN = {f['name']: i for i, f in enumerate(fr)}

def local(i):
    R = fr[i]['rot'].T.copy(); p = fr[i]['pos'].copy()
    if fr[i]['parent'] < 0:               # root frame offset is ignored (GTA does the same)
        R = np.eye(3); p = np.zeros(3)
    return R, p
def world(i):
    R, p = local(i)
    par = fr[i]['parent']
    if par < 0: return R, p
    Rp, pp = world(par)
    return Rp @ R, Rp @ p + pp

wR, wF = world(FN['wheel_rear'])[1], world(FN['wheel_front'])[1]
pivot_dff = world(FN['forks_front'])[1]
GROUND_Z = wR[2] - 0.35                    # rear tyre bottom (rear tyre radius from the mesh bbox)
YMID = (wR[1] + wF[1]) / 2.0
def to_g(p):                              # dff (x right, y fwd, z up) -> godot, ground at y=0, origin between the wheels
    p = np.asarray(p, float)
    return np.array([p[..., 0], p[..., 2] - GROUND_Z, -(p[..., 1] - YMID)]).T if p.ndim > 1 else np.array([p[0], p[2] - GROUND_Z, -(p[1] - YMID)])
def to_gdir(n):
    n = np.asarray(n, float); return np.array([n[:, 0], n[:, 2], -n[:, 1]]).T

# frame -> (mesh group, geometry); chassis_vlo (low LOD) is skipped
GROUPS = {'Body': ['chassis', 'glass', 'nomer', 'forks_rear'],
          'Fork': ['forks_front', 'mudguard'],
          'WheelF': ['wheel_front'], 'WheelR': ['wheel_rear']}
centres = {'Body': np.zeros(3), 'Fork': to_g(pivot_dff), 'WheelF': to_g(wF), 'WheelR': to_g(wR)}
atom = {fr[fi]['name']: gi for fi, gi in at}

G = GLB(); images = []; textures = []; materials = []; mat_key = {}
def get_material(m):
    name = m['tex'] or 'plain'
    col = m['color']
    key = (name, col if (m['tex'] is None or name == 'lob_steklo') else None)
    if key in mat_key: return mat_key[key]
    mat = dict(name=name, pbrMetallicRoughness=dict(metallicFactor=0.0, roughnessFactor=0.7))
    if m['tex'] in tex:
        img, al = tex[m['tex']]
        b = io.BytesIO(); img.save(b, 'PNG')
        images.append(dict(bufferView=G.view(b.getvalue()), mimeType='image/png', name=name))
        textures.append(dict(source=len(images) - 1, sampler=0))
        mat['pbrMetallicRoughness']['baseColorTexture'] = dict(index=len(textures) - 1)
        if al: mat['alphaMode'] = 'MASK'; mat['alphaCutoff'] = 0.5; mat['doubleSided'] = True
    else:
        mat['pbrMetallicRoughness']['baseColorFactor'] = [c / 255.0 for c in col]
    if name == 'lob_steklo':               # windscreen
        mat['alphaMode'] = 'BLEND'; mat['doubleSided'] = True
        mat['pbrMetallicRoughness']['baseColorFactor'] = [0.18, 0.2, 0.22, 0.28]
    if name in ('nomer', 'ramka'): mat['doubleSided'] = True
    materials.append(mat); mat_key[key] = len(materials) - 1
    return mat_key[key]

def strip_to_tris(ind):
    out = []
    for i in range(len(ind) - 2):
        a, b, c = ind[i], ind[i + 1], ind[i + 2]
        if a == b or b == c or a == c: continue
        out.append((a, c, b) if i % 2 else (a, b, c))
    return np.array(out, dtype=np.uint32)

meshes = []; nodes = []; stats = {}
for gname, frames in GROUPS.items():
    prims = []; tris_total = 0
    for fname in frames:
        gi = atom[fname]; g = ge[gi]
        R, p = world(FN[fname])
        V = to_g(g['verts'].astype(float) @ R.T + p) - centres[gname]
        N = to_gdir(g['normals'].astype(float) @ R.T)
        UV = g['uv'].astype('<f4')
        V = V.astype('<f4'); N = N.astype('<f4')
        pos = G.accessor(V, 5126, 'VEC3', 34962, True); nor = G.accessor(N, 5126, 'VEC3', 34962)
        uv = G.accessor(UV, 5126, 'VEC2', 34962)
        for mi, ind in g['mesh']['meshes']:
            tri = strip_to_tris(ind) if g['mesh']['strip'] else ind.astype('<u4').reshape(-1, 3)
            fnorm = np.cross(V[tri[:, 1]] - V[tri[:, 0]], V[tri[:, 2]] - V[tri[:, 0]])
            if np.mean(np.sum(fnorm * N[tri[:, 0]], 1) > 0) < 0.5:
                tri = tri[:, [0, 2, 1]]
            ia = G.accessor(tri.astype('<u4').reshape(-1), 5125, 'SCALAR', 34963)
            prims.append(dict(attributes=dict(POSITION=pos, NORMAL=nor, TEXCOORD_0=uv), indices=ia, material=get_material(g['mats'][mi])))
            tris_total += len(tri)
    meshes.append(dict(name=gname, primitives=prims))
    nodes.append(dict(name=gname, mesh=len(meshes) - 1, translation=[float(x) for x in centres[gname]]))
    stats[gname] = tris_total

gltf = dict(asset=dict(version='2.0', generator='bike-convert'), scene=0, scenes=[dict(nodes=list(range(len(nodes))))],
            nodes=nodes, meshes=meshes, materials=materials, textures=textures, images=images,
            samplers=[dict(magFilter=9729, minFilter=9987, wrapS=10497, wrapT=10497)],
            accessors=G.acc, bufferViews=G.bv, buffers=[dict(byteLength=len(G.bin))])
js = json.dumps(gltf).encode(); js += b' ' * ((4 - len(js) % 4) % 4)
binb = bytes(G.bin) + b'\0' * ((4 - len(G.bin) % 4) % 4)
os.makedirs(os.path.join(OUT, 'assets/bike'), exist_ok=True)
with open(os.path.join(OUT, 'assets/bike/nrg500.glb'), 'wb') as f:
    f.write(struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(binb)))
    f.write(struct.pack('<I4s', len(js), b'JSON') + js); f.write(struct.pack('<I4s', len(binb), b'BIN\0') + binb)

fw, rw_ = centres['WheelF'], centres['WheelR']
pv = centres['Fork']
def gv(v): return 'Vector3(%.4f, %.4f, %.4f)' % tuple(v)
seat = to_g(world(FN['ped_frontseat'])[1]); grip = to_g(world(FN['bargrip'])[1])
meta = f"""# Generated by tools/convert_bike.py from the GTA SA NRG-500 model - metres, Godot axes (-Z = front), origin = ground between the wheels
extends RefCounted

const WHEEL_F: Vector3 = {gv(fw)}       # front wheel centre
const WHEEL_R: Vector3 = {gv(rw_)}       # rear wheel centre
const RADIUS_F: float = {fw[1]:.4f}
const RADIUS_R: float = {rw_[1]:.4f}
const WHEELBASE: float = {rw_[2]-fw[2]:.4f}
const FORK_PIVOT: Vector3 = {gv(pv)}   # steering head; the fork rotates around the line pivot -> front wheel centre
const SEAT: Vector3 = {gv(seat)}
const GRIP_R: Vector3 = {gv(grip)}
"""
open(os.path.join(OUT, 'scripts/bike_meta.gd'), 'w').write(meta)
print('triangles', stats, 'total', sum(stats.values()))
print(meta)
