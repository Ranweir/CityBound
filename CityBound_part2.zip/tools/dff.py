import struct, numpy as np
from rw import chunks
def u(d,o,f): return struct.unpack_from('<'+f,d,o)
def parse_dff(path):
    d=open(path,'rb').read()
    clump=next(chunks(d,0,len(d)))
    _,cp,cs,_=clump
    frames=[];geoms=[];atomics=[]
    for t,p,s,v in chunks(d,cp,cp+cs):
        if t==0xE: frames=parse_frames(d,p,s)
        elif t==0x1A:
            for t2,p2,s2,_ in chunks(d,p,p+s):
                if t2==0xF: geoms.append(parse_geom(d,p2,s2))
        elif t==0x14:
            fi,gi,fl,_=u(d,p+12,'IIII'); atomics.append((fi,gi))
    return frames,geoms,atomics
def parse_frames(d,p,size):
    it=list(chunks(d,p,p+size))
    t,sp,ss,_=it[0]
    n,=u(d,sp,'I')
    fr=[]
    for i in range(n):
        m=np.array(u(d,sp+4+i*56,'9f')).reshape(3,3)
        pos=np.array(u(d,sp+4+i*56+36,'3f'))
        par,flags=u(d,sp+4+i*56+48,'iI')
        fr.append(dict(rot=m,pos=pos,parent=par,name=None,nodeid=None,hier=None))
    idx=0
    for t,p2,s2,_ in it[1:]:
        if t==3:
            for t3,p3,s3,_ in chunks(d,p2,p2+s2):
                if t3==0x253F2FE: fr[idx]['name']=d[p3:p3+s3].split(b'\0')[0].decode('latin1')
                elif t3==0x11E:
                    ver,nid,cnt=u(d,p3,'iii')
                    fr[idx]['nodeid']=nid
                    if cnt>0:
                        fl,ks=u(d,p3+12,'II')
                        fr[idx]['hier']=[u(d,p3+20+i*12,'iii') for i in range(cnt)]
            idx+=1
    return fr
def parse_geom(d,p,size):
    g={}
    it=list(chunks(d,p,p+size))
    sp=it[0][1]
    flags,tri,nv,morph=u(d,sp,'IIII'); o=sp+16
    ntex=(flags>>16)&0xff
    if ntex==0: ntex=1 if flags&4 else (2 if flags&0x80 else 0)
    if flags&8: o+=nv*4
    uvs=[]
    for k in range(ntex):
        uvs.append(np.frombuffer(d,'<f4',nv*2,o).reshape(nv,2)); o+=nv*8
    tris=np.frombuffer(d,'<u2',tri*4,o).reshape(tri,4); o+=tri*8
    verts=normals=None
    for m in range(morph):
        o+=16
        hv,hn=u(d,o,'II'); o+=8
        if hv: verts=np.frombuffer(d,'<f4',nv*3,o).reshape(nv,3); o+=nv*12
        if hn: normals=np.frombuffer(d,'<f4',nv*3,o).reshape(nv,3); o+=nv*12
        break
    g.update(flags=flags,verts=verts,normals=normals,uv=uvs[0] if uvs else None,tris=tris,nv=nv)
    g['mats']=[];g['skin']=None;g['mesh']=None
    for t,p2,s2,_ in it[1:]:
        if t==8: g['mats']=parse_matlist(d,p2,s2)
        elif t==3:
            for t3,p3,s3,_ in chunks(d,p2,p2+s2):
                if t3==0x116: g['skin']=parse_skin(d,p3,s3,nv)
                elif t3==0x50E: g['mesh']=parse_bin(d,p3,s3)
    return g
def parse_matlist(d,p,size):
    mats=[]
    for t,p2,s2,_ in chunks(d,p,p+size):
        if t==7:
            m=dict(tex=None,color=(255,255,255,255))
            for t3,p3,s3,_ in chunks(d,p2,p2+s2):
                if t3==1:
                    fl,col,un,tx=u(d,p3,'I4BII'.replace('4B','I')) if False else (None,)*4
                    m['color']=tuple(d[p3+4:p3+8]); m['textured']=u(d,p3+12,'I')[0]
                elif t3==6:
                    for t4,p4,s4,_ in chunks(d,p3,p3+s3):
                        if t4==2 and m['tex'] is None: m['tex']=d[p4:p4+s4].split(b'\0')[0].decode('latin1')
            mats.append(m)
    return mats
def parse_skin(d,p,size,nv):
    nb,nub,mw,_=u(d,p,'BBBB'); o=p+4
    used=list(d[o:o+nub]); o+=nub
    idx=np.frombuffer(d,'u1',nv*4,o).reshape(nv,4).copy(); o+=nv*4
    w=np.frombuffer(d,'<f4',nv*4,o).reshape(nv,4).copy(); o+=nv*16
    ibm=np.frombuffer(d,'<f4',nb*16,o).reshape(nb,4,4).copy()
    return dict(nb=nb,used=used,idx=idx,w=w,ibm=ibm)
def parse_bin(d,p,size):
    fl,nm,ti=u(d,p,'III'); o=p+12; meshes=[]
    for i in range(nm):
        cnt,mi=u(d,o,'II'); o+=8
        ind=np.frombuffer(d,'<u4',cnt,o).copy(); o+=cnt*4
        meshes.append((mi,ind))
    return dict(strip=fl==1,meshes=meshes)
if __name__=='__main__':
    fr,ge,at=parse_dff("Skin/Mai Shiranui Tactical Camo.dff")
    print(len(fr),len(ge),at)
    for i,f in enumerate(fr): print(i,f['name'],f['parent'],f['nodeid'],np.round(f['pos'],3), 'H' if f['hier'] else '')
    for g in ge:
        print(g['nv'],hex(g['flags']),[ (m['tex'],m['color']) for m in g['mats']], g['skin'] and (g['skin']['nb'],g['skin']['used']), g['mesh'] and (g['mesh']['strip'],[(a,len(b)) for a,b in g['mesh']['meshes']]), len(g['tris']))
