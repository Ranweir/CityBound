import struct, numpy as np
def u(d,o,f): return struct.unpack_from('<'+f,d,o)
def nm(b): return b.split(b'\0')[0].decode('latin1')
def parse_ifp(path):
    d=open(path,'rb').read()
    assert d[:4]==b'ANP3'
    n,=u(d,32,'I'); o=36; anims={}
    for _ in range(n):
        name=nm(d[o:o+24]); nobj,fsz,unk=u(d,o+24,'III'); o+=36
        objs=[]
        for _ in range(nobj):
            oname=nm(d[o:o+24]); ft,nf,bid,=u(d,o+24,'III'); o+=36
            # frame types: 3 = rot+trans (16 bytes), 4?/other = rot only (10 bytes)
            fs=16 if ft==4 else 10 if ft==3 else None
            objs.append(dict(name=oname,ft=ft,nf=nf,bid=bid,off=o))
            o+=nf*(16 if ft==4 else 10)  # provisional
        anims[name]=dict(objs=objs,nobj=nobj,fsz=fsz,end=o)
    return d,anims
if __name__=='__main__':
    d,a=parse_ifp('anim/ped.ifp')
    print(len(a))
    for k in list(a)[:15]: print(k,a[k]['nobj'],a[k]['fsz'],[(o['name'],o['ft'],o['nf'],o['bid']) for o in a[k]['objs']][:3])
    for k in ['walk_player','run_player','idle_stance','WALK_player','IDLE_stance']:
        print(k, k in a)
    print([k for k in a if 'walk' in k.lower() or 'idle' in k.lower() or k.lower().startswith('run')][:30])
