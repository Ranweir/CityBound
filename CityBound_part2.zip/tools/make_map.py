"""Generates the offroad hills test map: heightmap, splat/detail map, vegetation placement, props (numpy only).
Run:  python3 tools/make_map.py   (writes assets/map/*.bin and scripts/map_meta.gd)"""
import numpy as np, struct, math, os
from PIL import Image
from scipy import ndimage as ndi

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'assets','map'); os.makedirs(OUT,exist_ok=True)
N=257; M=1025; SIZE=400.0; HALF=SIZE/2; SP=SIZE/(M-1)
rng=np.random.default_rng(1234)
g=np.linspace(-HALF,HALF,M); X,Z=np.meshgrid(g,g)       # arrays are [z_row, x_col]

def smooth(a,b,x):
    t=np.clip((x-a)/(b-a),0,1); return t*t*(3-2*t)
def fbm(octs,base,seed,pers=0.5):
    r=np.random.default_rng(seed); out=np.zeros((M,M),np.float32); amp=1.0; tot=0.0
    for o in range(octs):
        k=base*2**o+1
        im=Image.fromarray(r.random((k,k)).astype(np.float32),'F').resize((M,M),Image.BICUBIC)
        out+=amp*np.asarray(im); tot+=amp; amp*=pers
    out/=tot; return (out-out.min())/(out.max()-out.min())

# ---------------- base terrain
low=fbm(3,2,1); mid=fbm(4,6,2); hi=fbm(3,24,3); ridge=1-np.abs(2*fbm(3,4,4)-1)
r=np.sqrt(X**2+Z**2); rough=0.35+0.65*smooth(40,170,r)
H=34*(low-0.5)+rough*(11*(mid-0.5)+2.4*(hi-0.5)+16*(ridge**2.2-0.2))
H=(H-H.mean())/H.std()*8.6+19.0
H=np.maximum(H,0.5).astype(np.float32)

# ---------------- roads (Catmull-Rom splines through control points, metres)
def spline(pts,step=0.3):
    P=[np.array(p,float) for p in pts]; P=[P[0]*2-P[1]]+P+[P[-1]*2-P[-2]]; out=[]
    for i in range(1,len(P)-2):
        p0,p1,p2,p3=P[i-1],P[i],P[i+1],P[i+2]
        n=max(2,int(np.linalg.norm(p2-p1)/step))
        for t in np.linspace(0,1,n,endpoint=False):
            out.append(0.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t**3))
    out.append(P[-2]); return np.array(out)
R1=spline([(-30,-200),(-22,-140),(10,-92),(0,-42),(-10,0),(15,46),(40,92),(20,142),(45,200)])
R2=spline([(-200,26),(-140,42),(-80,10),(-10,0),(60,-26),(120,-10),(170,-56),(200,-30)])
R3=spline([(15,46),(90,62),(140,110),(200,122)])
roads=[R1,R2,R3]
def to_idx(p): return np.clip(np.round((p+HALF)/SP).astype(int),0,M-1)
mask=np.zeros((M,M),bool)
for R in roads:
    ij=to_idx(R); mask[ij[:,1],ij[:,0]]=True
d_px,(iy,ix)=ndi.distance_transform_edt(~mask,return_indices=True)
D=(d_px*SP).astype(np.float32)                                   # distance to nearest road centre line (m)
Hb=ndi.gaussian_filter(H,28/SP)                                   # road follows a heavily smoothed terrain
Hroad=Hb[iy,ix]
w=1.0-smooth(3.4,15.0,D); w=np.where(D<=3.4,1.0,w)
H=H*(1-w)+Hroad*w
H=H*(1-smooth(3.0,5.5,D)*(D<18))+ndi.gaussian_filter(H,5)*(smooth(3.0,5.5,D)*(D<18))   # smooth the embankments

# ---------------- props: huts on flat ground near roads
Hs=ndi.gaussian_filter(H,2.0); gy,gx=np.gradient(Hs,SP); S=np.sqrt(gx**2+gy**2)
Sb=ndi.uniform_filter(S,int(14/SP))
cand=np.argwhere((D>13)&(D<32)&(Sb<0.11)&(np.abs(X)<165)&(np.abs(Z)<165))
rng.shuffle(cand); huts=[]
for j,i in cand:
    p=np.array([X[j,i],Z[j,i]])
    if all(np.linalg.norm(p-np.array(h[:2]))>75 for h in huts): huts.append((p[0],p[1],0))
    if len(huts)==4: break
for k,(hx,hz,_) in enumerate(huts):
    j,i=to_idx(np.array([hx,hz]))[1],to_idx(np.array([hx,hz]))[0]
    hc=H[j,i]; rr=np.sqrt((X-hx)**2+(Z-hz)**2); wp=1.0-smooth(9.0,16.0,rr); wp=np.where(rr<=9.0,1.0,wp)
    H=H*(1-wp)+hc*wp
    huts[k]=(hx,hc,hz,float(rng.uniform(0,math.tau)))
Hs=ndi.gaussian_filter(H,2.0); gy,gx=np.gradient(Hs,SP); S=np.sqrt(gx**2+gy**2)

# ---------------- splat / detail map
nd=fbm(4,8,21); ng=fbm(3,16,22)
road_edge=D+(ng-0.5)*1.6
wroad=1.0-smooth(2.6,4.8,road_edge); wroad=np.where(road_edge<=2.6,1.0,wroad)
rock=smooth(0.52,0.92,S+0.12*(ng-0.5))*(1-wroad)
patch=smooth(0.60,0.70,nd)*0.85
dirt=np.maximum(wroad,patch)
for (hx,hz) in [(h[0],h[2]) for h in huts]:
    rr=np.sqrt((X-hx)**2+(Z-hz)**2); dirt=np.maximum(dirt,0.75*(1-smooth(5.5,10,rr)))
dirt=np.clip(np.maximum(dirt,0.35*smooth(0.30,0.5,S)),0,1)*(1-rock)
grass=np.clip(1-rock-dirt,0,1)
rut=(1-0.5*np.exp(-((D-0.95)/0.24)**2)*(D<2.4)*(0.65+0.35*fbm(3,60,23)))
rut=np.clip(rut*(1-0.18*wroad*fbm(2,40,24)),0,1)
det=np.stack([grass,dirt,rock,rut],-1)
det8=np.zeros((1024,1024,4),np.uint8)
for c in range(4):
    det8[:,:,c]=np.asarray(Image.fromarray((det[:,:,c]*255).astype(np.uint8)).resize((1024,1024),Image.BILINEAR))
open(os.path.join(OUT,'detail.bin'),'wb').write(det8.tobytes())

# ---------------- heights for the mesh / collision (257x257)
H257=H[::4,::4].astype(np.float32); assert H257.shape==(N,N)
open(os.path.join(OUT,'height.bin'),'wb').write(H257.tobytes())

# ---------------- object placement helpers
def look(arr,x,z):
    i=np.clip(np.round((x+HALF)/SP).astype(int),0,M-1); j=np.clip(np.round((z+HALF)/SP).astype(int),0,M-1); return arr[j,i]
def jitter_grid(step,jit,seed):
    r=np.random.default_rng(seed); gx_=np.arange(-HALF+step/2,HALF,step)
    gx2,gz2=np.meshgrid(gx_,gx_); x=gx2.ravel()+r.uniform(-jit,jit,gx2.size); z=gz2.ravel()+r.uniform(-jit,jit,gx2.size)
    ok=(np.abs(x)<HALF-3)&(np.abs(z)<HALF-3); return x[ok],z[ok],r
def write(name,rows):
    a=np.array(rows,np.float32).reshape(-1,6); open(os.path.join(OUT,name),'wb').write(a.tobytes()); print(name,len(a)); return a
hutxz=np.array([(h[0],h[2]) for h in huts])
def far_from_huts(x,z,rad):
    ok=np.ones_like(x,bool)
    for hx,hz in hutxz: ok&=np.hypot(x-hx,z-hz)>rad
    return ok

# trees
forest=smooth(0.48,0.60,fbm(3,5,11))
x,z,r_=jitter_grid(5.2,2.3,31)
y=look(H,x,z); dd=look(D,x,z); ss=look(S,x,z); fo=look(forest,x,z)
prob=0.62*fo+0.02
ok=(r_.random(x.size)<prob)&(dd>6.5)&(ss<0.6)&far_from_huts(x,z,13)
x,z,y=x[ok],z[ok],y[ok]; n=len(x)
trees=write('trees.bin',np.c_[x,y,z,r_.uniform(0.8,1.55,n)**1.0,r_.uniform(0,math.tau,n),r_.random(n)])
# grass
x,z,r_=jitter_grid(1.25,0.62,32)
gw=look(grass,x,z); dd=look(D,x,z); ss=look(S,x,z); fo=look(forest,x,z); y=look(H,x,z)
prob=gw**2*(0.55+0.45*(1-fo))
ok=(r_.random(x.size)<prob)&(dd>3.6)&(ss<0.62)
x,z,y=x[ok],z[ok],y[ok]; n=len(x)
if n>52000:
    sel=rng.choice(n,52000,replace=False); x,z,y=x[sel],z[sel],y[sel]; n=52000
write('grass.bin',np.c_[x,y,z,r_.uniform(0.75,1.45,n),r_.uniform(0,math.tau,n),r_.random(n)])
# bushes (blue-berry bushes in meadows)
x,z,r_=jitter_grid(9.0,4.0,33)
gw=look(grass,x,z); dd=look(D,x,z); ss=look(S,x,z); fo=look(forest,x,z); y=look(H,x,z)
ok=(r_.random(x.size)<0.28*gw)&(dd>5)&(ss<0.45)&far_from_huts(x,z,9)
x,z,y=x[ok],z[ok],y[ok]; n=len(x)
write('bushes.bin',np.c_[x,y,z,r_.uniform(0.7,1.5,n),r_.uniform(0,math.tau,n),r_.random(n)])
# rocks: steep slopes + along the roads
x,z,r_=jitter_grid(4.0,1.9,34)
dd=look(D,x,z); ss=look(S,x,z); y=look(H,x,z)
prob=np.where(ss>0.42,0.09,0.0)+np.where((dd>4.2)&(dd<11),0.05,0.0)+0.006
ok=(r_.random(x.size)<prob)&(dd>3.4)&far_from_huts(x,z,10)
x,z,y=x[ok],z[ok],y[ok]; n=len(x)
write('rocks.bin',np.c_[x,y,z,r_.uniform(0.5,2.6,n)**1.2,r_.uniform(0,math.tau,n),r_.random(n)])

# haystacks + gate + fences + spawn
hay=[]
for (hx,hy,hz,yaw) in huts[:3]:
    a=yaw+1.2; hay.append((hx+math.cos(a)*9.5,look(H,np.array([hx+math.cos(a)*9.5]),np.array([hz+math.sin(a)*9.5]))[0],hz+math.sin(a)*9.5,float(rng.uniform(1.4,2.0))))
# junction of R1/R2 is the control point (-10,0)
jx,jz=-10.0,0.0
jy=float(look(H,np.array([jx]),np.array([jz]))[0])
def arc_point(R,start_xz,dist):
    k0=int(np.argmin(np.hypot(R[:,0]-start_xz[0],R[:,1]-start_xz[1])))
    seg=np.hypot(*np.diff(R,axis=0).T); cum=np.r_[0,np.cumsum(seg)]
    k=int(np.searchsorted(cum,cum[k0]+dist)); k=min(k,len(R)-2)
    t=R[k+1]-R[k]; t/=np.linalg.norm(t); return R[k],t,k
gp,gt,_=arc_point(R1,(jx,jz),48)
gy_=float(look(H,np.array([gp[0]]),np.array([gp[1]]))[0])
gate_yaw=math.atan2(gt[0],gt[1])      # rotation about Y so the gate's local +Z points along the road
sp,st,_=arc_point(R1,(jx,jz),7)
spawn=(float(sp[0]),float(look(H,np.array([sp[0]]),np.array([sp[1]]))[0]),float(sp[1]))
spawn_yaw=math.atan2(-st[0],-st[1])    # camera yaw (looks along -Z at yaw 0) to look along the road
fence=[]
hx0,hz0=huts[0][0],huts[0][2]
_,_,k0=arc_point(R1,(hx0,hz0),0)
seg=np.hypot(*np.diff(R1,axis=0).T); cum=np.r_[0,np.cumsum(seg)]
for side in (-1,1):
    s=cum[k0]-34
    while s<cum[k0]+34:
        k=min(int(np.searchsorted(cum,s)),len(R1)-2); t=R1[k+1]-R1[k]; t/=np.linalg.norm(t); nrm=np.array([-t[1],t[0]])
        p=R1[k]+nrm*side*4.6; yy=float(look(H,np.array([p[0]]),np.array([p[1]]))[0])
        fence.append((p[0],yy,p[1],math.atan2(t[0],t[1]),1.0,0.0)); s+=2.4
fence=np.array(fence,np.float32); open(os.path.join(OUT,'fences.bin'),'wb').write(fence.tobytes()); print('fences',len(fence))

with open(os.path.join(ROOT,'scripts','map_meta.gd'),'w') as f:
    f.write("# Generated by tools/make_map.py - do not edit by hand\nextends RefCounted\n\n")
    f.write(f"const N: int = {N}\nconst SIZE: float = {SIZE}\n")
    f.write(f"const SPAWN: Vector3 = Vector3({spawn[0]:.2f}, {spawn[1]:.2f}, {spawn[2]:.2f})\nconst SPAWN_YAW: float = {spawn_yaw:.4f}\n")
    f.write(f"const GATE: Vector3 = Vector3({gp[0]:.2f}, {gy_:.2f}, {gp[1]:.2f})\nconst GATE_YAW: float = {gate_yaw:.4f}\n")
    f.write("const HUTS: Array = [\n"+",\n".join(f"\tVector4({h[0]:.2f}, {h[1]:.2f}, {h[2]:.2f}, {h[3]:.3f})" for h in huts)+"\n]\n")
    f.write("const HAY: Array = [\n"+",\n".join(f"\tVector4({h[0]:.2f}, {h[1]:.2f}, {h[2]:.2f}, {h[3]:.2f})" for h in hay)+"\n]\n")
slopes=S[::4,::4]; rg=np.array([look(H,R1[k:k+1,0],R1[k:k+1,1])[0] for k in range(0,len(R1),10)]); grade=np.abs(np.diff(rg))/(10*0.3)
print('slope >0.3:',round(float((slopes>0.3).mean()*100,),1),'% >0.55:',round(float((slopes>0.55).mean()*100),1),'% | R1 max grade',round(float(grade.max()),3),'mean',round(float(grade.mean()),3))
print('height range',H257.min(),H257.max(),'spawn',spawn,'gate',gp,'huts',[(round(h[0]),round(h[2])) for h in huts])

# ---------------- preview (hillshade + splat colours + objects)
col=np.zeros((M,M,3),np.float32)
col+=grass[...,None]*np.array([.36,.5,.2])+dirt[...,None]*np.array([.52,.4,.28])+rock[...,None]*np.array([.5,.5,.5])
col*=rut[...,None]
nrm=np.dstack([-gx,np.ones_like(gx),-gy]); nrm/=np.linalg.norm(nrm,axis=2,keepdims=True)
L=np.array([-0.5,0.75,-0.4]); L/=np.linalg.norm(L)
shade=np.clip(nrm@L,0.1,1.0)*1.25
img=np.clip(col*shade[...,None]*1.15,0,1)
im=Image.fromarray((img*255).astype(np.uint8)).resize((900,900))
from PIL import ImageDraw
dr=ImageDraw.Draw(im); sc=900/SIZE
for a,c in ((trees,(15,60,20)),(rocks:=np.fromfile(os.path.join(OUT,'rocks.bin'),np.float32).reshape(-1,6),(90,90,90))):
    for row in a[::1]:
        px=(row[0]+HALF)*sc; py=(row[2]+HALF)*sc; dr.ellipse((px-2,py-2,px+2,py+2),fill=c)
for h in huts: px=(h[0]+HALF)*sc; py=(h[2]+HALF)*sc; dr.rectangle((px-5,py-5,px+5,py+5),fill=(200,60,40))
px=(gp[0]+HALF)*sc; py=(gp[1]+HALF)*sc; dr.rectangle((px-4,py-4,px+4,py+4),fill=(255,255,0))
px=(spawn[0]+HALF)*sc; py=(spawn[2]+HALF)*sc; dr.ellipse((px-5,py-5,px+5,py+5),fill=(0,120,255))
im.save('/home/claude/w/map_preview.png')
