shader_type spatial;
// terrain_realistic.gdshader  -  gritty off-road terrain for the 75x75 m map (GL Compatibility safe).
// Fully procedural: dirt / grass / rock / mud are built from ONE tiling noise texture (noise_tex) and
// ONE baked surface map (surface_map) that scripts/map_builder.gd generates.
//
// surface_map : R = mud amount, G = rock amount, B = trail (compacted dirt), A = puddle potential (0..1)
// noise_tex   : R = fbm, G = cellular (rock facets / pebbles), B = second fbm
// PBR photo textures (assets/tex/pbr): grass / gravel (trails + dirt) / mud / rock, each with a normal map.
//               The old procedural colours stay as tints and as fallback when a texture is not set.
// Wetness     : global uniform road_wetness (written by TimeCycWeatherManager.gd) darkens the ground,
//               makes mud glossy and fills puddles. The CPU side (get_surface_state_at) uses the
//               same puddle formula, so what you SEE is what the physics uses.

global uniform float road_wetness;

uniform sampler2D surface_map : filter_linear, repeat_disable;
uniform sampler2D noise_tex : filter_linear_mipmap, repeat_enable;

uniform float map_size = 75.0;
uniform vec2 map_uv_scale = vec2(1.0, 1.0);    // set by map_builder (half-texel alignment)
uniform vec2 map_uv_offset = vec2(0.0, 0.0);
uniform float puddle_max = 0.20;               // metres, must match map_builder.PUDDLE_MAX
uniform float puddle_dry_bias = 0.17;          // metres, must match map_builder.PUDDLE_DRY_BIAS
uniform float rain_intensity : hint_range(0.0, 1.0) = 0.0;   // 1 while it rains (ripples in puddles)
uniform float normal_strength : hint_range(0.0, 2.0) = 1.0;
uniform float detail_distance = 30.0;          // beyond this the bump detail is skipped (Android speed)

uniform sampler2D grass_d : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D grass_n : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D gravel_d : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D gravel_n : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D mud_d : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D mud_n : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D rock_d : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D rock_n : hint_normal, filter_linear_mipmap, repeat_enable;
uniform float grass_scale = 0.42;     // texture tiles per metre
uniform float gravel_scale = 0.34;
uniform float mud_scale = 0.30;
uniform float rock_scale = 0.20;
uniform vec3 grass_tint : source_color = vec3(0.80, 1.00, 0.62);   // photo grass is autumn-ish: push it greener
uniform vec3 gravel_tint : source_color = vec3(1.0, 0.92, 0.84);
uniform vec3 mud_tint : source_color = vec3(1.0, 1.0, 1.0);
uniform vec3 rock_tint : source_color = vec3(0.92, 0.92, 0.95);
uniform float rock_desat : hint_range(0.0, 1.0) = 0.5;
uniform float tex_normal_strength : hint_range(0.0, 3.0) = 1.0;
uniform sampler2D rut_map : filter_linear, repeat_disable;   // R = dynamic ruts (tyre tracks / footprints) written by map_builder.press_rut()
uniform float rut_depth_m = 0.12;              // metres of a full rut, must match map_builder.RUT_DEPTH
uniform float aa_distance = 36.0;              // beyond this the anti-tiling second tap is skipped

uniform vec3 grass_a : source_color = vec3(0.16, 0.20, 0.06);
uniform vec3 grass_b : source_color = vec3(0.31, 0.33, 0.12);
uniform vec3 dirt_a : source_color = vec3(0.30, 0.21, 0.13);
uniform vec3 dirt_b : source_color = vec3(0.47, 0.37, 0.25);
uniform vec3 rock_a : source_color = vec3(0.27, 0.25, 0.23);
uniform vec3 rock_b : source_color = vec3(0.50, 0.46, 0.40);
uniform vec3 mud_dry : source_color = vec3(0.25, 0.17, 0.11);
uniform vec3 mud_wet : source_color = vec3(0.075, 0.05, 0.035);
uniform vec3 puddle_col : source_color = vec3(0.13, 0.11, 0.075);
uniform vec3 beach_sand_tint : source_color = vec3(1.20, 1.08, 0.82);

varying vec3 wpos;     // terrain chunks are built in world space (node at origin)
varying vec3 wnrm;
varying float cav;     // baked cavity / ambient occlusion (COLOR.r, 1 = open)
varying float vdist;

void vertex() {
	wpos = VERTEX;
	wnrm = NORMAL;
	cav = COLOR.r;
	vdist = length((MODELVIEW_MATRIX * vec4(VERTEX, 1.0)).xyz);
}

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

// photo texture sampled twice (second tap rotated + at another scale) so the tiling is not visible.
// textureGrad with gradients computed by the caller: safe inside the per-material branches below.
vec3 tex_aa(sampler2D t, vec2 p, vec2 dx, vec2 dy, float sc, float k, bool near_lod) {
	vec3 a = textureGrad(t, p * sc, dx * sc, dy * sc).rgb;
	if (near_lod && k > 0.02) {
		mat2 r = mat2(vec2(0.8, -0.6), vec2(0.6, 0.8));
		float s2 = sc * 0.37;
		vec3 b = textureGrad(t, r * p * s2 + vec2(0.31, 0.57), r * dx * s2, r * dy * s2).rgb;
		a = mix(a, b, k);
	}
	return a;
}

// tangent normal map -> world-space gradient offset (terrain is mostly facing up; u = +x, v = +z)
vec3 nm_offset(vec3 t) {
	vec3 nm = t * 2.0 - 1.0;
	return vec3(nm.x, 0.0, -nm.y) / max(nm.z, 0.25);
}

// bump height used for the procedural normal (cheap: 2 texture taps, +1 on rock)
float bump_h(vec2 p, float rock_w, float mud_w) {
	float fine = texture(noise_tex, p * 1.7).r;
	float mid = texture(noise_tex, p * 0.43).b;
	float h = fine * 0.45 + mid * 0.55;
	h *= (1.0 - 0.6 * mud_w);                              // mud is smoother
	if (rock_w > 0.05) {
		float facet = texture(noise_tex, p * 0.9).g;
		h = mix(h, facet * 1.4 + fine * 0.3, rock_w);
	}
	return h;
}

void fragment() {
	vec2 uvm = (wpos.xz + vec2(map_size * 0.5)) / map_size * map_uv_scale + map_uv_offset;
	vec4 sm = texture(surface_map, uvm);
	float mud = sm.r;
	float rock = sm.g;
	float trail = sm.b;
	float pot = sm.a;

	vec2 p = wpos.xz;
	vec3 n0 = normalize(wnrm);
	float wet = clamp(road_wetness, 0.0, 1.0);

	float low = texture(noise_tex, p * 0.09).r;
	float mid = texture(noise_tex, p * 0.31).b;
	float fine = texture(noise_tex, p * 1.9).r;
	float patchn = texture(noise_tex, p * 0.045 + vec2(0.37, 0.11)).b;

	// ---- material weights (ragged edges from noise)
	float rock_w = smoothstep(0.35, 0.7, max(rock, smoothstep(0.52, 0.78, 1.0 - n0.y)) + (mid - 0.5) * 0.4);
	float trail_w = smoothstep(0.35, 0.65, trail + (mid - 0.5) * 0.35);
	float dirt_w = max(trail_w, smoothstep(0.5, 0.68, patchn + (fine - 0.5) * 0.3) * 0.75);
	// wet weather turns dirt trails and puddle spots to mud (same formula as map_builder._mud_eff)
	float wet_mud = max(smoothstep(0.2, 0.7, pot) * 0.85, trail * 0.4) * smoothstep(0.15, 0.65, wet) * (1.0 - rock);
	float mud_e = max(mud, wet_mud);
	float mud_w = smoothstep(0.22, 0.55, mud_e + (fine - 0.5) * 0.3);

	// ---- dynamic ruts: tracks pressed into soft ground (bilinear 512^2 map, ~15 cm per texel)
	vec2 ruv = (wpos.xz + vec2(map_size * 0.5)) / map_size;
	float rut = texture(rut_map, ruv).r;
	float rut_w = smoothstep(0.03, 0.30, rut);
	vec2 rut_grad = vec2(0.0);
	if (rut > 0.004 && vdist < 45.0) {
		float e = 1.0 / 512.0;
		float rx = texture(rut_map, ruv + vec2(e, 0.0)).r;
		float rz = texture(rut_map, ruv + vec2(0.0, e)).r;
		rut_grad = vec2(rx - rut, rz - rut) * (512.0 / map_size) * rut_depth_m * 2.6;   // slope of the groove (metres per metre)
	}

	// ---- albedo (photo textures; each material is only sampled where it is actually visible)
	vec2 gdx = dFdx(p);
	vec2 gdy = dFdy(p);
	vec2 tdir = vec2(-n0.z, n0.x) / max(length(n0.xz), 0.001);        // along a cliff face
	vec2 side_uv = vec2(dot(p, tdir), wpos.y);
	vec2 sdx = dFdx(side_uv);
	vec2 sdy = dFdy(side_uv);
	bool near_lod = vdist < aa_distance;
	float tile_k = smoothstep(0.30, 0.70, patchn);
	float top_w = smoothstep(0.55, 0.85, n0.y);

	float sh_rock = rock_w * (1.0 - mud_w);
	float sh_dirt = dirt_w * (1.0 - rock_w) * (1.0 - mud_w);
	float sh_grass = (1.0 - dirt_w) * (1.0 - rock_w) * (1.0 - mud_w);

	vec3 col = vec3(0.0);
	if (sh_grass > 0.01) {
		vec3 grass = tex_aa(grass_d, p, gdx, gdy, grass_scale, tile_k, near_lod) * grass_tint;
		grass *= mix(vec3(1.0), mix(grass_a, grass_b, low) * 3.2, 0.35) * (0.80 + 0.40 * mid);
		col += grass * sh_grass;
	}
	if (sh_dirt > 0.01) {
		vec3 dirt = tex_aa(gravel_d, p, gdx, gdy, gravel_scale, tile_k, near_lod) * gravel_tint * (0.82 + 0.36 * mid);
		col += dirt * sh_dirt;
	}
	if (sh_rock > 0.01) {
		vec3 rockc = vec3(0.0);
		if (top_w > 0.02) {
			rockc += textureGrad(rock_d, p * rock_scale, gdx * rock_scale, gdy * rock_scale).rgb * top_w;
		}
		if (top_w < 0.98) {
			rockc += textureGrad(rock_d, side_uv * rock_scale, sdx * rock_scale, sdy * rock_scale).rgb * (1.0 - top_w);
		}
		float rl = dot(rockc, vec3(0.299, 0.587, 0.114));
		rockc = mix(rockc, vec3(rl), rock_desat) * rock_tint * (0.85 + 0.30 * low);
		col += rockc * sh_rock;
	}
	float mud_wetness = clamp(0.35 + 0.65 * wet, 0.0, 1.0);
	if (mud_w > 0.01) {
		vec3 mudt = textureGrad(mud_d, p * mud_scale, gdx * mud_scale, gdy * mud_scale).rgb * mud_tint;
		vec3 mudc = mudt * mix(0.95, 0.42, mud_wetness) * (0.85 + 0.30 * mid);
		col += mudc * mud_w;
	}
	// Wide pale sand ribbon between inland vegetation and the waterline.
	float coast_z = 5.0 + sin(wpos.x * 0.11) * 1.7 + sin(wpos.x * 0.29 + 0.8) * 0.65;
	float inland_from_shore = coast_z - wpos.z;
	float sand_w = smoothstep(-0.9, 0.35, inland_from_shore) * (1.0 - smoothstep(6.5, 10.0, inland_from_shore));
	vec3 sand_col = tex_aa(gravel_d, p, gdx, gdy, gravel_scale * 0.72, tile_k, near_lod) * beach_sand_tint;
	col = mix(col, sand_col, sand_w);
	col *= 1.0 - wet * (0.18 + 0.30 * dirt_w + 0.10 * rock_w) * (1.0 - sand_w * 0.75);
	col = mix(col, col * vec3(0.60, 0.50, 0.42), rut_w * (0.75 + 0.25 * wet) * (1.0 - sand_w));

	// ---- puddles (same formula as map_builder.get_surface_state_at)
	float depth = max(0.0, pot * puddle_max - (1.0 - wet) * puddle_dry_bias);
	float pmask = smoothstep(0.004, 0.02, depth) * (1.0 - rock_w * 0.8);
	pmask = max(pmask, smoothstep(0.35, 0.75, rut) * smoothstep(0.45, 0.9, wet) * 0.85);   // grooves fill with water when it is wet
	col = mix(col, puddle_col * (1.0 - clamp(depth * 3.0, 0.0, 0.45)), pmask * 0.9);
	col *= mix(0.55, 1.0, cav);

	// ---- procedural bump normal (world space, fades with distance)
	vec3 nw = n0;
	float fade = 1.0 - smoothstep(detail_distance * 0.6, detail_distance, vdist);
	if (fade > 0.01) {
		vec3 off = vec3(0.0);
		if (sh_grass > 0.05) {
			off += nm_offset(textureGrad(grass_n, p * grass_scale, gdx * grass_scale, gdy * grass_scale).xyz) * sh_grass;
		}
		if (sh_dirt > 0.05) {
			off += nm_offset(textureGrad(gravel_n, p * gravel_scale, gdx * gravel_scale, gdy * gravel_scale).xyz) * sh_dirt;
		}
		if (sh_rock * top_w > 0.05) {
			off += nm_offset(textureGrad(rock_n, p * rock_scale, gdx * rock_scale, gdy * rock_scale).xyz) * (1.4 * sh_rock * top_w);
		}
		if (mud_w > 0.05) {
			off += nm_offset(textureGrad(mud_n, p * mud_scale, gdx * mud_scale, gdy * mud_scale).xyz) * (1.2 * mud_w);
		}
		nw = normalize(n0 + off * 0.55 * tex_normal_strength * normal_strength * fade);
	}
	nw = normalize(nw + vec3(rut_grad.x, 0.0, rut_grad.y));                  // groove walls

	// ---- puddle surface: flat, mirror-like, rain ripples
	vec3 npud = vec3(0.0, 1.0, 0.0);
	if (pmask > 0.01 && rain_intensity > 0.01) {
		vec2 q = p * 3.2;
		vec2 cell = floor(q);
		vec2 f = fract(q) - 0.5;
		float hh = hash21(cell);
		float tt = fract(TIME * 0.8 + hh);
		float r = length(f);
		float ring = smoothstep(0.07, 0.0, abs(r - tt * 0.5)) * (1.0 - tt);
		vec2 rip = f / max(r, 0.001) * ring * 0.55 * rain_intensity;
		npud = normalize(vec3(rip.x, 1.0, rip.y));
	}
	nw = normalize(mix(nw, npud, pmask));
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);

	// ---- roughness / specular
	float rough = 0.95;
	rough = mix(rough, 0.90, dirt_w);
	rough = mix(rough, 0.80, rock_w);
	rough = mix(rough, mix(0.75, 0.20, mud_wetness), mud_w);          // wet mud = glossy
	rough = mix(rough, rough * 0.72, wet * (1.0 - mud_w) * 0.6);
	rough = mix(rough, 0.035, pmask);
	float spec = mix(0.30, 0.50, wet);
	spec = mix(spec, 0.95, pmask);

	ALBEDO = col;
	ROUGHNESS = clamp(rough, 0.03, 1.0);
	SPECULAR = spec;
	METALLIC = 0.0;
}
