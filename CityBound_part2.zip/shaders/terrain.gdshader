shader_type spatial;
// Terrain: grass / dirt-road / rock blended by a baked detail map, with normal maps,
// two-scale sampling against tiling, triplanar rock on cliffs and rain wetness.

global uniform float road_wetness;

uniform sampler2D detail_map : filter_linear_mipmap, repeat_disable;   // R grass, G dirt, B rock, A ruts/shade
uniform sampler2D grass_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D dirt_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D rock_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D grass_nrm : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D dirt_nrm : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D rock_nrm : hint_normal, filter_linear_mipmap, repeat_enable;
uniform float map_size = 400.0;
uniform float grass_scale = 0.22;
uniform float dirt_scale = 0.30;
uniform float rock_scale = 0.11;
uniform float normal_strength = 1.0;

varying vec3 wpos;
varying vec3 wnorm;

void vertex() {
	wpos = VERTEX;      // terrain chunks are built in world space
	wnorm = NORMAL;
	vec3 t = cross(NORMAL, vec3(0.0, 0.0, 1.0));
	if (length(t) < 0.001) {
		t = vec3(1.0, 0.0, 0.0);
	}
	t = normalize(t);
	TANGENT = t;
	BINORMAL = normalize(cross(NORMAL, t));
}

void fragment() {
	vec2 uvm = (wpos.xz + vec2(map_size * 0.5)) / map_size;
	vec4 dm = texture(detail_map, uvm);
	vec3 wgt = dm.rgb / (dm.r + dm.g + dm.b + 0.0001);
	vec2 p = wpos.xz;

	vec3 g1 = texture(grass_tex, p * grass_scale).rgb;
	vec3 g2 = texture(grass_tex, p * grass_scale * 0.137 + vec2(0.31, 0.57)).rgb;
	vec3 gcol = g1 * (0.62 + 0.75 * g2.g);

	vec3 d1 = texture(dirt_tex, p * dirt_scale).rgb;
	vec3 d2 = texture(dirt_tex, p * dirt_scale * 0.171 + vec2(0.7, 0.2)).rgb;
	vec3 dcol = d1 * (0.68 + 0.65 * d2.r);

	vec3 nw = pow(abs(wnorm), vec3(4.0));
	nw /= (nw.x + nw.y + nw.z);
	vec3 rcol = texture(rock_tex, wpos.zy * rock_scale).rgb * nw.x
		+ texture(rock_tex, wpos.xz * rock_scale).rgb * nw.y
		+ texture(rock_tex, wpos.xy * rock_scale).rgb * nw.z;

	vec3 albedo = gcol * wgt.r + dcol * wgt.g + rcol * wgt.b;
	albedo *= dm.a;

	float wet = clamp(road_wetness, 0.0, 1.0) * (wgt.g * 0.9 + wgt.b * 0.6 + wgt.r * 0.35);
	albedo *= mix(1.0, 0.6, wet);

	vec3 ng = texture(grass_nrm, p * grass_scale).xyz;
	vec3 nd = texture(dirt_nrm, p * dirt_scale).xyz;
	vec3 nr = mix(vec3(0.5, 0.5, 1.0), texture(rock_nrm, wpos.xz * rock_scale).xyz, smoothstep(0.45, 0.9, nw.y));
	NORMAL_MAP = ng * wgt.r + nd * wgt.g + nr * wgt.b;
	NORMAL_MAP_DEPTH = normal_strength;

	float base_rough = dot(wgt, vec3(0.95, 0.88, 0.8));
	ALBEDO = albedo;
	ROUGHNESS = mix(base_rough, base_rough * 0.45, wet);
	SPECULAR = mix(0.35, 0.7, wet);
}
