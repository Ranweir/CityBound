extends Node
## TimeCycWeatherManager.gd  (Godot 4.3, GDScript)
## GTA SA "timecyc.dat" style 24h time cycle + dynamic weather + global road wetness.
##
## Scene nodes used (all optional - missing ones are created automatically):
##   WorldEnvironment  -> Environment (background = Sky) -> Sky -> ProceduralSkyMaterial
##   DirectionalLight3D (shadow enabled)  = sun by day, moon by night
##   Camera3D (any current camera) = rain follows it

signal weather_changed(new_weather: int)
signal road_wetness_changed(value: float)
signal hour_changed(hour: int)

enum Weather { CLEAR_SUNNY, OVERCAST, RAINY, POST_RAIN }

@export_group("Scene References")
@export var world_environment: WorldEnvironment
@export var sun_light: DirectionalLight3D
@export var create_missing_nodes: bool = true

@export_group("Time")
@export_range(0.0, 24.0, 0.01) var time_of_day: float = 9.0
@export var day_length_seconds: float = 720.0   ## real seconds for one full 24h day
@export var time_running: bool = true
@export var sunrise_hour: float = 6.0
@export var sunset_hour: float = 19.0
@export_range(0.0, 1.2, 0.01) var sun_tilt: float = 0.45   ## radians, moves the sun arc off the east-west line

@export_group("Weather")
@export var start_weather: Weather = Weather.CLEAR_SUNNY
@export var auto_weather: bool = true
@export var weather_blend_speed: float = 0.35   ## higher = faster weather transitions
@export var enable_rain_particles: bool = true

@export_group("Road Wetness (time constants, seconds)")
@export var wet_time_rain: float = 12.0         ## rain: wetness rises toward 1.0
@export var wet_time_post_rain: float = 45.0    ## post-rain: keeps rising toward 1.0 (puddles)
@export var dry_time_clear: float = 20.0        ## clear sunny: dries toward 0.0
@export var dry_time_overcast: float = 150.0    ## overcast: dries very slowly

@export_group("Look")
@export var clouds_enabled: bool = true           ## low-cost sky cloud layer for visible weather changes
@export var fog_density_scale: float = 1.0       ## multiplies the time-of-day fog density

@export_group("Performance")
@export var update_interval: float = 0.2        ## sky/light/fog update rate (seconds)

## Global road wetness 0.0 (dry) .. 1.0 (soaked).
## Also published as global shader uniform "road_wetness" (use: global uniform float road_wetness;)
var road_wetness: float = 0.0
var weather: int = Weather.CLEAR_SUNNY

# Per-weather modifiers. gray = overcast desaturation, sun/amb = light multipliers,
# fog = fog density multiplier, expo = exposure multiplier, shadow = shadow opacity,
# disc = visibility of the sun disc, rain = rain intensity, cloud = cloud cover 0..1, cdark = cloud darkening (storm).
const WEATHER_PARAMS: Dictionary = {
	0: {"gray": 0.0, "sun": 1.0, "amb": 1.0, "fog": 1.0, "expo": 0.96, "shadow": 1.0, "disc": 1.0,  "rain": 0.0, "cloud": 0.30, "cdark": 0.0},
	1: {"gray": 0.0, "sun": 0.78, "amb": 0.88, "fog": 2.0, "expo": 0.92, "shadow": 0.85, "disc": 0.08, "rain": 0.0, "cloud": 0.92, "cdark": 0.42},
	2: {"gray": 0.0, "sun": 0.62, "amb": 0.76, "fog": 3.0, "expo": 0.88, "shadow": 0.75, "disc": 0.0,  "rain": 1.0, "cloud": 1.0, "cdark": 0.88},
	3: {"gray": 0.0, "sun": 0.88, "amb": 0.94, "fog": 1.7, "expo": 0.96, "shadow": 0.9, "disc": 0.45, "rain": 0.0, "cloud": 0.66, "cdark": 0.20},
}
const WEATHER_NAMES: Array = ["Clear", "Overcast", "Rain", "Post-rain"]

var _env: Environment = null
var _sky_mat: ShaderMaterial = null
var _keys: Array = []
var _wx: Dictionary = {}
var _accum: float = 0.0
var _weather_timer: float = 60.0
var _last_hour: int = -1
var _last_wet_sent: float = -1.0
var _rain: GPUParticles3D = null

# ------------------------------------------------------------------ lifecycle
func _ready() -> void:
	_build_keys()
	_ensure_nodes()
	_ensure_global_param()
	weather = start_weather
	_wx = (WEATHER_PARAMS[weather] as Dictionary).duplicate()
	_set_weights_onehot(weather)
	if enable_rain_particles:
		_create_rain()
	_reset_weather_timer()
	_apply_visuals()
	_publish_wetness(true)

func _process(delta: float) -> void:
	if time_running and day_length_seconds > 0.0:
		time_of_day = fposmod(time_of_day + delta * 24.0 / day_length_seconds, 24.0)
	var h: int = int(time_of_day)
	if h != _last_hour:
		_last_hour = h
		hour_changed.emit(h)

	_update_weather_blend(delta)
	_update_auto_weather(delta)
	_update_wetness(delta)
	_update_rain()

	_accum += delta
	if _accum >= update_interval:
		_accum = 0.0
		_apply_visuals()

# ------------------------------------------------------------------ public API
func set_weather(new_weather: int, instant: bool = false) -> void:
	new_weather = clampi(new_weather, 0, 3)
	var changed: bool = new_weather != weather
	weather = new_weather
	if instant:
		_wx = (WEATHER_PARAMS[weather] as Dictionary).duplicate()
		_set_weights_onehot(weather)
		_apply_visuals()
	_reset_weather_timer()
	if changed:
		weather_changed.emit(weather)

func set_time(hour: float) -> void:
	time_of_day = fposmod(hour, 24.0)
	_apply_visuals()

func get_time_string() -> String:
	var h: int = int(time_of_day)
	var m: int = int((time_of_day - float(h)) * 60.0)
	return "%02d:%02d" % [h, m]

## Smoothed rain intensity 0..1 (follows weather blending, so ripples fade in/out instead of popping).
func get_rain_amount() -> float:
	return clampf(float(_wx.get("rain", 0.0)), 0.0, 1.0)

## Standing-water level 0..1: 0 in Clear / Overcast (dry), builds up with road wetness during Rain / Post-rain.
func get_standing_water() -> float:
	return smoothstep(0.25, 1.0, road_wetness)

func get_weather_name() -> String:
	return WEATHER_NAMES[weather]

# ------------------------------------------------------------------ setup
func _ensure_nodes() -> void:
	if world_environment == null and create_missing_nodes:
		world_environment = WorldEnvironment.new()
		world_environment.name = "WorldEnvironment"
		add_child(world_environment)
	if world_environment != null:
		_env = world_environment.environment
		if _env == null:
			_env = Environment.new()
			world_environment.environment = _env
		_env.background_mode = Environment.BG_SKY
		if _env.sky == null:
			_env.sky = Sky.new()
		if not (_env.sky.sky_material is ShaderMaterial):
			var sm := ShaderMaterial.new()
			sm.shader = load("res://shaders/sky_clouds.gdshader")
			if clouds_enabled:
				sm.set_shader_parameter("noise_tex", _make_cloud_noise())
			_env.sky.sky_material = sm
		_sky_mat = _env.sky.sky_material as ShaderMaterial
		_env.sky.radiance_size = Sky.RADIANCE_SIZE_256         # sharper sky reflections on water / car paint / glass
		_env.sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
		# Keep the environment readable on Android GL Compatibility. The sky shader is
		# custom, so do not rely on sky radiance alone to illuminate the 3D scene.
		_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		_env.ambient_light_color = Color(0.72, 0.76, 0.82)
		_env.ambient_light_energy = 1.05
		_env.fog_enabled = true
		_env.fog_sky_affect = 0.15
		# --- GTA-SA-ENB style grading: filmic tonemap, bloom, punchy contrast / colour
		_env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
		_env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
		_env.tonemap_white = 6.0
		_env.glow_enabled = true      # restrained bloom for mobile
		_env.glow_intensity = 0.22
		_env.glow_strength = 0.48
		_env.glow_bloom = 0.015
		_env.glow_hdr_threshold = 1.35
		_env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
		_env.adjustment_enabled = true
		_env.adjustment_contrast = 1.04
		_env.adjustment_saturation = 1.07
	if sun_light == null and create_missing_nodes:
		sun_light = DirectionalLight3D.new()
		sun_light.name = "Sun"
		sun_light.directional_shadow_max_distance = 300.0
		add_child(sun_light)
	if sun_light != null:
		# Full-map real-time directional shadows. Four cascades distribute detail
		# from the bike to the far edges of the 200 x 200 m map. This is a
		# deliberately high GPU-cost preset for the POCO F1 target.
		sun_light.shadow_enabled = true
		sun_light.light_specular = 1.0
		sun_light.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
		sun_light.directional_shadow_max_distance = 300.0
		sun_light.shadow_blur = 1.0
		sun_light.directional_shadow_blend_splits = true

func _make_cloud_noise() -> Texture2D:
	# seamless fractal noise used by the cloud layer in sky_clouds.gdshader
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = 5
	n.fractal_gain = 0.5
	n.frequency = 0.009
	n.seed = 1337
	var img: Image = n.get_seamless_image(512, 512)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

func _ensure_global_param() -> void:
	var found: bool = false
	for n in RenderingServer.global_shader_parameter_get_list():
		if str(n) == "road_wetness":
			found = true
	if not found:
		RenderingServer.global_shader_parameter_add("road_wetness", RenderingServer.GLOBAL_VAR_TYPE_FLOAT, 0.0)

func _create_rain() -> void:
	_rain = GPUParticles3D.new()
	_rain.name = "Rain"
	_rain.amount = 1900
	_rain.lifetime = 1.05
	_rain.local_coords = false
	_rain.visibility_aabb = AABB(Vector3(-24.0, -20.0, -24.0), Vector3(48.0, 24.0, 48.0))
	_rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(22.0, 0.2, 22.0)
	pm.direction = Vector3(0.0, -1.0, 0.0)
	pm.spread = 2.0
	pm.initial_velocity_min = 18.0
	pm.initial_velocity_max = 23.0
	pm.gravity = Vector3(0.0, -4.0, 0.0)
	_rain.process_material = pm
	var quad := QuadMesh.new()
	quad.size = Vector2(0.032, 0.9)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.78, 0.84, 0.92, 0.42)
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	quad.material = mat
	_rain.draw_pass_1 = quad
	_rain.emitting = false
	add_child(_rain)

# ------------------------------------------------------------------ time-of-day keyframes (SA_DOX 2.0 timecyc.dat)
# Real GTA SA time cycle rows (COUNTRYSIDE: extrasunny / cloudy / rainy / sunny) from the SA_DOX 2.0 mod, 8 slots per weather.
# The four weathers are blended by _ww (weights follow the weather change), then the slots are interpolated by hour.
const SDX = preload("res://scripts/sadox_timecyc.gd")
const WEATHER_KEYS: Array = ["clear", "overcast", "rain", "post"]
var _ww: Array = [1.0, 0.0, 0.0, 0.0]      # blend weight of each weather's timecyc rows

func _build_keys() -> void:
	_keys = []
	for wk in WEATHER_KEYS:
		var rows: Array = []
		var src: Array = SDX.DATA[wk]
		for i in range(src.size()):
			var d: Dictionary = (src[i] as Dictionary).duplicate()
			d["h"] = float(SDX.HOURS[i])
			rows.append(d)
		_keys.append(rows)

func _set_weights_onehot(w: int) -> void:
	for i in range(4):
		_ww[i] = 1.0 if i == w else 0.0

# interpolate one weather's 8 slots at hour h
func _interp_rows(rows: Array, h: float) -> Dictionary:
	var n: int = rows.size()
	var next_i: int = -1
	for i in range(n):
		if float((rows[i] as Dictionary)["h"]) > h:
			next_i = i
			break
	var a: Dictionary
	var b: Dictionary
	var h_a: float
	var h_b: float
	if next_i == -1:
		a = rows[n - 1]
		b = rows[0]
		h_a = float(a["h"])
		h_b = float(b["h"]) + 24.0
	elif next_i == 0:
		a = rows[n - 1]
		b = rows[0]
		h_a = float(a["h"]) - 24.0
		h_b = float(b["h"])
	else:
		a = rows[next_i - 1]
		b = rows[next_i]
		h_a = float(a["h"])
		h_b = float(b["h"])
	var t: float = clampf((h - h_a) / maxf(h_b - h_a, 0.001), 0.0, 1.0)
	var out: Dictionary = {}
	for k in a.keys():
		if k == "h":
			continue
		var va = a[k]
		var vb = b[k]
		if va is Color:
			out[k] = (va as Color).lerp(vb as Color, t)
		else:
			out[k] = lerpf(float(va), float(vb), t)
	return out

func _night_value(h: float) -> float:
	if h < 12.0:
		return 1.0 - smoothstep(4.5, 6.0, h)
	return smoothstep(19.5, 21.5, h)

func _sample_keys(h: float) -> Dictionary:
	var acc: Dictionary = {}
	var wsum: float = 0.0
	for wi in range(4):
		var wgt: float = float(_ww[wi])
		if wgt < 0.002:
			continue
		var r: Dictionary = _interp_rows(_keys[wi], h)
		wsum += wgt
		for k in r.keys():
			var v = r[k]
			if acc.has(k):
				if v is Color:
					acc[k] = (acc[k] as Color) + (v as Color) * wgt
				else:
					acc[k] = float(acc[k]) + float(v) * wgt
			else:
				acc[k] = (v * wgt) if (v is Color) else float(v) * wgt
	for k in acc.keys():
		if acc[k] is Color:
			acc[k] = (acc[k] as Color) / maxf(wsum, 0.0001)
		else:
			acc[k] = float(acc[k]) / maxf(wsum, 0.0001)
	var night: float = _night_value(h)
	var top: Color = acc["top"]
	var bot: Color = acc["bot"]
	var amb: Color = acc["amb"]
	var core: Color = acc["core"]
	var maxc: float = maxf(core.r, maxf(core.g, core.b))
	var sun_col: Color = Color(1, 1, 1)
	var sun_e: float = 0.0
	if maxc > 0.03:
		sun_col = Color(core.r / maxc, core.g / maxc, core.b / maxc)
		sun_e = maxc * 1.5
	sun_col = sun_col.lerp(Color(0.54, 0.64, 1.0), night)       # moon light
	sun_e = maxf(sun_e * (1.0 - night), 0.22 * night)
	var out: Dictionary = {}
	out["top"] = top
	out["hor"] = bot
	out["gh"] = bot.lerp(amb, 0.3) * 0.85
	out["gb"] = amb * 0.30 + Color(0.03, 0.025, 0.015)
	out["sun"] = sun_col
	out["sun_e"] = sun_e
	out["amb"] = amb
	out["amb_e"] = 1.1 * (1.0 - 0.6 * night)
	out["fog"] = bot
	out["fog_d"] = 0.0045 * (1.0 + 0.5 * night)
	out["expo"] = 1.0 + 0.1 * night
	out["shdw"] = clampf(float(acc["shdw"]) / 255.0 * 1.65, 0.0, 1.0)
	out["night"] = night
	out["water"] = acc["water"]
	out["low"] = acc["low"]
	out["bcl"] = acc["bcl"]
	return out

# ------------------------------------------------------------------ applying everything
func _lum(c: Color) -> float:
	return c.r * 0.3 + c.g * 0.59 + c.b * 0.11

func _apply_visuals() -> void:
	if _env == null or _sky_mat == null:
		return
	var s: Dictionary = _sample_keys(time_of_day)
	var gray: float = float(_wx["gray"])
	var lh: float = _lum(s["hor"])

	# --- sky (overcast pulls colours toward a flat grey)
	var top: Color = (s["top"] as Color).lerp(Color(lh * 0.75, lh * 0.78, lh * 0.84), gray)
	var hor: Color = (s["hor"] as Color).lerp(Color(lh * 0.95, lh * 0.97, lh * 1.0), gray)
	var gh: Color = (s["gh"] as Color).lerp(Color(lh * 0.9, lh * 0.92, lh * 0.95), gray)
	_sky_mat.set_shader_parameter("sky_top", top)
	_sky_mat.set_shader_parameter("sky_horizon", hor)
	_sky_mat.set_shader_parameter("ground_horizon", gh)
	_sky_mat.set_shader_parameter("ground_bottom", s["gb"])
	_sky_mat.set_shader_parameter("game_time", time_of_day)          # SA_DOX atmospheric scattering inputs
	_sky_mat.set_shader_parameter("night_value", float(s["night"]))
	_sky_mat.set_shader_parameter("sun_color", s["sun"])

	# --- sun (day) / moon (night) position
	var pos: Vector3 = _light_position(time_of_day)
	var fade: float = smoothstep(0.0, 0.05, pos.y)     # fade out as it touches the horizon
	if sun_light != null:
		sun_light.basis = Basis.looking_at(-pos, Vector3.UP)
		sun_light.light_color = (s["sun"] as Color).lerp(Color(0.85, 0.9, 1.0), gray * 0.6)
		# Retain a daylight illumination floor at dawn/dusk; this avoids a bright sky
		# with an almost unlit world on mobile renderers.
		var daylight_floor: float = lerpf(0.28, 0.0, float(s["night"]))
		var effective_sun: float = maxf(float(s["sun_e"]), daylight_floor)
		sun_light.light_energy = effective_sun * float(_wx["sun"]) * maxf(fade, 0.35 * (1.0 - float(s["night"])))
		sun_light.shadow_opacity = minf(clampf(float(s["shdw"]) * float(_wx["shadow"]), 0.0, 1.0), 0.68)

	# --- sun disc in the sky: bigger near the horizon, hidden by clouds/rain
	var low: float = 1.0 - clampf(pos.y * 3.0, 0.0, 1.0)
	_sky_mat.set_shader_parameter("sun_vis", float(_wx["disc"]))
	_sky_mat.set_shader_parameter("sun_radius", 0.04 * (1.0 + low * 0.6))

	# --- clouds: cover + colours follow weather and time of day
	var sun_c: Color = s["sun"]
	var lit_k: float = clampf(float(s["sun_e"]), 0.18, 1.3)
	var cdark: float = float(_wx["cdark"])
	var lit_col: Color = sun_c.lerp(Color(lh, lh, lh), gray * 0.6) * lit_k * 1.15
	var amb_c: Color = s["amb"]
	var shade_col: Color = amb_c * clampf(float(s["amb_e"]), 0.3, 1.2) * 0.62
	_sky_mat.set_shader_parameter("clouds_on", clouds_enabled)
	_sky_mat.set_shader_parameter("cloud_cover", float(_wx["cloud"]))
	_sky_mat.set_shader_parameter("cloud_lit", lit_col.lerp(Color(0.25, 0.26, 0.29) * lit_k, cdark))
	_sky_mat.set_shader_parameter("cloud_shade", shade_col.lerp(Color(0.10, 0.11, 0.13) * lit_k, cdark))
	# Evolve cloud formations through the day: cumulus by day, layered dramatic clouds at golden hour.
	var golden: float = 1.0 - clampf(absf(time_of_day - 17.7) / 2.2, 0.0, 1.0)
	var sunrise: float = 1.0 - clampf(absf(time_of_day - 7.0) / 1.8, 0.0, 1.0)
	var storm_factor: float = float(_wx["cloud"]) * 0.35 + cdark * 0.25
	var cloud_mix: float = clampf(golden * 0.92 + sunrise * 0.28 + storm_factor, 0.0, 1.0)
	_sky_mat.set_shader_parameter("cloud_style", cloud_mix)
	# Rays strongest at low sun through broken clouds; subdued at noon and during heavy rain.
	var sun_height: float = clampf(pos.y, 0.0, 1.0)
	var broken_clouds: float = 1.0 - clampf(absf(float(_wx["cloud"]) - 0.72) / 0.72, 0.0, 1.0)
	var ray_strength: float = (0.12 + golden * 0.62 + sunrise * 0.34) * broken_clouds
	ray_strength *= (1.0 - float(_wx["rain"]) * 0.82) * (1.0 - float(s["night"]))
	ray_strength *= (1.0 - sun_height * 0.62)
	_sky_mat.set_shader_parameter("god_ray_strength", clampf(ray_strength, 0.0, 0.72))

	# --- ambient, fog, exposure
	var amb: Color = s["amb"]
	var neutral_amb: Color = amb.lerp(Color(_lum(amb), _lum(amb), _lum(amb)), gray * 0.5)
	# Floor ambient RGB and energy so vegetation/terrain do not collapse to black
	# when the time-cycle data contains very dark dawn/night samples.
	_env.ambient_light_color = Color(maxf(neutral_amb.r, 0.32), maxf(neutral_amb.g, 0.34), maxf(neutral_amb.b, 0.38))
	_env.ambient_light_energy = maxf(float(s["amb_e"]) * float(_wx["amb"]), 1.0)
	var fog: Color = s["fog"]
	_env.fog_light_color = fog.lerp(Color(lh * 0.9, lh * 0.93, lh * 0.98), gray)
	_env.fog_density = float(s["fog_d"]) * float(_wx["fog"]) * fog_density_scale
	_env.tonemap_exposure = float(s["expo"]) * float(_wx["expo"])

## Position of the light source in the sky. Sun arcs east->west between sunrise and sunset,
## the moon takes the same arc during the night.
func _light_position(h: float) -> Vector3:
	var a: float
	if h >= sunrise_hour and h < sunset_hour:
		a = (h - sunrise_hour) / (sunset_hour - sunrise_hour) * PI
	else:
		var night_len: float = 24.0 - (sunset_hour - sunrise_hour)
		var hh: float = h - sunset_hour
		if hh < 0.0:
			hh += 24.0
		a = hh / night_len * PI
	return Vector3(cos(a), sin(a) * cos(sun_tilt), sin(a) * sin(sun_tilt)).normalized()

# ------------------------------------------------------------------ weather logic
func _update_weather_blend(delta: float) -> void:
	var tgt: Dictionary = WEATHER_PARAMS[weather]
	var k: float = 1.0 - exp(-weather_blend_speed * delta)
	for key in tgt.keys():
		_wx[key] = lerpf(float(_wx[key]), float(tgt[key]), k)
	for wi in range(4):
		_ww[wi] = lerpf(float(_ww[wi]), 1.0 if wi == weather else 0.0, k)

func _reset_weather_timer() -> void:
	match weather:
		Weather.CLEAR_SUNNY:
			_weather_timer = randf_range(90.0, 180.0)
		Weather.OVERCAST:
			_weather_timer = randf_range(40.0, 80.0)
		Weather.RAINY:
			_weather_timer = randf_range(60.0, 120.0)
		_:
			_weather_timer = randf_range(40.0, 70.0)

func _update_auto_weather(delta: float) -> void:
	if not auto_weather:
		return
	_weather_timer -= delta
	if _weather_timer > 0.0:
		return
	var nxt: int = Weather.CLEAR_SUNNY
	match weather:
		Weather.CLEAR_SUNNY:
			nxt = Weather.OVERCAST
		Weather.OVERCAST:
			nxt = Weather.RAINY if randf() < 0.65 else Weather.CLEAR_SUNNY
		Weather.RAINY:
			nxt = Weather.POST_RAIN
		_:
			nxt = Weather.CLEAR_SUNNY if randf() < 0.8 else Weather.OVERCAST
	set_weather(nxt)

# ------------------------------------------------------------------ road wetness
func _update_wetness(delta: float) -> void:
	var target: float = 0.0
	var tau: float = dry_time_clear
	match weather:
		Weather.CLEAR_SUNNY:
			target = 0.0
			tau = dry_time_clear
		Weather.OVERCAST:
			target = 0.0
			tau = dry_time_overcast
		Weather.RAINY:
			target = 1.0
			tau = wet_time_rain
		Weather.POST_RAIN:
			target = 1.0
			tau = wet_time_post_rain
	road_wetness = lerpf(road_wetness, target, 1.0 - exp(-delta / maxf(tau, 0.01)))
	if absf(road_wetness - target) < 0.002:
		road_wetness = target
	_publish_wetness(false)

func _publish_wetness(force: bool) -> void:
	if force or absf(road_wetness - _last_wet_sent) > 0.004 or (road_wetness == 0.0 and _last_wet_sent != 0.0) or (road_wetness == 1.0 and _last_wet_sent != 1.0):
		_last_wet_sent = road_wetness
		RenderingServer.global_shader_parameter_set("road_wetness", road_wetness)
		road_wetness_changed.emit(road_wetness)

# ------------------------------------------------------------------ rain
func _update_rain() -> void:
	if _rain == null:
		return
	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam != null:
		_rain.global_position = cam.global_position + Vector3(0.0, 12.0, 0.0)
	var r: float = float(_wx["rain"])
	_rain.emitting = r > 0.03
	_rain.amount_ratio = clampf(r, 0.02, 1.0)
