extends Node3D
# City Bound test map: hilly offroad terrain (see scripts/world_builder.gd) + time cycle / weather.

const MapBuilder = preload("res://scripts/map_builder.gd")
const CarMetaS = preload("res://scripts/car_meta.gd")
const BikeMetaS = preload("res://scripts/bike_meta.gd")
const TruckMetaS = preload("res://scripts/truck_meta.gd")

var world = null
var player = null   # player.gd instance
var car = null      # car.gd instance
var bike = null     # bike.gd instance
var truck = null    # truck.gd instance (KamAZ-5320 6x6)
var vehicle = null  # the vehicle (car, bike or truck) the player is driving right now, null = on foot
var look_idle: float = 10.0
var ui = null       # touch_ui.gd instance
var tc = null       # TimeCycWeatherManager instance
var cam_pivot: Node3D = null
var spring: SpringArm3D = null
var cam: Camera3D = null
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var cam_base_len: float = 4.2      # default camera distance of the current mode (on foot / car / bike)
var cam_zoom: float = 1.0          # user zoom multiplier (+ / - buttons on screen)
var hud: Label = null
var hud_timer: float = 0.0
var base_accel: Dictionary = {}   # vehicle -> accel / max_speed on dry ground (mud scales them)
var base_max: Dictionary = {}
var sink: Dictionary = {}
var surf: Dictionary = {}
var water_fx: Dictionary = {}     # vehicle -> water_fx.gd instance (splash, wake, ripples)
var wade: Dictionary = {}         # vehicle -> smoothed top-speed factor while wading
var pond_base: float = 0.0        # pond level before the rain raises it
var pond_mesh: MeshInstance3D = null
var _wsync: float = 0.0
var player_fx_on: bool = false     # the character's own water effects are running
var rut_last: Dictionary = {}      # wheel id -> last world position a rut was pressed at
var foot_dist: float = 0.0         # distance walked since the last footprint
var foot_side: float = 1.0         # which foot comes next

func _ready() -> void:
	_make_timecyc()
	world = MapBuilder.new()
	world.name = "World"
	world.weather_manager = tc      # wetness / rain drive puddles + mud physics
	add_child(world)                # builds the map in its _ready()
	_setup_water_sync()
	_make_player()
	_make_car()
	_make_bike()
	_make_truck()
	_make_water_fx()
	_make_camera()
	_make_ui()
	car.ui = ui
	bike.ui = ui
	truck.ui = ui

# Weather -> water. main.gd drives rain ripples + pond level from TimeCycWeatherManager (smoothed floats, no string
# compares); map_builder's own 0.25 s weather polling is switched off so the two never fight.
func _setup_water_sync() -> void:
	if world == null:
		return
	world.set_process(false)
	if "_pond_level" in world:
		pond_base = float(world._pond_level)
	pond_mesh = world.get_node_or_null("PondWater") as MeshInstance3D

func _sync_water(delta: float) -> void:
	_wsync += delta
	if _wsync < 0.1 or tc == null or world == null:
		return
	_wsync = 0.0
	var rain: float = tc.get_rain_amount()
	if world.terrain_mat != null:
		world.terrain_mat.set_shader_parameter("rain_intensity", rain)
	if world.water_mat != null:
		world.water_mat.set_shader_parameter("rain_intensity", rain)
	# pond rises a few cm while wet. Physics (get_surface_state_at) and the water mesh share the same level.
	var rise: float = 0.06 * tc.get_standing_water()
	if "_pond_level" in world:
		world._pond_level = pond_base + rise
	if pond_mesh != null:
		pond_mesh.position.y = rise

func _make_timecyc() -> void:
	tc = load("res://scripts/TimeCycWeatherManager.gd").new()
	tc.name = "TimeCycWeatherManager"
	tc.time_of_day = 16.6
	tc.day_length_seconds = 1080.0
	tc.fog_density_scale = 0.45
	add_child(tc)   # creates WorldEnvironment + sun + rain by itself
	if tc.sun_light != null:
		tc.sun_light.directional_shadow_max_distance = 90.0

func _on_debug(id: int) -> void:
	if id >= 0 and id <= 3:
		tc.set_weather(id)
	elif id == 4:
		tc.set_time(tc.time_of_day + 3.0)

func _make_player() -> void:
	player = load("res://scripts/player.gd").new()
	player.position = world.spawn_position
	player.world = world            # wading physics on foot
	add_child(player)
	cam_yaw = world.spawn_yaw
	player.model.rotation.y = cam_yaw + PI

func _make_car() -> void:
	car = load("res://scripts/car.gd").new()
	var fwd := Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw))
	car.position = world.get_safe_position(world.spawn_position + fwd * 5.5, 0.4)   # above ground AND water
	car.rotation.y = world.spawn_yaw
	car.world = world
	add_child(car)
	base_accel[car] = car.accel
	base_max[car] = car.max_speed
	sink[car] = 0.0

func _make_bike() -> void:
	# NRG-500 parked next to the F-150, a few metres to the right of the spawn point
	bike = load("res://scripts/bike.gd").new()
	var fwd := Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw))
	var right: Vector3 = fwd.cross(Vector3.UP)
	bike.position = world.get_safe_position(world.spawn_position + fwd * 3.0 + right * 3.2, 0.4)
	bike.rotation.y = world.spawn_yaw
	bike.world = world
	add_child(bike)
	base_accel[bike] = bike.accel
	base_max[bike] = bike.max_speed
	sink[bike] = 0.0

func _make_truck() -> void:
	# KamAZ-5320 6x6 parked on the trail ahead of the F-150 (about 15 m along the main path from the spawn point)
	truck = load("res://scripts/truck.gd").new()
	var pos: Vector3 = world.spawn_position + Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw)) * 15.0
	var yaw: float = world.spawn_yaw
	var path: PackedVector2Array = world._main_path
	if path.size() > 20:
		var sp := Vector2(world.spawn_position.x, world.spawn_position.z)
		var i0: int = 0
		var best: float = 1.0e9
		for i in range(path.size()):
			var d: float = path[i].distance_to(sp)
			if d < best:
				best = d
				i0 = i
		var ia: int = mini(i0 + 13, path.size() - 5)
		var a: Vector2 = path[ia]
		var b: Vector2 = path[ia + 4]
		pos = Vector3(a.x, 0.0, a.y)
		yaw = atan2(-(b.x - a.x), -(b.y - a.y))
	truck.position = world.get_safe_position(pos, 0.5)
	truck.rotation.y = yaw
	truck.world = world
	add_child(truck)
	base_accel[truck] = truck.accel
	base_max[truck] = truck.max_speed
	sink[truck] = 0.0

func _make_water_fx() -> void:
	var CarM = preload("res://scripts/car_meta.gd")
	var BikeM = preload("res://scripts/bike_meta.gd")
	var sun = tc.sun_light if tc != null else null
	var fx_car = load("res://scripts/water_fx.gd").new()
	fx_car.name = "WaterFxCar"
	add_child(fx_car)
	fx_car.setup(car, world, sun, CarM.WHEELS, Vector3(0.0, 0.0, -3.2), 3.2, 1.1, 1.0, 0)
	water_fx[car] = fx_car
	var fx_bike = load("res://scripts/water_fx.gd").new()
	fx_bike.name = "WaterFxBike"
	add_child(fx_bike)
	fx_bike.setup(bike, world, sun, [BikeM.WHEEL_F, BikeM.WHEEL_R], Vector3(0.0, 0.0, -1.0), 1.0, 0.35, 0.55, 1)
	water_fx[bike] = fx_bike
	var fx_truck = load("res://scripts/water_fx.gd").new()
	fx_truck.name = "WaterFxTruck"
	add_child(fx_truck)
	fx_truck.setup(truck, world, sun, TruckMetaS.WHEELS, Vector3(0.0, 0.0, -3.6), 3.6, 1.5, 1.45, 3, 12.0)
	water_fx[truck] = fx_truck
	# the character wading: feet splash, rings, waist wake and a small V wake in the pond (pond shader slot veh2)
	var fx_p = load("res://scripts/water_fx.gd").new()
	fx_p.name = "WaterFxPlayer"
	add_child(fx_p)
	fx_p.setup(player, world, sun, [Vector3(-0.2, 0.0, 0.0), Vector3(0.2, 0.0, 0.0)], Vector3(0.0, 0.0, -0.45), 0.45, 0.4, 0.3, 2, 2.5, true)
	water_fx[player] = fx_p

# the closest vehicle the player is allowed to get into (null = none in range)
func _nearest_vehicle():
	var best = null
	var best_d: float = 1.0e9
	for v in [car, bike, truck]:
		if v == null:
			continue
		var d: float = player.global_position.distance_to(v.global_position)
		if d < v.enter_range and d < best_d:
			best = v
			best_d = d
	return best

func _on_action() -> void:
	if vehicle != null:
		_exit_vehicle()
	else:
		var v = _nearest_vehicle()
		if v != null:
			_enter_vehicle(v)

func _enter_vehicle(v) -> void:
	vehicle = v
	v.driven = true
	if v == bike:
		player.start_riding(bike)        # rider sits on the bike
	else:
		player.set_active(false)
	spring.add_excluded_object(v.get_rid())
	cam_base_len = 8.5 if v == car else (11.5 if v == truck else 5.8)
	cam_pitch = -0.22
	ui.jump_pressed = false

func _exit_vehicle() -> void:
	var v = vehicle
	vehicle = null
	v.driven = false
	var left: Vector3 = -v.forward_vector().cross(Vector3.UP)
	if v == bike:
		player.stop_riding()
	else:
		player.set_active(true)
	player.global_position = v.global_position + left * (1.5 if v == bike else (3.4 if v == truck else 2.7)) + Vector3(0.0, 0.8, 0.0)
	player.model.rotation.y = v.heading + PI
	spring.remove_excluded_object(v.get_rid())
	cam_base_len = 4.2
	cam_pitch = -0.28
	ui.jump_pressed = false

func _make_camera() -> void:
	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam_pivot.global_position = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	spring = SpringArm3D.new()
	spring.spring_length = 4.2
	spring.margin = 0.25
	spring.collision_mask = 1
	cam_pivot.add_child(spring)
	spring.add_excluded_object(player.get_rid())
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 600.0
	# Vehicle meshes (F-150, NRG-500 and KamAZ) are intentionally on layer 20
	# so reflection probes can exclude them. The camera must still render that layer.
	cam.cull_mask = 0xFFFFF
	spring.add_child(cam)
	cam.make_current()
	player.cam_pivot = cam_pivot

func _make_vignette() -> void:
	# soft dark corners (cheap: one transparent gradient, no screen reads)
	var vl := CanvasLayer.new()
	vl.layer = 0
	add_child(vl)
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	gr.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0.6)])
	var gt := GradientTexture2D.new()
	gt.gradient = gr
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 64
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	vl.add_child(tr)

func _make_ui() -> void:
	_make_vignette()
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = load("res://scripts/touch_ui.gd").new()
	layer.add_child(ui)
	player.ui = ui
	ui.debug_pressed.connect(_on_debug)
	ui.action_pressed.connect(_on_action)
	hud = Label.new()
	hud.position = Vector2(20.0, 14.0)
	hud.add_theme_font_size_override("font_size", 22)
	hud.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hud.add_theme_constant_override("outline_size", 6)
	layer.add_child(hud)

# Tyre tracks and footprints: every wheel of a moving vehicle (and the walking character) presses into soft ground
# (mud, wet dirt). map_builder keeps the rut map; the terrain shader draws it, get_surface_state_at() sinks wheels into it.
func _stamp_ruts(delta: float) -> void:
	for k in range(3):
		var v = car if k == 0 else (bike if k == 1 else truck)
		var pts: Array = CarMetaS.WHEELS if k == 0 else ([BikeMetaS.WHEEL_F, BikeMetaS.WHEEL_R] if k == 1 else TruckMetaS.WHEELS)
		var rad: float = 0.30 if k == 0 else (0.13 if k == 1 else truck.rut_radius)
		var power: float = 1.1 if k == 0 else (0.6 if k == 1 else truck.rut_power)
		var dmul: float = truck.rut_depth_mul if k == 2 else 1.0       # the heavy KamAZ digs deeper than the ground allows a light car
		var moving: bool = absf(v.speed) > 0.5
		var yb := Basis(Vector3.UP, v.rotation.y)
		for i in range(pts.size()):
			var lp: Vector3 = pts[i]
			var wp: Vector3 = v.global_position + yb * Vector3(lp.x, 0.0, lp.z)
			var key: int = k * 10 + i
			if moving:
				if rut_last.has(key):
					world.press_rut_line(rut_last[key], wp, rad, power * delta, dmul)
				rut_last[key] = wp
			else:
				rut_last.erase(key)
	if vehicle == null and player.is_on_floor():
		var hv := Vector2(player.velocity.x, player.velocity.z)
		if hv.length() > 0.25:
			foot_dist += hv.length() * delta
			if foot_dist > 0.55:
				foot_dist = 0.0
				foot_side = -foot_side
				var side := Vector3(hv.y, 0.0, -hv.x).normalized()
				world.press_rut(player.global_position + side * (0.13 * foot_side), 0.13, 0.7)
	world.flush_ruts(delta)

func _physics_process(delta: float) -> void:
	if car == null or bike == null or truck == null or world == null:
		return
	_stamp_ruts(delta)
	for v in [car, bike, truck]:
		var is_truck: bool = v == truck
		var is_bike: bool = v == bike
		var s: Dictionary = world.get_surface_state_at(v.global_position)
		var trac: float = s["traction_multiplier"]
		# deep water: the lorry sits much higher on its big wheels, so the same water is "shallower" for it
		var dn: float = clampf(float(s["water_depth"]) / (1.25 if is_truck else 0.9), 0.0, 1.0)  # 0 = dry, 1 = 90 cm+ of water (125 cm for the KamAZ)
		# top speed collapses as the water gets deep; smoothed so the vehicle's speed clamp follows the drag (no hard stop)
		var wk_floor: float = 0.42 if is_bike else (0.72 if is_truck else 0.55)
		var wk: float = lerpf(float(wade.get(v, 1.0)), lerpf(1.0, wk_floor, dn), 1.0 - exp(-2.5 * delta))
		wade[v] = wk
		# 4x4 car keeps pulling in mud / water; the 6x6 truck pulls even harder (huge low-end torque); the 2-wheel bike loses more
		var pull_floor: float = 0.5 if is_bike else (0.9 if is_truck else 0.68)
		var spd_abs: float = absf(v.speed)
		# aquaplaning: a thin sheet of water (3-45 cm) at speed lifts the tyres off the ground; deep water floats them
		var thin: float = smoothstep(0.02, 0.08, float(s["water_depth"])) * (1.0 - smoothstep(0.25, 0.55, float(s["water_depth"])))
		var aqua: float = thin * smoothstep(9.0, 26.0, spd_abs) * (0.5 if is_truck else 1.0)     # nine tonnes do not aquaplane easily
		var float_k: float = dn * dn
		var trac_tyre: float = lerpf(trac, 1.0, 0.18) if is_truck else trac                          # big tyres, lots of weight: a bit more bite
		v.grip = trac_tyre * (1.0 - 0.4 * aqua) * lerpf(1.0, 0.6, float_k)      # tyres use the same surface grip (drifting on mud / wet ground / water)
		# 4x4 / 6x6: all wheels pull, so the engine side sees much better traction than the tyres' grip alone (mud / water / wet trails)
		var trac_eng: float = lerpf(trac, 1.0, 0.8) if is_truck else (trac if is_bike else lerpf(trac, 1.0, 0.6))
		v.accel = base_accel[v] * lerpf(pull_floor, 1.0, trac_eng) * lerpf(1.0, 0.85, dn)
		v.max_speed = maxf(base_max[v] * lerpf(pull_floor + 0.05, 1.0, trac_eng) * wk, 4.0)      # never below a crawl -> never stuck
		# mud / water drag: the car ploughs through, the bike suffers, the heavy truck digs in (mud_drag_mul) but its torque keeps it going
		var drag_k: float = 1.0 if is_bike else (0.55 * truck.mud_drag_mul if is_truck else 0.55)
		v.speed *= maxf(0.0, 1.0 - float(s["drag_factor"]) * drag_k * delta)
		# hydrodynamic resistance: grows with speed squared and with depth (fast entry slows hard, then wading crawl)
		var hyd: float = minf(absf(v.speed), 0.03 * dn * v.speed * v.speed * delta)
		v.speed -= signf(v.speed) * hyd
		# water holds the hull: sideways sliding is killed, turning gets heavy and sluggish in deep water
		if "lat_speed" in v:
			v.lat_speed *= maxf(0.0, 1.0 - 2.2 * dn * delta)
		if "yaw_rate" in v:
			v.yaw_rate *= maxf(0.0, 1.0 - 1.1 * dn * delta)
		# bike: past ~40 cm the engine drowns, the bike crawls and wallows
		if is_bike:
			v.accel *= lerpf(1.0, 0.7, smoothstep(0.3, 0.8, float(s["water_depth"])))
		# the heavy truck sinks deeper into soft ground (mud, wet trails, its own ruts)
		var sink_mul: float = truck.mud_sink_mul if is_truck else 1.0
		sink[v] = lerpf(float(sink[v]), minf(float(s["sink_amount"]) * sink_mul, 0.6), 1.0 - exp(-5.0 * delta))
		if is_truck:
			# mud clods fly while the wheels run through soft ground (0 on hard ground, 1 in deep mud / fresh ruts)
			var soft_k: float = clampf(float(s["mud_depth"]) / 0.25 + float(s["rut_depth"]) * 0.8, 0.0, 1.0)
			if float(s["water_depth"]) > 0.15:
				soft_k = 0.0
			truck.mud_k = lerpf(truck.mud_k, soft_k, 1.0 - exp(-6.0 * delta))
		# floating sway + bow-wave lift while wading
		var tt: float = Time.get_ticks_msec() * 0.001
		var spd01: float = clampf(absf(v.speed) / 12.0, 0.0, 1.0)
		var k_w: float = 1.0 - exp(-4.0 * delta)
		var sway: float = 0.6 if is_truck else 1.0                  # heavy: smaller wobble
		v.water_pitch = lerpf(v.water_pitch, dn * sway * (0.012 * sin(tt * 1.4) + 0.045 * spd01) - 0.02 * dn * clampf(v.speed / 12.0, -1.0, 0.0), k_w)
		v.water_roll = lerpf(v.water_roll, dn * sway * 0.022 * sin(tt * 1.9 + 1.3), k_w)
		if v.visual != null:
			v.visual.position.y = -float(sink[v]) + dn * (0.05 + 0.015 * sin(tt * 2.3))   # body sinks into mud, rides a bit higher in water
		if water_fx.has(v):
			water_fx[v].update(delta, s)
		if v == vehicle or (vehicle == null and v == car):
			surf = s
	# character on foot: water effects follow the wading character; off while driving
	if water_fx.has(player):
		if vehicle == null:
			water_fx[player].update(delta, world.get_surface_state_at(player.global_position))
			player_fx_on = true
		elif player_fx_on:
			water_fx[player].stop()
			player_fx_on = false

func _process(delta: float) -> void:
	_sync_water(delta)
	if ui == null or player == null:
		return
	var ld: Vector2 = ui.look_delta
	ui.look_delta = Vector2.ZERO
	if Input.is_key_pressed(KEY_1):
		tc.set_weather(0)
	elif Input.is_key_pressed(KEY_2):
		tc.set_weather(1)
	elif Input.is_key_pressed(KEY_3):
		tc.set_weather(2)
	elif Input.is_key_pressed(KEY_4):
		tc.set_weather(3)
	if Input.is_key_pressed(KEY_Q):
		ld.x -= 400.0 * delta
	if Input.is_key_pressed(KEY_E):
		ld.x += 400.0 * delta
	if ld.length() > 0.5:
		look_idle = 0.0
	else:
		look_idle += delta
	if ui.zoom_dir != 0.0:
		cam_zoom = clampf(cam_zoom * exp(ui.zoom_dir * 0.9 * delta), 0.35, 2.5)     # hold + / - to move the camera
	spring.spring_length = cam_base_len * cam_zoom
	cam_yaw -= ld.x * 0.0045
	cam_pitch = clampf(cam_pitch - ld.y * 0.0045, -1.15, 0.45)
	var target: Vector3 = player.global_position + Vector3(0.0, 1.55, 0.0)
	if vehicle != null:
		target = vehicle.global_position + Vector3(0.0, 2.2 if vehicle == car else (3.4 if vehicle == truck else 1.7), 0.0)
		if absf(vehicle.speed) > 1.5 and look_idle > 1.2:
			var want: float = vehicle.heading if vehicle.speed > 0.0 else vehicle.heading + PI
			if vehicle != bike and vehicle.speed > 0.0:
				want += vehicle.cam_slide * 0.5          # camera swings towards the direction of travel while the car slides
			cam_yaw = lerp_angle(cam_yaw, want, 1.0 - exp(-1.8 * delta))
		ui.action_label = "EXIT"
	else:
		ui.action_label = "ENTER" if _nearest_vehicle() != null else ""
	ui.vehicle_mode = vehicle != null           # driving: arrow buttons instead of the joystick
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	cam_pivot.global_position = cam_pivot.global_position.lerp(target, 1.0 - exp(-16.0 * delta))
	hud_timer += delta
	if hud_timer > 0.4:
		hud_timer = 0.0
		hud.text = "[v12]  FPS: %d   %s   %s   Wet: %d%%" % [Engine.get_frames_per_second(), tc.get_time_string(), tc.get_weather_name(), int(tc.road_wetness * 100.0)]
		if vehicle != null:
			hud.text += "   %d km/h" % int(vehicle.speed_kmh())
			if vehicle == car:
				hud.text += "   4x4"
			elif vehicle == truck:
				hud.text += "   6x6 KamAZ"
			if not surf.is_empty():
				hud.text += "   mud %d cm  water %d cm" % [int(float(surf["mud_depth"]) * 100.0), int(float(surf["water_depth"]) * 100.0)]
