extends Node3D
# scripts/water_fx.gd  -  water interaction effects for ONE vehicle (SnowRunner-style wading), Godot 4.3 / GL Compatibility.
#   * wake quad   : bow wave crest, V-shaped wake lines, turbulent foam trail and waterline foam around the hull
#   * ripple rings: expanding rings left behind in world space while the vehicle drives through water
#   * splash      : CPUParticles3D spray at every wheel in water + bow spray + one-shot splash when entering water
#   * pond ripples: shader uniforms veh0 / veh1 / veh2 of the pond water (map_builder.gd) bend water normals around the bike and player
# main.gd creates one instance per vehicle (setup) and calls update() every physics frame.

const WAKE_SHADER: String = """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_mix;
uniform float intensity = 0.0;
uniform float spd = 0.0;
uniform float bright = 1.0;
uniform float half_len = 3.2;
uniform float half_w = 1.1;
uniform vec2 ext = vec2(5.0, 11.0);
varying vec2 lp;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
void vertex() {
	lp = VERTEX.xz;
}
void fragment() {
	vec2 p = lp;
	float t = TIME;
	float n1 = vnoise(p * 2.6 + vec2(0.0, -t * (1.0 + 3.0 * spd)));
	float n2 = vnoise(p * 5.5 + vec2(t * 0.6, -t * (1.5 + 4.0 * spd)));
	float nn = 0.6 * n1 + 0.4 * n2;
	// foam hugging the hull at the waterline
	vec2 q = abs(p) - vec2(half_w, half_len);
	float dbox = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0);
	float contact = (1.0 - smoothstep(0.0, 0.9, dbox)) * (0.45 + 0.8 * nn);
	// bow wave: a crest ring in front of the nose
	float zf = p.y + half_len;
	float de = length(vec2(p.x / (half_w * 1.7), min(zf, 0.0) / 1.1 - 0.25));
	float crest = smoothstep(0.55, 1.0, de) * (1.0 - smoothstep(1.0, 1.6, de)) * step(zf, 0.8) * (0.35 + 0.65 * spd);
	// Kelvin wake: two lines spreading out behind the vehicle
	float zb = max(zf, 0.0);
	float dl = abs(abs(p.x) - (half_w * 0.95 + zb * 0.30));
	float line = (1.0 - smoothstep(0.0, 0.42, dl + (nn - 0.5) * 0.35)) * (1.0 - smoothstep(0.0, 11.0, zb)) * step(0.0, zf) * spd;
	// turbulent foam between the lines
	float inside = 1.0 - smoothstep(0.0, half_w * 1.1 + zb * 0.26, abs(p.x));
	float turb = inside * smoothstep(0.35, 0.8, nn) * (1.0 - smoothstep(1.0, 9.0, zb)) * step(0.0, zf) * (0.25 + 0.75 * spd);
	float a = clamp(contact * 0.85 + crest * 0.95 + line * 0.7 + turb * 0.6, 0.0, 1.0);
	float edge = (1.0 - smoothstep(0.7, 1.0, abs(p.x) / ext.x)) * (1.0 - smoothstep(0.7, 1.0, abs(p.y) / ext.y));
	ALBEDO = vec3(0.86, 0.88, 0.86) * (0.8 + 0.2 * nn) * bright;
	ALPHA = a * edge * intensity * 0.8;
}
"""

const RING_SHADER: String = """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_mix;
uniform float age = 0.0;
uniform float strength = 1.0;
uniform float bright = 1.0;
varying vec2 lp;
void vertex() {
	lp = UV * 2.0 - 1.0;
}
void fragment() {
	float d = length(lp);
	float band = 1.0 - smoothstep(0.0, 0.13, abs(d - age));
	float band2 = (1.0 - smoothstep(0.0, 0.09, abs(d - age * 0.66))) * 0.6;
	float fade = (1.0 - age) * (1.0 - age) * (1.0 - smoothstep(0.85, 1.0, d));
	ALBEDO = vec3(0.82, 0.86, 0.86) * bright;
	ALPHA = clamp((band + band2) * fade * strength * 0.6, 0.0, 0.65);
}
"""

const RING_COUNT: int = 12
const RING_LIFE: float = 2.4

var veh = null                    # bike.gd or player.gd instance
var world = null                  # map_builder.gd instance
var light = null                  # DirectionalLight3D (sun) -> foam brightness
var half_len: float = 3.2
var half_w: float = 1.1
var scale_k: float = 1.0          # effect scale
var slot: int = 0                 # veh1 for bike / veh2 for player
var wheel_pts: Array = []         # local positions (Vector3) of the wheels
var bow_pt: Vector3 = Vector3.ZERO

var wake: MeshInstance3D = null
var wake_mat: ShaderMaterial = null
var ring_nodes: Array = []
var ring_mats: Array = []
var ring_age := PackedFloat32Array()
var ring_idx: int = 0
var wheel_fx: Array = []
var bow_fx: CPUParticles3D = null
var burst_fx: CPUParticles3D = null
var splash_audio: AudioStreamPlayer3D = null
var intensity: float = 0.0
var was_wet: bool = false
var travel: float = 0.0
var bright: float = 1.0
var speed_ref: float = 14.0       # speed (m/s) that counts as "full speed" for the effects (car 14, walking character ~2.5)
var is_walker: bool = false       # true = veh is player.gd (CharacterBody3D, heading from model, speed from velocity)

var _soft_tex: GradientTexture2D = null
var _ramp: Gradient = null
var _grow: Curve = null
var _quad: QuadMesh = null

func _shader(code: String) -> Shader:
	var s := Shader.new()
	s.code = code
	return s

func setup(vehicle, world_node, light_node, pts: Array, bow: Vector3, hl: float, hw: float, k: float, wake_slot: int, ref_speed: float = 14.0, walker: bool = false) -> void:
	veh = vehicle
	speed_ref = ref_speed
	is_walker = walker
	world = world_node
	light = light_node
	wheel_pts = pts
	bow_pt = bow
	half_len = hl
	half_w = hw
	scale_k = k
	slot = wake_slot
	_make_particle_assets()
	_make_wake()
	_make_rings()
	for p in wheel_pts:
		# Tyres throw water out and backwards, with an arcing spray rather than a vertical puff.
		wheel_fx.append(_make_emitter(30, 0.95, 62.0, 0.72 * scale_k, Vector3(0.0, 1.0, 0.85)))
	# The front wheel/bow pushes a short fan of water away from the nose.
	bow_fx = _make_emitter(42, 1.05, 42.0, 0.9 * scale_k, Vector3(0.0, 1.0, 0.35))
	burst_fx = _make_emitter(56, 1.2, 68.0, 1.05 * scale_k, Vector3(0.0, 1.0, 0.3))
	burst_fx.one_shot = true
	burst_fx.explosiveness = 0.95
	splash_audio = AudioStreamPlayer3D.new()
	splash_audio.name = "Water_Entry_Splash"
	splash_audio.stream = load("res://assets/audio/water_splash.wav")
	splash_audio.volume_db = -8.0
	splash_audio.unit_size = 6.0
	splash_audio.max_distance = 42.0
	add_child(splash_audio)

func _make_particle_assets() -> void:
	_soft_tex = GradientTexture2D.new()
	var gg := Gradient.new()
	gg.set_color(0, Color(1, 1, 1, 1))
	gg.set_color(1, Color(1, 1, 1, 0))
	gg.add_point(0.55, Color(1, 1, 1, 0.8))
	_soft_tex.gradient = gg
	_soft_tex.fill = GradientTexture2D.FILL_RADIAL
	_soft_tex.fill_from = Vector2(0.5, 0.5)
	_soft_tex.fill_to = Vector2(1.0, 0.5)
	_soft_tex.width = 64
	_soft_tex.height = 64
	_ramp = Gradient.new()
	_ramp.set_color(0, Color(1, 1, 1, 0.0))
	_ramp.set_color(1, Color(1, 1, 1, 0.0))
	_ramp.add_point(0.12, Color(1, 1, 1, 0.9))
	_grow = Curve.new()
	_grow.add_point(Vector2(0.0, 0.45))
	_grow.add_point(Vector2(1.0, 1.6))
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = _soft_tex
	mat.vertex_color_use_as_albedo = true
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mat.billboard_keep_scale = true
	mat.disable_receive_shadows = true
	_quad = QuadMesh.new()
	_quad.size = Vector2(1.0, 1.0)
	_quad.material = mat

func _make_emitter(count: int, life: float, spread_deg: float, size: float, dir: Vector3) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.top_level = true
	p.amount = count
	p.lifetime = life
	p.lifetime_randomness = 0.3
	p.local_coords = false
	p.emitting = false
	p.direction = dir
	p.spread = spread_deg
	p.gravity = Vector3(0.0, -9.0, 0.0)
	p.initial_velocity_min = 1.0
	p.initial_velocity_max = 2.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.25 * scale_k
	p.scale_amount_min = size * 0.6
	p.scale_amount_max = size
	p.scale_amount_curve = _grow
	p.color_ramp = _ramp
	p.mesh = _quad
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
	return p

func _make_wake() -> void:
	wake = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(half_w * 9.0, half_len * 7.0)
	wake.mesh = pm
	wake_mat = ShaderMaterial.new()
	wake_mat.shader = _shader(WAKE_SHADER)
	wake_mat.render_priority = 2
	wake_mat.set_shader_parameter("half_len", half_len)
	wake_mat.set_shader_parameter("half_w", half_w)
	wake_mat.set_shader_parameter("ext", pm.size * 0.5)
	wake.material_override = wake_mat
	wake.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	wake.top_level = true
	wake.visible = false
	add_child(wake)

func _make_rings() -> void:
	var sh: Shader = _shader(RING_SHADER)
	var pm := PlaneMesh.new()
	pm.size = Vector2(1.0, 1.0)
	ring_age.resize(RING_COUNT)
	for i in range(RING_COUNT):
		var m := ShaderMaterial.new()
		m.shader = sh
		m.render_priority = 1
		var n := MeshInstance3D.new()
		n.mesh = pm
		n.material_override = m
		n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		n.top_level = true
		n.visible = false
		add_child(n)
		ring_nodes.append(n)
		ring_mats.append(m)
		ring_age[i] = 9.0

func _spawn_ring(pos: Vector3, spd01: float) -> void:
	var i: int = ring_idx
	ring_idx = (ring_idx + 1) % RING_COUNT
	var sz: float = (3.2 + spd01 * 4.4) * scale_k
	var n: MeshInstance3D = ring_nodes[i]
	n.global_position = pos
	n.scale = Vector3(sz, 1.0, sz)
	n.visible = true
	ring_age[i] = 0.0
	var m: ShaderMaterial = ring_mats[i]
	m.set_shader_parameter("age", 0.0)
	m.set_shader_parameter("strength", 0.5 + 0.5 * spd01)
	m.set_shader_parameter("bright", bright)

# switches every effect off (character is inside a vehicle / hidden)
func stop() -> void:
	intensity = 0.0
	was_wet = false
	if wake != null:
		wake.visible = false
	for p in wheel_fx:
		p.emitting = false
	if bow_fx != null:
		bow_fx.emitting = false
	if world != null and world.water_mat != null:
		world.water_mat.set_shader_parameter("veh%d" % slot, Vector4(0.0, 0.0, 0.0, 0.0))

# s = world.get_surface_state_at(vehicle position)
func update(delta: float, s: Dictionary) -> void:
	if veh == null or world == null:
		return
	var depth: float = float(s["water_depth"])
	var surf_y: float = float(s["water_surface"])
	var vspeed: float = 0.0
	var yaw: float = 0.0
	if is_walker:
		vspeed = Vector2(veh.velocity.x, veh.velocity.z).length()
		yaw = veh.model.rotation.y + PI          # the character model faces +Z, vehicles face -Z
	else:
		vspeed = float(veh.speed)
		yaw = veh.rotation.y
	# speed normalised to the car scale, so every threshold below works for a walking character too
	var spd: float = absf(vspeed) / (speed_ref / 14.0)
	var spd01: float = clampf(spd / 14.0, 0.0, 1.0)
	var vpos: Vector3 = veh.global_position
	var yb := Basis(Vector3.UP, yaw)
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var wet: bool = depth > 0.06
	var mud: float = clampf(float(s["mud_depth"]) / 0.3, 0.0, 1.0)
	var tint: Color = Color(0.93, 0.94, 0.91).lerp(Color(0.62, 0.5, 0.34), 0.35 + 0.45 * mud)

	if light != null:
		bright = clampf(0.3 + float(light.light_energy) * 0.6, 0.3, 1.0)

	# ---- wake quad (bow wave, wake lines, waterline foam)
	var target: float = 0.0
	if wet:
		target = clampf(depth / 0.25, 0.0, 1.0) * (0.3 + 0.7 * spd01)
	intensity = lerpf(intensity, target, 1.0 - exp(-6.0 * delta))
	wake.visible = intensity > 0.02
	if wake.visible:
		wake.global_position = Vector3(vpos.x, surf_y + 0.03, vpos.z)
		wake.rotation.y = yaw
		wake_mat.set_shader_parameter("intensity", intensity)
		wake_mat.set_shader_parameter("spd", spd01)
		wake_mat.set_shader_parameter("bright", bright)

	# ---- ripple rings left behind in world space
	for i in range(RING_COUNT):
		if ring_age[i] < 1.0:
			ring_age[i] += delta / RING_LIFE
			if ring_age[i] >= 1.0:
				(ring_nodes[i] as Node3D).visible = false
			else:
				(ring_mats[i] as ShaderMaterial).set_shader_parameter("age", ring_age[i])
	if wet and depth > 0.1 and spd > 1.0:
		travel += spd * delta
		if travel > 1.1 + (1.0 - spd01) * 0.8:
			travel = 0.0
			var side: float = randf_range(-0.4, 0.4) * half_w
			var rp: Vector3 = vpos - fwd * half_len * 0.55 + yb * Vector3(side, 0.0, 0.0)
			_spawn_ring(Vector3(rp.x, surf_y + 0.025, rp.z), spd01)

	# ---- wheel spray
	for i in range(wheel_pts.size()):
		var lp: Vector3 = wheel_pts[i]
		var wp: Vector3 = vpos + yb * Vector3(lp.x, 0.0, lp.z)
		var ws: Dictionary = world.get_surface_state_at(wp)
		var wd: float = float(ws["water_depth"])
		var p: CPUParticles3D = wheel_fx[i]
		p.global_position = Vector3(wp.x, float(ws["water_surface"]) + 0.05, wp.z)
		p.rotation.y = yaw
		var on: bool = wd > 0.035 and spd > 0.65
		if p.emitting != on:
			p.emitting = on
		if on:
			var v: float = 1.0 + spd * 0.34 + wd * 1.2
			p.initial_velocity_min = v * 0.6 * scale_k
			p.initial_velocity_max = v * scale_k
			p.color = tint

	# ---- bow spray (nose pushing the water)
	var bw: Vector3 = vpos + yb * bow_pt
	bow_fx.global_position = Vector3(bw.x, surf_y + 0.1, bw.z)
	bow_fx.rotation.y = yaw
	var bow_on: bool = wet and depth > 0.12 and spd > 1.8
	if bow_fx.emitting != bow_on:
		bow_fx.emitting = bow_on
	if bow_on:
		var bv: float = 1.3 + spd * 0.32 + depth * 0.8
		bow_fx.initial_velocity_min = bv * 0.6 * scale_k
		bow_fx.initial_velocity_max = bv * scale_k
		bow_fx.color = tint

	# ---- big splash when driving into water
	if depth > 0.12 and not was_wet:
		was_wet = true
		if spd > 3.0:
			if splash_audio != null:
				splash_audio.global_position = Vector3(bw.x, surf_y, bw.z)
				splash_audio.pitch_scale = randf_range(0.92, 1.08)
				splash_audio.play()
			burst_fx.global_position = Vector3(bw.x, surf_y + 0.1, bw.z)
			burst_fx.rotation.y = yaw
			var sv: float = 2.0 + spd * 0.25
			burst_fx.initial_velocity_min = sv * 0.6 * scale_k
			burst_fx.initial_velocity_max = sv * scale_k
			burst_fx.color = tint
			burst_fx.restart()
			burst_fx.emitting = true
			_spawn_ring(Vector3(bw.x, surf_y + 0.025, bw.z), spd01)
	elif depth < 0.05:
		was_wet = false

	# ---- ripples in the pond water itself (normals bend around the vehicle)
	var wm = world.water_mat
	if wm != null:
		wm.set_shader_parameter("veh%d" % slot, Vector4(vpos.x, vpos.z, intensity * (0.4 + 0.6 * spd01), yaw))
