extends CharacterBody3D
# Third-person player: GTA-SA skin (converted .glb) + idle / walk / run animations.

# Speeds are tied to the original GTA SA clips so the feet never slide.
# WALK_CLIP_SPEED / RUN_CLIP_SPEED = metres per second the original clip travels at 1.0x.
const WALK_CLIP_SPEED: float = 0.72
const RUN_CLIP_SPEED: float = 2.11
const WALK_ANIM_SCALE: float = 1.0    # 1.0 = same pace as the GTA SA walk (reference video)
const RUN_ANIM_SCALE: float = 1.0     # 1.0 = original GTA SA run pace
const WALK_SPEED: float = WALK_CLIP_SPEED * WALK_ANIM_SCALE
const RUN_SPEED: float = RUN_CLIP_SPEED * RUN_ANIM_SCALE
const JUMP_VELOCITY: float = 5.2
const GRAVITY: float = 14.0
const FEET_OFFSET: float = 1.07       # model origin is at the hips, feet are 1.07 m lower

var ui = null            # touch_ui.gd instance (set by main.gd)
var cam_pivot: Node3D = null
var model: Node3D = null
var anim: AnimationPlayer = null
var current_state: String = ""
var spawn_pos: Vector3 = Vector3.ZERO
var col_shape: CollisionShape3D = null
var skel: Skeleton3D = null
var riding: bool = false
var ride_vehicle: Node3D = null
var world = null         # map_builder.gd instance (set by main.gd): water / mud surface state
var wade_sink: float = 0.0

# Sitting pose on the motorbike. Per bone: rotation vector (axis * angle, radians) applied on top of the rest pose.
# Solved offline (tools/make_ride_pose.py): hips on the seat, hands on the grips, toes on the foot pegs.
const RIDE_POSE := {
	"Pelvis": Vector3(0.02458, 0.00734, -0.21839),
	"Spine_1": Vector3(-0.00071, 0.01658, 1.12902),
	"Spine_2": Vector3(-0.00070, 0.00176, 0.05921),
	"Neck": Vector3(-0.00177, -0.00498, -0.38035),
	"Head": Vector3(-0.00000, -0.02871, -0.15034),
	"Bip01_L_Clavicle": Vector3(-0.29396, -0.19054, 0.11576),
	"Bip01_R_Clavicle": Vector3(0.25763, 0.19332, 0.13963),
	"L_UpperArm": Vector3(0.02976, 0.11381, -0.46341),
	"R_UpperArm": Vector3(-0.04298, -0.08381, -0.42965),
	"L_ForeArm": Vector3(0.02636, -0.04028, -1.13161),
	"R_ForeArm": Vector3(-0.01930, 0.24497, -1.14196),
	"L_Hand": Vector3(-0.00001, 0.28664, -0.03730),
	"R_Hand": Vector3(0.00002, -0.29598, -0.08286),
	"L_Thigh": Vector3(-0.04272, 0.00913, 0.69129),
	"R_Thigh": Vector3(0.01845, -0.03465, 0.69503),
	"L_Calf": Vector3(0.00000, 0.00000, -2.01352),
	"R_Calf": Vector3(0.00000, 0.00000, -2.04063),
	"L_Foot": Vector3(0.18395, -0.11863, 1.02141),
	"R_Foot": Vector3(-0.15902, 0.10666, 0.99450),
}
# model position inside the bike (bike space, metres): hips end up on the seat
const RIDE_MODEL_POS := Vector3(0.0, 1.02922, 0.36)

func _ready() -> void:
	spawn_pos = global_position
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 0.6
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	var col := CollisionShape3D.new()
	col.shape = shape
	col.position = Vector3(0.0, 0.9, 0.0)
	add_child(col)
	col_shape = col

	model = Node3D.new()
	add_child(model)
	model.rotation.y = PI   # face -Z (same way the camera looks at start)

	var scene: PackedScene = load("res://assets/character.glb")
	var inst: Node = scene.instantiate()
	model.add_child(inst)
	if inst is Node3D:
		(inst as Node3D).position = Vector3(0.0, FEET_OFFSET, 0.0)

	skel = inst.find_child("Skeleton3D", true, false) as Skeleton3D
	anim = inst.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if anim != null:
		for n in anim.get_animation_list():
			var a: Animation = anim.get_animation(n)
			a.loop_mode = Animation.LOOP_LINEAR
		_play("idle", 1.0)
	else:
		push_warning("AnimationPlayer not found in character.glb")

func set_active(on: bool) -> void:
	# used when getting in / out of the car
	visible = on
	set_physics_process(on)
	if col_shape != null:
		col_shape.set_deferred("disabled", not on)
	velocity = Vector3.ZERO

func start_riding(bike: Node3D) -> void:
	# the model is moved onto the bike (it leans / bounces with it) and frozen in the sitting pose
	if riding or skel == null:
		set_active(false)
		return
	riding = true
	ride_vehicle = bike
	set_active(false)
	if anim != null:
		anim.stop()
		anim.active = false
	skel.reset_bone_poses()
	for bone_name in RIDE_POSE:
		var bi: int = skel.find_bone(bone_name)
		if bi < 0:
			continue
		var v: Vector3 = RIDE_POSE[bone_name]
		var ang: float = v.length()
		var dq: Quaternion = Quaternion.IDENTITY
		if ang > 0.000001:
			dq = Quaternion(v / ang, ang)
		var rest_q: Quaternion = skel.get_bone_rest(bi).basis.orthonormalized().get_rotation_quaternion()
		skel.set_bone_pose_rotation(bi, rest_q * dq)
	remove_child(model)
	bike.visual.add_child(model)
	model.visible = true
	model.position = RIDE_MODEL_POS - Vector3(0.0, FEET_OFFSET, 0.0)
	model.rotation = Vector3(0.0, PI, 0.0)

func stop_riding() -> void:
	if not riding:
		set_active(true)
		return
	riding = false
	if model.get_parent() != null:
		model.get_parent().remove_child(model)
	add_child(model)
	model.position = Vector3.ZERO
	model.rotation = Vector3(0.0, PI, 0.0)
	skel.reset_bone_poses()
	if anim != null:
		anim.active = true
	current_state = ""
	_play("idle", 1.0)
	ride_vehicle = null
	set_active(true)

func _play(state: String, speed: float) -> void:
	if anim == null:
		return
	if state != current_state:
		if anim.has_animation(state):
			anim.play(state, 0.2)
		current_state = state
	anim.speed_scale = speed

func _physics_process(delta: float) -> void:
	var iv: Vector2 = Vector2.ZERO
	if ui != null:
		iv = ui.move_vec

	# keyboard (for testing on PC)
	var kx: float = 0.0
	var ky: float = 0.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		kx -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		kx += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		ky -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		ky += 1.0
	if kx != 0.0 or ky != 0.0:
		iv = Vector2(kx, ky).normalized()

	var mag: float = minf(iv.length(), 1.0)
	var yaw: float = 0.0
	if cam_pivot != null:
		yaw = cam_pivot.rotation.y
	var dir: Vector3 = Vector3(iv.x, 0.0, iv.y).rotated(Vector3.UP, yaw)

	var speed: float = 0.0
	var state: String = "idle"
	var clip_scale: float = 1.0
	if mag > 0.15:
		var running: bool = Input.is_key_pressed(KEY_SHIFT)
		if ui != null and ui.run_held:
			running = true
		if running:
			speed = RUN_SPEED
			state = "run"
			clip_scale = RUN_ANIM_SCALE
		else:
			speed = WALK_SPEED
			state = "walk"
			clip_scale = WALK_ANIM_SCALE
		dir = dir.normalized()
		var target_yaw: float = atan2(dir.x, dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, target_yaw, 1.0 - exp(-14.0 * delta))
	else:
		dir = Vector3.ZERO

	# ---- wading (SnowRunner-style): deeper water = slower + heavier, body sinks into mud
	var dw: float = 0.0
	var sink_t: float = 0.0
	if world != null:
		var ss: Dictionary = world.get_surface_state_at(global_position)
		dw = clampf(float(ss["water_depth"]) / 1.0, 0.0, 1.0)                  # 0 = dry, 1 = waist deep
		var wade_k: float = lerpf(1.0, 0.62, dw) * (1.0 - 0.2 * clampf(float(ss["mud_depth"]) / 0.5, 0.0, 1.0))
		speed *= wade_k
		clip_scale *= wade_k                                                   # keep the feet from sliding
		sink_t = minf(float(ss["sink_amount"]), 0.3)
		if global_position.y < float(ss["terrain_height"]) - 0.6:              # slipped through the half-res collision
			global_position = world.get_safe_position(global_position, 0.2)
			velocity.y = 0.0
	wade_sink = lerpf(wade_sink, sink_t, 1.0 - exp(-6.0 * delta))
	if not riding and model != null:
		model.position.y = -wade_sink

	var accel: float = 1.0 - exp(-12.0 * delta)
	velocity.x = lerpf(velocity.x, dir.x * speed, accel)
	velocity.z = lerpf(velocity.z, dir.z * speed, accel)

	var want_jump: bool = Input.is_key_pressed(KEY_SPACE)
	if ui != null and ui.jump_pressed:
		want_jump = true
		ui.jump_pressed = false

	if not is_on_floor():
		velocity.y -= GRAVITY * lerpf(1.0, 0.4, dw) * delta
	elif want_jump:
		velocity.y = JUMP_VELOCITY * lerpf(1.0, 0.5, dw)

	move_and_slide()

	if is_on_floor():
		_play(state, clip_scale)
	else:
		_play(current_state if current_state != "" else "idle", 1.0)

	if global_position.y < -30.0:
		global_position = spawn_pos
		velocity = Vector3.ZERO
