extends Node3D
# scripts/map_builder.gd  -  75 x 75 m tropical beach riding map with ocean, sand and shallow shoreline.
#
# Everything is generated at start-up (no .bin files needed):
#   * terrain: 200x200 cells (0.375 m), 4x4 chunks, ruts, hills, rock outcrop, bog, pond with a shallow ford
#   * collision: ConcavePolygonShape3D (half resolution) + simple colliders for trees / boulders / logs
#   * props: MultiMeshInstance3D for trees, boulders, rocks, stones, logs, tires, planks, branches,
#            grass, ferns, shrubs (all procedurally modelled, no cones, no boxes)
#   * shaders: shaders/terrain_realistic.gdshader (terrain) + small inline shaders (props, foliage, water)
#   * physics API: get_surface_state_at(world_pos) -> Dictionary (see below)
#
# main.gd:   world = preload("res://scripts/map_builder.gd").new(); world.weather_manager = tc; add_child(world)
#            then use world.spawn_position / world.spawn_yaw / world.get_safe_position() / world.get_height().

enum SurfaceType { DIRT, GRASS, ROCK, MUD, SHALLOW_WATER, DEEP_WATER }

const MAP_SIZE: float = 75.0
const HALF: float = 37.5
const CELLS: int = 200
const G: int = 201                 # grid points per side (CELLS + 1)
const STEP: float = 0.375          # metres per cell
const CHUNKS: int = 4
const CHUNK_CELLS: int = 50
const COL_STEP: int = 2            # collision resolution = every 2nd vertex (0.75 m) -> 20k triangles
const MUD_MAX: float = 0.5         # metres of mud at mud == 1
const RUT_N: int = 512             # dynamic rut map: 512 x 512 texels over the whole map (~15 cm per texel)
const RUT_DEPTH: float = 0.22      # metres a full rut (value 1) is pressed down: extra sink for vehicles, bump depth in the shader
const PUDDLE_MAX: float = 0.20     # keep identical in terrain_realistic.gdshader
const PUDDLE_DRY_BIAS: float = 0.17
const NOISE_RES: int = 256
const TERRAIN_SHADER: String = "res://shaders/terrain_realistic.gdshader"

@export var seed_value: int = 20261123
@export var density_scale: float = 1.0          # multiplies all vegetation / prop counts
@export var terrain_casts_shadow: bool = false  # Android: terrain shadows cost a lot, off by default
@export var tree_count: int = 0
@export var rim_tree_count: int = 0
@export var boulder_count: int = 0
@export var rock_count: int = 0
@export var stone_count: int = 0
@export var log_count: int = 0
@export var tire_count: int = 0
@export var plank_count: int = 0
@export var branch_count: int = 0
@export var grass_count: int = 0
@export var fern_count: int = 0
@export var shrub_count: int = 0

var weather_manager = null          # TimeCycWeatherManager (set by main.gd before add_child)
var wetness_override: float = 0.0   # used only when no weather_manager is set
var spawn_position: Vector3 = Vector3.ZERO
var spawn_yaw: float = 0.0

# ---- baked fields (index = j * G + i, j = z row, i = x column)
var hgt := PackedFloat32Array()     # terrain height (m)
var mud := PackedFloat32Array()     # 0..1  (x MUD_MAX = mud depth)
var rut_h := PackedFloat32Array()     # 0..1 dynamic ruts / footprints pressed into soft ground by wheels and feet
var rut_bytes := PackedByteArray()
var rut_img: Image = null
var rut_tex: ImageTexture = null
var _rut_dirty: bool = false
var _rut_clock: float = 0.0
var rock := PackedFloat32Array()    # 0..1
var trl := PackedFloat32Array()     # 0..1 trail / compacted dirt
var pot := PackedFloat32Array()     # 0..1 puddle potential
var slp := PackedFloat32Array()     # slope (rise / run)
var cavg := PackedFloat32Array()    # ambient-occlusion-like cavity (1 = open)
var _bog := PackedFloat32Array()
var _dmin := PackedFloat32Array()   # distance to nearest trail centre line
var _lat := PackedFloat32Array()    # signed lateral offset from it
var _along := PackedFloat32Array()  # distance along the trail

var _main_path := PackedVector2Array()
var _branch_path := PackedVector2Array()
var _pond_c: Vector2 = Vector2(0.0, 24.0)
var _pond_ab: Vector2 = Vector2(60.0, 60.0)
var _pond_level: float = 1.8
const SEA_LEVEL: float = 1.8
var _bog_c: Vector2 = Vector2(-24.0, -6.0)
var _outcrop_c: Vector2 = Vector2(24.0, 20.0)

var rng := RandomNumberGenerator.new()
var noise_tex: ImageTexture = null
var surface_tex: ImageTexture = null
var terrain_mat: ShaderMaterial = null
var water_mat: ShaderMaterial = null
var water_nrm: ImageTexture = null
var prop_mat: ShaderMaterial = null
var rock_mat: ShaderMaterial = null
var grass_mat: ShaderMaterial = null
var fern_mat: ShaderMaterial = null
var shrub_mat: ShaderMaterial = null
var _prop_body: StaticBody3D = null
var _rain: float = 0.0
var _tick: float = 0.0

# =====================================================================================
#  Mesh builder helper
# =====================================================================================
class MB:
	var v := PackedVector3Array()
	var c := PackedColorArray()
	var n := PackedVector3Array()
	var uv := PackedVector2Array()
	var idx := PackedInt32Array()

	func vert(p: Vector3, col: Color, u: Vector2 = Vector2.ZERO) -> int:
		v.append(p)
		c.append(col)
		uv.append(u)
		n.append(Vector3.ZERO)
		return v.size() - 1

	# adds a triangle whose front face (Godot = clockwise) looks along `hint`
	func tri(a: int, b: int, cc: int, hint: Vector3) -> void:
		var nn: Vector3 = (v[b] - v[a]).cross(v[cc] - v[a])
		if nn.dot(hint) > 0.0:
			var t: int = b
			b = cc
			cc = t
			nn = -nn
		var outn: Vector3 = -nn
		n[a] += outn
		n[b] += outn
		n[cc] += outn
		idx.append(a)
		idx.append(b)
		idx.append(cc)

	func add_to(mesh: ArrayMesh) -> void:
		var nrm := PackedVector3Array()
		nrm.resize(n.size())
		for i in range(n.size()):
			var q: Vector3 = n[i]
			nrm[i] = q.normalized() if q.length_squared() > 0.000001 else Vector3.UP
		var arrays: Array = []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = v
		arrays[Mesh.ARRAY_NORMAL] = nrm
		arrays[Mesh.ARRAY_COLOR] = c
		arrays[Mesh.ARRAY_TEX_UV] = uv
		arrays[Mesh.ARRAY_INDEX] = idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	func build() -> ArrayMesh:
		var m := ArrayMesh.new()
		add_to(m)
		return m

# =====================================================================================
#  Inline shaders (props / foliage / water)
# =====================================================================================
const PROP_SHADER: String = """
shader_type spatial;
global uniform float road_wetness;
uniform sampler2D noise_tex : filter_linear_mipmap, repeat_enable;
uniform float rough_base = 0.9;
uniform float mud_splash = 1.0;
uniform sampler2D tex_d : source_color, filter_linear_mipmap, repeat_enable;
uniform float tex_mix = 0.0;       // 0 = old procedural look, 1 = photo texture (rocks)
uniform float tex_scale = 0.32;
varying vec3 wpos;
varying vec3 wn;
varying float ground_y;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	ground_y = MODEL_MATRIX[3].y;
}
void fragment() {
	vec3 w = pow(abs(wn), vec3(4.0));
	w /= (w.x + w.y + w.z + 0.0001);
	float d1;
	float d2;
	vec3 col;
	if (tex_mix > 0.0) {
		// textured rock: one noise tap each, texture on top (flat) + side (dominant horizontal axis) only
		d1 = texture(noise_tex, wpos.xz * 0.8).r;
		d2 = texture(noise_tex, wpos.xz * 3.1).b;
		vec2 suv = (w.x > w.z) ? wpos.zy : wpos.xy;
		vec3 tx = texture(tex_d, suv * tex_scale).rgb * (1.0 - w.y) + texture(tex_d, wpos.xz * tex_scale).rgb * w.y;
		float tl = dot(tx, vec3(0.299, 0.587, 0.114));
		tx = mix(tx, vec3(tl), 0.45) * (0.7 + 1.2 * dot(COLOR.rgb, vec3(0.333))) * (0.85 + 0.3 * d2);
		col = mix(COLOR.rgb * (0.65 + 0.7 * d1) * (0.85 + 0.3 * d2), tx, tex_mix);
	} else {
		d1 = texture(noise_tex, wpos.zy * 0.8).r * w.x + texture(noise_tex, wpos.xz * 0.8).r * w.y + texture(noise_tex, wpos.xy * 0.8).r * w.z;
		d2 = texture(noise_tex, wpos.zy * 3.1).b * w.x + texture(noise_tex, wpos.xz * 3.1).b * w.y + texture(noise_tex, wpos.xy * 3.1).b * w.z;
		col = COLOR.rgb * (0.65 + 0.7 * d1) * (0.85 + 0.3 * d2);
	}
	float lh = wpos.y - ground_y;
	float splash = (1.0 - smoothstep(-0.1, 0.4, lh)) * mud_splash * (0.4 + 0.6 * d2);
	col = mix(col, vec3(0.15, 0.10, 0.065), splash * 0.6);
	float wet = clamp(road_wetness, 0.0, 1.0);
	col *= 1.0 - 0.3 * wet;
	ALBEDO = col;
	ROUGHNESS = mix(rough_base, 0.4, wet * 0.6);
	SPECULAR = 0.4;
}
"""

const FOLIAGE_SHADER: String = """
shader_type spatial;
render_mode cull_disabled;
global uniform float road_wetness;
uniform int shape = 0;            // 0 grass blades, 1 leaf-cluster cards, 2 fern fronds
uniform vec3 tint_a : source_color = vec3(0.12, 0.20, 0.05);
uniform vec3 tint_b : source_color = vec3(0.30, 0.40, 0.10);
uniform float wind = 0.10;
uniform float alpha_cut = 0.5;
varying float vsway;
float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}
void vertex() {
	vsway = COLOR.a;
	vec3 o = MODEL_MATRIX[3].xyz;
	float ph = o.x * 0.7 + o.z * 0.9;
	VERTEX.x += sin(TIME * 1.6 + ph + VERTEX.y * 1.7) * wind * vsway;
	VERTEX.z += cos(TIME * 1.3 + ph * 1.1 + VERTEX.y * 1.5) * wind * 0.7 * vsway;
}
void fragment() {
	float a = 1.0;
	vec3 col = COLOR.rgb;
	if (shape == 1) {
		vec2 uv = UV;
		float edge = 1.0 - smoothstep(0.78, 1.0, length(uv * 2.0 - 1.0));
		float acc = 0.0;
		vec3 lc = tint_a;
		for (int layer = 0; layer < 2; layer++) {
			vec2 g = uv * 5.0 + float(layer) * vec2(2.3, 1.7);
			vec2 id = floor(g);
			vec2 f = fract(g) - 0.5;
			float h = hash21(id + float(layer) * 17.0);
			vec2 off = (vec2(hash21(id + 3.1), hash21(id + 7.7)) - 0.5) * 0.45;
			float ang = h * 6.2831;
			vec2 q = f - off;
			q = vec2(q.x * cos(ang) + q.y * sin(ang), -q.x * sin(ang) + q.y * cos(ang));
			float d = length(q * vec2(1.0, 2.3));
			float leaf = 1.0 - smoothstep(0.30, 0.42, d);
			if (leaf > acc) {
				acc = leaf;
				lc = mix(tint_a, tint_b, h);
			}
		}
		a = acc * edge;
		col = lc * COLOR.r;
	} else if (shape == 2) {
		float u = (UV.x - 0.5) * 2.0;
		float v = UV.y;
		float env = sin(3.14159 * clamp(pow(v, 0.7), 0.0, 1.0)) * 0.95 + 0.05;
		float pin = smoothstep(0.85, 0.5, abs(fract(v * 9.0 - abs(u) * 1.7) - 0.5) * 2.0);
		float inside = step(abs(u), env);
		float rib = 1.0 - smoothstep(0.04, 0.08, abs(u));
		a = max(pin * inside, rib);
		col = mix(tint_a, tint_b, v) * COLOR.r;
	}
	ALPHA = a;
	ALPHA_SCISSOR_THRESHOLD = alpha_cut;
	ALBEDO = col * mix(1.0, 0.8, clamp(road_wetness, 0.0, 1.0) * 0.5);
	ROUGHNESS = 0.85;
	SPECULAR = 0.25;
	BACKLIGHT = col * 0.35;
	vec3 nn = FRONT_FACING ? NORMAL : -NORMAL;
	vec3 up_v = (VIEW_MATRIX * vec4(0.0, 1.0, 0.0, 0.0)).xyz;
	NORMAL = normalize(up_v * 0.6 + nn * 0.4);
}
"""

const WATER_SHADER: String = """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, specular_schlick_ggx;
// Pond water v9: clear shallows, deeper blue-green body, fresnel mirror, SCREEN-SPACE REFLECTIONS (trees, banks, bike show up
// mirrored in the water; where nothing is hit the engine's sky reflection is used), layered wave normals, shore foam, rain rings.
// COLOR.r = signed water depth encoded as 0.5 + depth / 3.2 (0.5 = shoreline), COLOR.a = legacy shore alpha.
global uniform float road_wetness;
uniform sampler2D noise_tex : filter_linear_mipmap, repeat_enable;
uniform sampler2D wave_nrm : filter_linear_mipmap, repeat_enable;     // RG = swell slope, BA = ripple slope
uniform sampler2D screen_tex : hint_screen_texture, filter_linear, repeat_disable;
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest, repeat_disable;
uniform vec3 shallow_col : source_color = vec3(0.30, 0.34, 0.24);
uniform vec3 deep_col : source_color = vec3(0.0, 0.35, 0.25);      // SA_DOX deep water colour
uniform sampler2D foam_tex : filter_linear_mipmap, repeat_enable;   // SA_DOX WaterFoam.png
uniform vec3 foam_col : source_color = vec3(0.90, 0.93, 0.95);
uniform float rain_intensity = 0.0;
uniform float wave_strength = 1.0;
uniform float ssr_strength = 1.0;
uniform vec2 water_flow = vec2(0.035, 0.012); // slow ocean drift direction/speed
uniform vec4 veh0 = vec4(0.0);   // x, z, amplitude, yaw : ripples + wake around vehicle 0
uniform vec4 veh1 = vec4(0.0);   // vehicle 1 (bike)
uniform vec4 veh2 = vec4(0.0);   // the character wading
varying vec3 wp;
float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}
vec2 veh_ring(vec2 p, vec4 v) {
	vec2 dv = p - v.xy;
	float d = length(dv);
	float w = sin(d * 7.0 - TIME * 7.0) * exp(-d * 0.55) * v.z;
	return dv / max(d, 0.001) * w * 0.35;
}
// V-shaped wake: two swell lines spreading out behind the hull (v.w = yaw, front = -Z), slope pushes the normals sideways
vec2 veh_wedge(vec2 p, vec4 v) {
	if (v.z < 0.01) {
		return vec2(0.0);
	}
	vec2 dv = p - v.xy;
	vec2 fw = vec2(-sin(v.w), -cos(v.w));
	vec2 sd = vec2(-fw.y, fw.x);
	float behind = -dot(dv, fw);
	float side = dot(dv, sd);
	if (behind < 0.3 || behind > 15.0) {
		return vec2(0.0);
	}
	float e = abs(side) - (0.9 + behind * 0.34);
	float env = exp(-e * e * 1.4) * (1.0 - behind / 15.0) * smoothstep(0.3, 1.5, behind);
	float w = sin(behind * 3.2 - TIME * 5.0) * 0.5 + 0.5;
	return sd * sign(side) * env * w * v.z * 0.55;
}
float interaction_height(vec2 p, vec4 v) {
	if (v.z < 0.001) return 0.0;
	vec2 dv = p - v.xy;
	float d = length(dv);
	float ring = sin(d * 5.2 - TIME * 6.5) * exp(-d * 0.30) * v.z;
	vec2 fw = vec2(-sin(v.w), -cos(v.w));
	vec2 side = vec2(-fw.y, fw.x);
	float behind = -dot(dv, fw);
	float lateral = abs(dot(dv, side));
	float wake_line = abs(lateral - (0.75 + max(behind, 0.0) * 0.30));
	float wake = exp(-wake_line * 2.2) * exp(-max(behind, 0.0) * 0.11) * step(0.0, behind);
	return ring * 0.018 + wake * sin(behind * 2.8 - TIME * 4.0) * v.z * 0.035;
}
void vertex() {
	vec2 p = VERTEX.xz;
	float t = TIME;
	vec2 flow = water_flow;
	float swell = sin(dot(p, vec2(0.72, 0.31)) * 0.42 + t * 1.15 + dot(flow, p) * 8.0) * 0.035;
	float cross_wave = sin(dot(p, vec2(-0.24, 0.91)) * 0.73 - t * 1.7 + dot(flow, p) * 5.0) * 0.018;
	VERTEX.y += (swell + cross_wave) * wave_strength + interaction_height(p, veh0) + interaction_height(p, veh1) + interaction_height(p, veh2);
	wp = VERTEX;
}
void fragment() {
	vec2 p = wp.xz;
	float t = TIME;
	float depth_m = max((COLOR.r - 0.5) * 3.2, 0.0);
	float edge = smoothstep(0.0, 0.28, depth_m);

	// ---- waves: swell + ripples + fine ripples (fine ones fade with distance so they do not shimmer)
	float vd = length(VERTEX);
	float near_k = 1.0 - smoothstep(22.0, 60.0, vd);
	vec4 a = texture(wave_nrm, p * 0.10 + flow * t + vec2(t * 0.012, t * 0.007));
	vec4 b = texture(wave_nrm, p * 0.33 - flow * t * 1.7 + vec2(-t * 0.020, t * 0.014));
	vec4 c = texture(wave_nrm, p * 1.15 + flow * t * 2.6 + vec2(t * 0.035, -t * 0.028));
	vec2 g = (a.rg * 2.0 - 1.0) * 0.28 + (b.ba * 2.0 - 1.0) * 0.30 + (c.ba * 2.0 - 1.0) * 0.16 * near_k;
	g *= wave_strength * (1.0 + 1.2 * rain_intensity);
	if (rain_intensity > 0.01) {
		vec2 q = p * 2.6;
		vec2 cell = floor(q);
		vec2 f = fract(q) - 0.5;
		float hh = hash21(cell);
		float tt = fract(t * 0.9 + hh);
		float r = length(f);
		float ring = smoothstep(0.08, 0.0, abs(r - tt * 0.5)) * (1.0 - tt);
		g += f / max(r, 0.001) * ring * 0.5 * rain_intensity;
	}
	g += veh_ring(p, veh0) + veh_ring(p, veh1) + veh_ring(p, veh2);
	g += veh_wedge(p, veh0) + veh_wedge(p, veh1) + veh_wedge(p, veh2);
	vec3 nw = normalize(vec3(g.x, 1.0, g.y));
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);

	// ---- colour / transparency
	float ndv = clamp(dot(NORMAL, VIEW), 0.0, 1.0);
	float fres = 0.04 + 0.96 * pow(1.0 - ndv, 3.5);
	float d01 = smoothstep(0.0, 1.2, depth_m);
	vec3 body = mix(shallow_col, deep_col, d01);
	float base_a = mix(0.30, 0.82, d01);

	// ---- screen-space reflection: march the mirror ray through the depth buffer
	vec3 hit_col = vec3(0.0);
	float hit_w = 0.0;
	vec3 rdir = reflect(normalize(VERTEX), NORMAL);
	if (rdir.z < -0.02 && ssr_strength > 0.0) {
		vec3 rp = VERTEX;
		float sl = 0.30;
		for (int i = 0; i < 16; i++) {
			rp += rdir * sl;
			sl *= 1.25;
			vec4 cp = PROJECTION_MATRIX * vec4(rp, 1.0);
			if (cp.w <= 0.0) {
				break;
			}
			vec2 suv = cp.xy / cp.w * 0.5 + 0.5;
			if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) {
				break;
			}
			float dd = texture(depth_tex, suv).x;
			vec3 ndc = vec3(suv * 2.0 - 1.0, dd * 2.0 - 1.0);
			vec4 vp = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
			float scene_z = vp.z / vp.w;
			float diff = scene_z - rp.z;
			if (diff > 0.0 && diff < sl * 1.2 + 0.25) {
				vec2 duv = suv + g * 0.015;
				hit_col = texture(screen_tex, duv).rgb;
				float bord = smoothstep(0.0, 0.08, suv.x) * smoothstep(1.0, 0.92, suv.x) * smoothstep(0.0, 0.08, suv.y) * smoothstep(1.0, 0.92, suv.y);
				hit_w = bord * (1.0 - float(i) / 20.0);
				break;
			}
		}
	}
	float refl_k = clamp(fres * 1.25, 0.0, 1.0) * mix(0.35, 1.0, d01);   // shallow edge reflects a bit less
	float ssr_w = hit_w * refl_k * ssr_strength;
	float alpha = clamp(base_a + (1.0 - base_a) * fres * 0.9 + ssr_w * 0.5, 0.0, 0.97) * edge;

	// ---- foam line where the water meets the bank (broken up by noise, laps in and out)
	float shore = 1.0 - smoothstep(0.02, 0.22, depth_m);
	float fn = texture(noise_tex, p * 1.6 + vec2(t * 0.03, t * 0.02)).g;
	float fm = texture(noise_tex, p * 0.5 - vec2(t * 0.02, 0.0)).b;
	float lap = 0.5 + 0.5 * sin(t * 1.0 + depth_m * 20.0 + fm * 8.0);
	float foam = smoothstep(0.50, 0.85, (1.0 - fn) * 0.85 + lap * 0.35 + (fm - 0.5) * 0.5 - 0.15) * shore * smoothstep(0.0, 0.02, depth_m);

	// SA_DOX foam: texture-driven foam that hugs the shore (waterPostProcessing.shader)
	float ft = texture(foam_tex, p * 0.12 + vec2(sin(t / 2.5) * 0.2) + g * 0.0092).r;
	float foam_sa = clamp(pow(1.0 - pow(max(depth_m, 0.0001), 0.2), 2.0) * 2.0, 0.0, 1.0) * clamp(ft * 2.0, 0.0, 1.0) * smoothstep(0.0, 0.02, depth_m);
	foam = max(foam, foam_sa * 0.85);

	ALBEDO = mix(body * (1.0 - ssr_w * 0.6), foam_col, foam);
	EMISSION = hit_col * ssr_w * 0.95 * (1.0 - foam);
	ALPHA = max(alpha, foam * 0.85);
	ROUGHNESS = mix(0.03 + 0.08 * rain_intensity, 0.9, foam);
	SPECULAR = mix(0.75 * (1.0 - hit_w * 0.7), 0.2, foam);
	METALLIC = 0.0;
}
"""

# =====================================================================================
#  Lifecycle
# =====================================================================================
func _ready() -> void:
	rng.seed = seed_value
	if OS.has_feature("android") or OS.has_feature("ios"):
		density_scale *= 0.8
	_make_noise_texture()
	_build_fields()
	_make_materials()
	_init_ruts()
	_build_terrain_meshes()
	_build_collision()
	_build_water()
	_scatter_all()
	_build_boundary()
	_pick_spawn()

func _process(delta: float) -> void:
	_tick += delta
	if _tick < 0.25:
		return
	_tick = 0.0
	if weather_manager != null and terrain_mat != null:
		var target: float = 1.0 if str(weather_manager.get_weather_name()) == "Rain" else 0.0
		_rain = lerpf(_rain, target, 0.35)
		terrain_mat.set_shader_parameter("rain_intensity", _rain)
		water_mat.set_shader_parameter("rain_intensity", _rain)

# =====================================================================================
#  Public API
# =====================================================================================
func get_height(x: float, z: float) -> float:
	return _bil(hgt, x, z)

func get_terrain_height(x: float, z: float) -> float:
	return _bil(hgt, x, z)

# Above ground AND above any water surface (use for spawning player / car).
func get_safe_position(p: Vector3, clearance: float = 1.0) -> Vector3:
	var s: Dictionary = get_surface_state_at(p)
	var y: float = s["terrain_height"]
	if float(s["water_depth"]) > 0.02:
		y = maxf(y, float(s["water_surface"]))
	return Vector3(p.x, y + clearance, p.z)

func get_spawn_transform() -> Transform3D:
	return Transform3D(Basis(Vector3.UP, spawn_yaw), spawn_position)

# Surface sample for vehicle / character physics. Keys:
#   terrain_height  : ground height (m)
#   water_depth     : standing water above ground (m)  (pond + rain puddles)
#   water_surface   : world Y of the water surface (== terrain_height when dry)
#   mud_depth       : mud thickness (m)
#   surface_type    : SurfaceType enum (DIRT, GRASS, ROCK, MUD, SHALLOW_WATER, DEEP_WATER)
#   sink_amount     : how far wheels / body should sink below terrain_height (m)
#   drag_factor     : extra deceleration, use  speed *= max(0, 1 - drag_factor * delta)   (1/s)
#   traction_multiplier : 0.15..1, multiply engine force / grip
func get_surface_state_at(world_pos: Vector3) -> Dictionary:
	var x: float = world_pos.x
	var z: float = world_pos.z
	var h: float = _bil(hgt, x, z)
	var wet: float = _wetness()
	var m: float = _mud_eff(x, z, wet)
	var rk: float = _bil(rock, x, z)
	var tr: float = _bil(trl, x, z)
	var pt: float = _bil(pot, x, z)
	var pond: float = _pond_depth(x, z, h)
	var rut_d: float = _rut_at(x, z)
	var puddle: float = maxf(0.0, pt * PUDDLE_MAX - (1.0 - wet) * PUDDLE_DRY_BIAS)
	var water: float = maxf(pond, puddle)
	var mud_d: float = m * MUD_MAX * (0.6 + 0.4 * wet)

	var stype: int = SurfaceType.GRASS
	if pond > 0.6:
		stype = SurfaceType.DEEP_WATER
	elif water > 0.05:
		stype = SurfaceType.SHALLOW_WATER
	elif mud_d > 0.12:
		stype = SurfaceType.MUD
	elif rk > 0.55:
		stype = SurfaceType.ROCK
	elif tr > 0.45:
		stype = SurfaceType.DIRT

	var traction: float = 0.75 * (1.0 - 0.35 * wet)
	match stype:
		SurfaceType.DIRT:
			traction = 0.85 * (1.0 - 0.35 * wet)
		SurfaceType.ROCK:
			traction = 0.95 * (1.0 - 0.15 * wet)
		SurfaceType.MUD:
			traction = 0.40 * (1.0 - 0.30 * wet) - mud_d * 0.25
		SurfaceType.SHALLOW_WATER:
			traction = 0.55 - water * 0.5
		SurfaceType.DEEP_WATER:
			traction = 0.25
	traction = clampf(traction, 0.15, 1.0)

	var sink: float = 0.0
	if stype != SurfaceType.DEEP_WATER:
		sink = mud_d * 0.55
		if m > 0.2:
			sink += water * 0.25
		sink += rut_d * RUT_DEPTH * 0.9                # wheels sit down in the grooves they dug
		sink = clampf(sink, 0.0, 0.5)

	var drag: float = mud_d * 1.6 + water * (0.8 if pond > 0.0 else 0.7) + rut_d * 0.4
	drag = clampf(drag, 0.0, 3.0)

	return {
		"terrain_height": h,
		"water_depth": water,
		"water_surface": (_pond_level if pond > 0.0 else h + water),
		"mud_depth": mud_d,
		"surface_type": stype,
		"sink_amount": sink,
		"rut_depth": rut_d,
		"drag_factor": drag,
		"traction_multiplier": traction,
	}

# =====================================================================================
#  Dynamic ruts (tyre tracks / footprints in soft ground)
# =====================================================================================
func _init_ruts() -> void:
	rut_h.resize(RUT_N * RUT_N)
	rut_h.fill(0.0)
	rut_bytes.resize(RUT_N * RUT_N)
	rut_bytes.fill(0)
	rut_img = Image.create_from_data(RUT_N, RUT_N, false, Image.FORMAT_R8, rut_bytes)
	rut_tex = ImageTexture.create_from_image(rut_img)
	if terrain_mat != null:
		terrain_mat.set_shader_parameter("rut_map", rut_tex)
		terrain_mat.set_shader_parameter("rut_depth_m", RUT_DEPTH)

# how soft the ground is at x, z (0 = hard, 1 = deep mud): decides how deep a tyre can dig
func _softness(x: float, z: float) -> float:
	var wet: float = _wetness()
	var m: float = _mud_eff(x, z, wet)
	var rk: float = _bil(rock, x, z)
	var h: float = _bil(hgt, x, z)
	var inland: float = _coastline_z(x) - z
	# Dry loose beach sand still yields under boots and tyres; wetter sand near
	# the waterline compacts more firmly, while inland dune sand is softer.
	var beach: float = smoothstep(-0.8, 0.35, inland) * (1.0 - smoothstep(7.0, 10.0, inland))
	var wet_sand: float = smoothstep(0.15, 0.9, 1.0 - absf(inland - 0.25) / 2.5)
	var sand_soft: float = beach * lerpf(0.78, 0.48, wet_sand)
	var sf: float = maxf(sand_soft, m * (0.6 + 0.4 * wet))
	sf = maxf(sf, 0.18 * wet * (1.0 - rk))
	sf *= 1.0 - smoothstep(0.15, 0.5, _pond_depth(x, z, h))
	return clampf(sf * (1.0 - rk * 0.92), 0.0, 1.0)

# Mud including what wet weather adds: dirt trails turn muddy when wet, and so does the ground where puddles collect.
# The same formula is in terrain_realistic.gdshader (mud_e), so what you see is what the physics uses.
func _mud_eff(x: float, z: float, wet: float) -> float:
	var m: float = _bil(mud, x, z)
	var pt: float = _bil(pot, x, z)
	var tr: float = _bil(trl, x, z)
	var rk: float = _bil(rock, x, z)
	var wk: float = smoothstep(0.15, 0.65, wet)
	var wm: float = maxf(smoothstep(0.2, 0.7, pt) * 0.85, tr * 0.4) * wk * (1.0 - rk)
	return maxf(m, wm)

func _rut_at(x: float, z: float) -> float:
	if rut_h.is_empty():
		return 0.0
	var fx: float = clampf((x + HALF) / MAP_SIZE * float(RUT_N) - 0.5, 0.0, float(RUT_N - 1) - 0.0001)
	var fz: float = clampf((z + HALF) / MAP_SIZE * float(RUT_N) - 0.5, 0.0, float(RUT_N - 1) - 0.0001)
	var i: int = int(fx)
	var j: int = int(fz)
	var tx: float = fx - float(i)
	var tz: float = fz - float(j)
	var a: float = rut_h[j * RUT_N + i]
	var b: float = rut_h[j * RUT_N + i + 1]
	var c: float = rut_h[(j + 1) * RUT_N + i]
	var d: float = rut_h[(j + 1) * RUT_N + i + 1]
	return lerpf(lerpf(a, b, tx), lerpf(c, d, tx), tz)

# Press one wheel / foot print into the ground. radius in metres, strength = extra deepening per call (0..1).
# The first press digs to ~55% of what the ground allows, repeated passes deepen it, never beyond the softness of the ground.
func press_rut(wp: Vector3, radius: float, strength: float, depth_mul: float = 1.0) -> void:
	# depth_mul > 1 allows heavier vehicles to dig deeper; the bike uses the default depth multiplier
	var soft: float = minf(_softness(wp.x, wp.z) * depth_mul, 1.0)
	if soft < 0.08:
		return
	var tpm: float = float(RUT_N) / MAP_SIZE
	var cx: float = (wp.x + HALF) * tpm - 0.5
	var cz: float = (wp.z + HALF) * tpm - 0.5
	var r: float = maxf(radius * tpm, 1.2)
	var x0: int = maxi(int(floor(cx - r)), 0)
	var x1: int = mini(int(ceil(cx + r)), RUT_N - 1)
	var z0: int = maxi(int(floor(cz - r)), 0)
	var z1: int = mini(int(ceil(cz + r)), RUT_N - 1)
	for j in range(z0, z1 + 1):
		for i in range(x0, x1 + 1):
			var dx: float = float(i) - cx
			var dz: float = float(j) - cz
			var d2: float = (dx * dx + dz * dz) / (r * r)
			if d2 >= 1.0:
				continue
			var f: float = 1.0 - d2
			var cap: float = soft * f
			var idx: int = j * RUT_N + i
			var v: float = rut_h[idx]
			if v >= cap:
				continue
			v = minf(maxf(v, cap * 0.8) + strength * cap, cap)
			rut_h[idx] = v
			rut_bytes[idx] = int(v * 255.0)
	_rut_dirty = true

# stamp along the path of a wheel since the last frame (no gaps at speed)
func press_rut_line(a: Vector3, b: Vector3, radius: float, strength: float, depth_mul: float = 1.0) -> void:
	var dist: float = a.distance_to(b)
	if dist > 8.0:
		press_rut(b, radius, strength, depth_mul)
		return
	var n: int = clampi(int(ceil(dist / maxf(radius * 0.7, 0.05))), 1, 10)
	for k in range(1, n + 1):
		press_rut(a.lerp(b, float(k) / float(n)), radius, strength / float(n), depth_mul)

# A boot-shaped oval impression, aligned to the character's travel direction.
func press_footprint(wp: Vector3, forward: Vector3, strength: float = 0.42) -> void:
	var fwd := Vector2(forward.x, forward.z).normalized()
	if fwd.length_squared() < 0.01:
		fwd = Vector2.UP
	var right := Vector2(fwd.y, -fwd.x)
	var soft: float = _softness(wp.x, wp.z)
	if soft < 0.08:
		return
	var tpm: float = float(RUT_N) / MAP_SIZE
	var center := Vector2((wp.x + HALF) * tpm - 0.5, (wp.z + HALF) * tpm - 0.5)
	var rx: float = 0.105 * tpm
	var rz: float = 0.17 * tpm
	var extent: int = int(ceil(maxf(rx, rz)))
	for j in range(maxi(0, int(center.y) - extent), mini(RUT_N - 1, int(center.y) + extent) + 1):
		for i in range(maxi(0, int(center.x) - extent), mini(RUT_N - 1, int(center.x) + extent) + 1):
			var d := Vector2(float(i) - center.x, float(j) - center.y)
			var along: float = d.dot(fwd) / rz
			var across: float = d.dot(right) / rx
			var q: float = along * along + across * across
			if q >= 1.0:
				continue
			var idx: int = j * RUT_N + i
			var imprint: float = soft * (1.0 - q) * strength
			rut_h[idx] = maxf(rut_h[idx], imprint)
			rut_bytes[idx] = int(clampf(rut_h[idx], 0.0, 1.0) * 255.0)
	_rut_dirty = true

# call every frame from main.gd (map_builder's own _process is switched off there); uploads ~8x per second, only when changed
func flush_ruts(delta: float) -> void:
	_rut_clock += delta
	if not _rut_dirty or _rut_clock < 0.12:
		return
	_rut_clock = 0.0
	_rut_dirty = false
	rut_img.set_data(RUT_N, RUT_N, false, Image.FORMAT_R8, rut_bytes)
	rut_tex.update(rut_img)

# =====================================================================================
#  Small helpers
# =====================================================================================
func _wetness() -> float:
	if weather_manager != null:
		return clampf(float(weather_manager.road_wetness), 0.0, 1.0)
	return wetness_override

func _bil(arr: PackedFloat32Array, x: float, z: float) -> float:
	var fx: float = clampf((x + HALF) / STEP, 0.0, float(G - 1) - 0.0001)
	var fz: float = clampf((z + HALF) / STEP, 0.0, float(G - 1) - 0.0001)
	var i: int = int(fx)
	var j: int = int(fz)
	var tx: float = fx - float(i)
	var tz: float = fz - float(j)
	var a: float = arr[j * G + i]
	var b: float = arr[j * G + i + 1]
	var c: float = arr[(j + 1) * G + i]
	var d: float = arr[(j + 1) * G + i + 1]
	return lerpf(lerpf(a, b, tx), lerpf(c, d, tx), tz)

func _coastline_z(x: float) -> float:
	# A gently irregular tropical shoreline running across the southern half of the map.
	return 5.0 + sin(x * 0.11) * 1.7 + sin(x * 0.29 + 0.8) * 0.65

func _pond_q(x: float, z: float) -> float:
	# The old pond mask is now an ocean mask: 0.5 = sea, 2.0 = dry land.
	return 0.5 if z > _coastline_z(x) else 2.0

func _pond_depth(x: float, z: float, h: float) -> float:
	if z <= _coastline_z(x):
		return 0.0
	return maxf(0.0, _pond_level - h)

func _mk_noise(nseed: int, freq: float, octaves: int = 1, ntype: int = FastNoiseLite.TYPE_SIMPLEX_SMOOTH) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = nseed
	n.frequency = freq
	n.noise_type = ntype
	if octaves > 1:
		n.fractal_type = FastNoiseLite.FRACTAL_FBM
		n.fractal_octaves = octaves
	else:
		n.fractal_type = FastNoiseLite.FRACTAL_NONE
	return n

func _blur(src: PackedFloat32Array, r: int) -> PackedFloat32Array:
	var tmp := PackedFloat32Array()
	tmp.resize(G * G)
	var out := PackedFloat32Array()
	out.resize(G * G)
	var inv: float = 1.0 / float(2 * r + 1)
	for j in range(G):
		var base: int = j * G
		var sum: float = 0.0
		for k in range(-r, r + 1):
			sum += src[base + clampi(k, 0, G - 1)]
		for i in range(G):
			tmp[base + i] = sum * inv
			sum += src[base + clampi(i + r + 1, 0, G - 1)] - src[base + clampi(i - r, 0, G - 1)]
	for i in range(G):
		var sum2: float = 0.0
		for k in range(-r, r + 1):
			sum2 += tmp[clampi(k, 0, G - 1) * G + i]
		for j in range(G):
			out[j * G + i] = sum2 * inv
			sum2 += tmp[clampi(j + r + 1, 0, G - 1) * G + i] - tmp[clampi(j - r, 0, G - 1) * G + i]
	return out

func _catmull(pts: Array, spacing: float) -> PackedVector2Array:
	var P: Array = []
	P.append(pts[0] * 2.0 - pts[1])
	for p in pts:
		P.append(p)
	P.append(pts[pts.size() - 1] * 2.0 - pts[pts.size() - 2])
	var out := PackedVector2Array()
	for i in range(1, P.size() - 2):
		var p0: Vector2 = P[i - 1]
		var p1: Vector2 = P[i]
		var p2: Vector2 = P[i + 1]
		var p3: Vector2 = P[i + 2]
		var n: int = maxi(2, int(p1.distance_to(p2) / spacing))
		for k in range(n):
			var t: float = float(k) / float(n)
			out.append(0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t))
	out.append(P[P.size() - 2])
	return out

# distance / lateral offset / along-distance of every grid point to the nearest trail segment
func _raster(path: PackedVector2Array, along_start: float) -> void:
	var R: float = 8.5
	var acc: float = along_start
	for s in range(path.size() - 1):
		var a: Vector2 = path[s]
		var b: Vector2 = path[s + 1]
		var ab: Vector2 = b - a
		var l2: float = ab.length_squared()
		if l2 < 0.0001:
			continue
		var l: float = sqrt(l2)
		var nrm: Vector2 = Vector2(-ab.y, ab.x) / l
		var i0: int = maxi(0, int(floor((minf(a.x, b.x) - R + HALF) / STEP)))
		var i1: int = mini(G - 1, int(ceil((maxf(a.x, b.x) + R + HALF) / STEP)))
		var j0: int = maxi(0, int(floor((minf(a.y, b.y) - R + HALF) / STEP)))
		var j1: int = mini(G - 1, int(ceil((maxf(a.y, b.y) + R + HALF) / STEP)))
		for j in range(j0, j1 + 1):
			var pz: float = -HALF + float(j) * STEP
			for i in range(i0, i1 + 1):
				var px: float = -HALF + float(i) * STEP
				var ap: Vector2 = Vector2(px, pz) - a
				var t: float = clampf(ap.dot(ab) / l2, 0.0, 1.0)
				var d: float = (ap - ab * t).length()
				var id: int = j * G + i
				if d < _dmin[id]:
					_dmin[id] = d
					_lat[id] = ap.dot(nrm)
					_along[id] = acc + t * l
		acc += l

# =====================================================================================
#  Textures
# =====================================================================================
func _make_noise_texture() -> void:
	var ia: Image = _mk_noise(11, 0.030, 5).get_seamless_image(NOISE_RES, NOISE_RES)
	var nc := _mk_noise(12, 0.040, 1, FastNoiseLite.TYPE_CELLULAR)
	nc.cellular_return_type = FastNoiseLite.RETURN_DISTANCE
	var ib: Image = nc.get_seamless_image(NOISE_RES, NOISE_RES)
	var ic: Image = _mk_noise(13, 0.014, 4).get_seamless_image(NOISE_RES, NOISE_RES)
	var bytes := PackedByteArray()
	bytes.resize(NOISE_RES * NOISE_RES * 4)
	var k: int = 0
	for y in range(NOISE_RES):
		for x in range(NOISE_RES):
			bytes[k] = int(ia.get_pixel(x, y).r * 255.0)
			bytes[k + 1] = int(ib.get_pixel(x, y).r * 255.0)
			bytes[k + 2] = int(ic.get_pixel(x, y).r * 255.0)
			bytes[k + 3] = 255
			k += 4
	var img: Image = Image.create_from_data(NOISE_RES, NOISE_RES, false, Image.FORMAT_RGBA8, bytes)
	img.generate_mipmaps()
	noise_tex = ImageTexture.create_from_image(img)

func _make_surface_texture() -> void:
	var bytes := PackedByteArray()
	bytes.resize(G * G * 4)
	for idx in range(G * G):
		bytes[idx * 4] = int(clampf(mud[idx], 0.0, 1.0) * 255.0)
		bytes[idx * 4 + 1] = int(clampf(rock[idx], 0.0, 1.0) * 255.0)
		bytes[idx * 4 + 2] = int(clampf(trl[idx], 0.0, 1.0) * 255.0)
		bytes[idx * 4 + 3] = int(clampf(pot[idx], 0.0, 1.0) * 255.0)
	var img: Image = Image.create_from_data(G, G, false, Image.FORMAT_RGBA8, bytes)
	surface_tex = ImageTexture.create_from_image(img)

# =====================================================================================
#  Height / mud / water fields
# =====================================================================================
func _build_fields() -> void:
	var total: int = G * G
	hgt.resize(total)
	mud.resize(total)
	rock.resize(total)
	trl.resize(total)
	pot.resize(total)
	slp.resize(total)
	cavg.resize(total)
	_bog.resize(total)
	_dmin.resize(total)
	_lat.resize(total)
	_along.resize(total)
	_dmin.fill(1.0e9)
	_lat.fill(0.0)
	_along.fill(0.0)

	# ---- 1. rolling hills + rim + rock outcrop hill
	var nl := _mk_noise(seed_value + 1, 0.018, 3)
	var nm := _mk_noise(seed_value + 2, 0.050, 2)
	var nf := _mk_noise(seed_value + 3, 0.160, 2)
	for j in range(G):
		var z: float = -HALF + float(j) * STEP
		for i in range(G):
			var x: float = -HALF + float(i) * STEP
			var e: float = maxf(absf(x), absf(z))
			var rim: float = 8.0 * smoothstep(31.0, 37.5, e)
			var ox: float = x - _outcrop_c.x
			var oz: float = z - _outcrop_c.y
			var hill: float = 3.2 * exp(-(ox * ox + oz * oz) / 112.0)
			hgt[j * G + i] = 4.0 + nl.get_noise_2d(x, z) * 3.0 + nm.get_noise_2d(x, z) * 0.9 + nf.get_noise_2d(x, z) * 0.1 + hill + rim

	# ---- 2. trails (main trail through the pond ford, branch trail through the bog)
	_main_path = _catmull([Vector2(-30, 29), Vector2(-20, 24), Vector2(-9, 21), Vector2(-1, 13), Vector2(3, 3), Vector2(5, -5), Vector2(7, -11), Vector2(13, -17), Vector2(21, -22), Vector2(29, -30)], 1.2)
	_branch_path = _catmull([Vector2(-1, 13), Vector2(-10, 8), Vector2(-19, 3), Vector2(-24, -5), Vector2(-28, -14), Vector2(-26, -23), Vector2(-18, -29)], 1.2)
	_raster(_main_path, 0.0)
	_raster(_branch_path, 400.0)

	# trail follows a smoothed version of the terrain
	var hb: PackedFloat32Array = _blur(hgt, 8)
	for idx in range(total):
		var w: float = 1.0 - smoothstep(2.2, 6.5, _dmin[idx])
		hgt[idx] = lerpf(hgt[idx], hb[idx], w * 0.95)

	# ---- 3. pond (flat plateau + bowl, shallower on the trail = ford) and bog
	var hpc: float = _bil(hgt, _pond_c.x, _pond_c.y)
	_pond_level = hpc - 0.06           # was hpc - 0.30: pond is 24 cm higher (fuller pond, deeper ford, wider shore)
	for j in range(G):
		var z2: float = -HALF + float(j) * STEP
		for i in range(G):
			var x2: float = -HALF + float(i) * STEP
			var idx2: int = j * G + i
			var q: float = _pond_q(x2, z2)
			var h: float = hgt[idx2]
			h = lerpf(h, hpc, 1.0 - smoothstep(1.25, 1.9, q))
			var tw: float = 1.0 - smoothstep(2.2, 6.5, _dmin[idx2])
			h -= 1.3 * (1.0 - smoothstep(0.35, 1.0, q)) * (1.0 - 0.62 * tw)
			var bd: float = sqrt((x2 - _bog_c.x) * (x2 - _bog_c.x) + (z2 - _bog_c.y) * (z2 - _bog_c.y))
			var bog: float = 1.0 - smoothstep(3.5, 7.0, bd)
			h -= 0.35 * bog
			hgt[idx2] = h
			_bog[idx2] = bog

	# ---- 4. mud
	var nmud := _mk_noise(seed_value + 4, 0.06, 2)
	var hb2: PackedFloat32Array = _blur(hgt, 10)
	for j in range(G):
		var z3: float = -HALF + float(j) * STEP
		for i in range(G):
			var x3: float = -HALF + float(i) * STEP
			var id3: int = j * G + i
			var nv: float = nmud.get_noise_2d(x3, z3)
			var core: float = 1.0 - smoothstep(1.9, 3.0, _dmin[id3])
			var mm: float = core * (0.25 + 0.75 * smoothstep(-0.1, 0.35, nv))
			mm = maxf(mm, _bog[id3] * (0.85 + 0.15 * nv))
			var q3: float = _pond_q(x3, z3)
			var hl: float = hgt[id3] - _pond_level
			mm = maxf(mm, (1.0 - smoothstep(0.02, 0.45, hl)) * (1.0 - smoothstep(0.9, 1.25, q3)))
			var lowcav: float = clampf((hb2[id3] - hgt[id3]) * 5.0, 0.0, 1.0)
			mm = maxf(mm, smoothstep(0.25, 0.6, lowcav) * 0.6)
			mud[id3] = clampf(mm, 0.0, 1.0)

	# ---- 5. ruts (two tyre grooves + centre hump) + micro relief
	var nr := _mk_noise(seed_value + 5, 0.07, 2)
	var nmic := _mk_noise(seed_value + 6, 0.60, 2)
	for j in range(G):
		var z4: float = -HALF + float(j) * STEP
		for i in range(G):
			var x4: float = -HALF + float(i) * STEP
			var id4: int = j * G + i
			var d: float = _dmin[id4]
			var core4: float = 1.0 - smoothstep(1.7, 2.6, d)
			if d < 3.2:
				var l: float = _lat[id4]
				var u: float = (absf(l) - 0.92) / 0.30
				var rut: float = exp(-u * u)
				var hump: float = exp(-(l / 0.45) * (l / 0.45))
				var depth: float = 0.10 + 0.14 * (0.5 + 0.5 * nr.get_noise_2d(_along[id4], 0.0)) + 0.20 * mud[id4]
				hgt[id4] += core4 * (0.045 * hump - depth * rut)
			hgt[id4] += nmic.get_noise_2d(x4, z4) * 0.035 * (0.5 + core4)

	# ---- 6. slope, rock, trail, puddle potential, cavity
	for j in range(G):
		for i in range(G):
			var il: int = maxi(i - 1, 0)
			var ir: int = mini(i + 1, G - 1)
			var ju: int = maxi(j - 1, 0)
			var jd: int = mini(j + 1, G - 1)
			var gx: float = (hgt[j * G + ir] - hgt[j * G + il]) / (float(ir - il) * STEP)
			var gz: float = (hgt[jd * G + i] - hgt[ju * G + i]) / (float(jd - ju) * STEP)
			slp[j * G + i] = sqrt(gx * gx + gz * gz)
	var nrk := _mk_noise(seed_value + 7, 0.09, 2)
	var hb3: PackedFloat32Array = _blur(hgt, 3)
	var hb4: PackedFloat32Array = _blur(hgt, 1)
	for j in range(G):
		var z5: float = -HALF + float(j) * STEP
		for i in range(G):
			var x5: float = -HALF + float(i) * STEP
			var id5: int = j * G + i
			var d5: float = _dmin[id5]
			var core5: float = 1.0 - smoothstep(1.9, 3.0, d5)
			trl[id5] = 1.0 - smoothstep(2.0, 3.8, d5)
			var ox2: float = x5 - _outcrop_c.x
			var oz2: float = z5 - _outcrop_c.y
			var zone: float = exp(-(ox2 * ox2 + oz2 * oz2) / 162.0)
			var r: float = smoothstep(0.5, 0.85, slp[id5] + 0.12 * nrk.get_noise_2d(x5, z5))
			r = maxf(r, smoothstep(0.1, 0.5, zone * (0.6 + 0.8 * nrk.get_noise_2d(x5 * 2.0, z5 * 2.0))))
			r *= (1.0 - core5 * 0.85) * (1.0 - mud[id5])
			rock[id5] = clampf(r, 0.0, 1.0)
			var cv: float = hb3[id5] - hgt[id5]
			var p: float = smoothstep(0.012, 0.12, cv) * (1.0 - smoothstep(0.22, 0.45, slp[id5])) * (1.0 - rock[id5])
			p = maxf(p, _bog[id5] * 0.9)
			if _pond_q(x5, z5) < 1.25 and hgt[id5] < _pond_level + 0.02:
				p = 0.0
			pot[id5] = clampf(p, 0.0, 1.0)
		cavg[id5] = 1.0 - clampf((hb4[id5] - hgt[id5]) * 5.0, 0.0, 0.55)

	# ---- 7. Replace the old muddy pond test map with a broad sandy coast and open sea.
	_pond_level = SEA_LEVEL
	for j in range(G):
		var zc: float = -HALF + float(j) * STEP
		for i in range(G):
			var xc: float = -HALF + float(i) * STEP
			var idc: int = j * G + i
			var inland: float = _coastline_z(xc) - zc
			var original_h: float = hgt[idc]
			var beach_noise: float = sin(xc * 0.42 + zc * 0.17) * 0.045 + sin(xc * 0.91 - zc * 0.31) * 0.018
			var coastal_h: float = SEA_LEVEL + inland * 0.19 + beach_noise
			var blend_inland: float = smoothstep(8.0, 16.0, inland)
			hgt[idc] = lerpf(coastal_h, original_h, blend_inland)
			# Keep the shoreline pale, dry and rideable; the sea bed has no mud puddles.
			if inland < 10.0:
				mud[idc] = 0.0
				rock[idc] = 0.0
				pot[idc] = 0.0
				trl[idc] = 0.0
				_bog[idc] = 0.0

# =====================================================================================
#  Materials, terrain chunks, collision, water, boundary
# =====================================================================================
func _shader_mat(code: String) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = code
	var m := ShaderMaterial.new()
	m.shader = sh
	return m

func _make_foliage_mat(shape: int, ca: Color, cb: Color, wind: float) -> ShaderMaterial:
	var m: ShaderMaterial = _shader_mat(FOLIAGE_SHADER)
	m.set_shader_parameter("shape", shape)
	m.set_shader_parameter("tint_a", Vector3(ca.r, ca.g, ca.b))
	m.set_shader_parameter("tint_b", Vector3(cb.r, cb.g, cb.b))
	m.set_shader_parameter("wind", wind)
	return m

# Seamless wave slope texture: RG = low-frequency swell slope, BA = ripple slope (0.5 = flat). 128 px so it is cheap to build on a phone.
func _make_water_normal() -> void:
	var res: int = 128
	var cfg: Array = [[21, 0.022, 3], [22, 0.075, 3]]
	var bytes := PackedByteArray()
	bytes.resize(res * res * 4)
	for layer in range(2):
		var nz: FastNoiseLite = _mk_noise(int(cfg[layer][0]), float(cfg[layer][1]), int(cfg[layer][2]))
		var im: Image = nz.get_seamless_image(res, res)
		var h := PackedFloat32Array()
		h.resize(res * res)
		for y in range(res):
			for x in range(res):
				h[y * res + x] = im.get_pixel(x, y).r
		var gx := PackedFloat32Array()
		var gy := PackedFloat32Array()
		gx.resize(res * res)
		gy.resize(res * res)
		var mx: float = 0.0001
		for y in range(res):
			var yu: int = (y - 1 + res) % res
			var yd: int = (y + 1) % res
			for x in range(res):
				var xl: int = (x - 1 + res) % res
				var xr: int = (x + 1) % res
				var dx: float = h[y * res + xr] - h[y * res + xl]
				var dy: float = h[yd * res + x] - h[yu * res + x]
				gx[y * res + x] = -dx
				gy[y * res + x] = -dy
				mx = maxf(mx, maxf(absf(dx), absf(dy)))
		for i in range(res * res):
			bytes[i * 4 + layer * 2] = int(clampf(0.5 + 0.5 * gx[i] / mx, 0.0, 1.0) * 255.0)
			bytes[i * 4 + layer * 2 + 1] = int(clampf(0.5 + 0.5 * gy[i] / mx, 0.0, 1.0) * 255.0)
	var img: Image = Image.create_from_data(res, res, false, Image.FORMAT_RGBA8, bytes)
	img.generate_mipmaps()
	water_nrm = ImageTexture.create_from_image(img)

func _make_materials() -> void:
	_make_surface_texture()
	terrain_mat = ShaderMaterial.new()
	terrain_mat.shader = load(TERRAIN_SHADER) as Shader
	terrain_mat.set_shader_parameter("surface_map", surface_tex)
	terrain_mat.set_shader_parameter("noise_tex", noise_tex)
	terrain_mat.set_shader_parameter("map_size", MAP_SIZE)
	terrain_mat.set_shader_parameter("map_uv_scale", Vector2(float(G - 1) / float(G), float(G - 1) / float(G)))
	terrain_mat.set_shader_parameter("map_uv_offset", Vector2(0.5 / float(G), 0.5 / float(G)))
	terrain_mat.set_shader_parameter("puddle_max", PUDDLE_MAX)
	terrain_mat.set_shader_parameter("puddle_dry_bias", PUDDLE_DRY_BIAS)
	for tn in ["grass", "gravel", "mud", "rock"]:
		terrain_mat.set_shader_parameter(tn + "_d", load("res://assets/tex/pbr/" + tn + "_d.jpg"))
		terrain_mat.set_shader_parameter(tn + "_n", load("res://assets/tex/pbr/" + tn + "_n.png"))
	water_mat = _shader_mat(WATER_SHADER)
	water_mat.set_shader_parameter("noise_tex", noise_tex)
	water_mat.set_shader_parameter("foam_tex", load("res://assets/sadox/WaterFoam.png"))
	_make_water_normal()
	water_mat.set_shader_parameter("wave_nrm", water_nrm)
	prop_mat = _shader_mat(PROP_SHADER)
	prop_mat.set_shader_parameter("noise_tex", noise_tex)
	rock_mat = _shader_mat(PROP_SHADER)
	rock_mat.set_shader_parameter("noise_tex", noise_tex)
	rock_mat.set_shader_parameter("tex_d", load("res://assets/tex/pbr/rock_d.jpg"))
	rock_mat.set_shader_parameter("tex_mix", 0.85)
	grass_mat = _make_foliage_mat(0, Color(0.10, 0.20, 0.05), Color(0.38, 0.58, 0.16), 0.10)
	fern_mat = _make_foliage_mat(2, Color(0.07, 0.22, 0.06), Color(0.24, 0.50, 0.14), 0.05)
	shrub_mat = _make_foliage_mat(1, Color(0.09, 0.22, 0.06), Color(0.28, 0.48, 0.12), 0.05)

func _normal_at(i: int, j: int) -> Vector3:
	var hl: float = hgt[j * G + maxi(i - 1, 0)]
	var hr: float = hgt[j * G + mini(i + 1, G - 1)]
	var hu: float = hgt[maxi(j - 1, 0) * G + i]
	var hd: float = hgt[mini(j + 1, G - 1) * G + i]
	return Vector3(hl - hr, 2.0 * STEP, hu - hd).normalized()

func _build_terrain_meshes() -> void:
	var w: int = CHUNK_CELLS + 1
	for cz in range(CHUNKS):
		for cx in range(CHUNKS):
			var i0: int = cx * CHUNK_CELLS
			var j0: int = cz * CHUNK_CELLS
			var verts := PackedVector3Array()
			var nrms := PackedVector3Array()
			var cols := PackedColorArray()
			var idxs := PackedInt32Array()
			for j in range(w):
				for i in range(w):
					var gi: int = i0 + i
					var gj: int = j0 + j
					verts.append(Vector3(-HALF + float(gi) * STEP, hgt[gj * G + gi], -HALF + float(gj) * STEP))
					nrms.append(_normal_at(gi, gj))
					cols.append(Color(cavg[gj * G + gi], 0.0, 0.0, 1.0))
			for j in range(CHUNK_CELLS):
				for i in range(CHUNK_CELLS):
					var a: int = j * w + i
					var b: int = a + 1
					var c: int = a + w
					var d: int = c + 1
					idxs.append(a)
					idxs.append(b)
					idxs.append(c)
					idxs.append(b)
					idxs.append(d)
					idxs.append(c)
			var arrays: Array = []
			arrays.resize(Mesh.ARRAY_MAX)
			arrays[Mesh.ARRAY_VERTEX] = verts
			arrays[Mesh.ARRAY_NORMAL] = nrms
			arrays[Mesh.ARRAY_COLOR] = cols
			arrays[Mesh.ARRAY_INDEX] = idxs
			var mesh := ArrayMesh.new()
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			var mi := MeshInstance3D.new()
			mi.name = "Terrain_%d_%d" % [cx, cz]
			mi.mesh = mesh
			mi.material_override = terrain_mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if terrain_casts_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(mi)

func _vtx(i: int, j: int) -> Vector3:
	return Vector3(-HALF + float(i) * STEP, hgt[j * G + i], -HALF + float(j) * STEP)

func _build_collision() -> void:
	var faces := PackedVector3Array()
	for j in range(0, CELLS, COL_STEP):
		for i in range(0, CELLS, COL_STEP):
			var p00: Vector3 = _vtx(i, j)
			var p10: Vector3 = _vtx(i + COL_STEP, j)
			var p01: Vector3 = _vtx(i, j + COL_STEP)
			var p11: Vector3 = _vtx(i + COL_STEP, j + COL_STEP)
			faces.append(p00)
			faces.append(p10)
			faces.append(p01)
			faces.append(p10)
			faces.append(p11)
			faces.append(p01)
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(faces)
	var body := StaticBody3D.new()
	body.name = "TerrainBody"
	var cs := CollisionShape3D.new()
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	_prop_body = StaticBody3D.new()
	_prop_body.name = "PropBody"
	_prop_body.collision_layer = 3     # layers 1+2: the car only collides with layer 2 (it rides the terrain on springs)
	add_child(_prop_body)

func _build_water() -> void:
	# Full-width ocean sheet. Vertex alpha fades at the irregular shoreline so the
	# wet sand remains visible and the existing water shader supplies waves/foam.
	var verts := PackedVector3Array()
	var nrms := PackedVector3Array()
	var cols := PackedColorArray()
	var idxs := PackedInt32Array()
	verts.resize(G * G)
	nrms.resize(G * G)
	cols.resize(G * G)
	for j in range(G):
		var z: float = -HALF + float(j) * STEP
		for i in range(G):
			var x: float = -HALF + float(i) * STEP
			var id: int = j * G + i
			var dep: float = _pond_level - hgt[id]
			var shore_dist: float = z - _coastline_z(x)
			var shore_alpha: float = smoothstep(-0.22, 0.75, shore_dist) * smoothstep(-0.05, 0.28, dep)
			verts[id] = Vector3(x, _pond_level, z)
			nrms[id] = Vector3.UP
			cols[id] = Color(clampf(0.5 + dep / 3.2, 0.0, 1.0), 1.0, 1.0, shore_alpha)
	for j in range(G - 1):
		for i in range(G - 1):
			var a: int = j * G + i
			var b: int = a + 1
			var c: int = a + G
			var d: int = c + 1
			if cols[a].a + cols[b].a + cols[c].a + cols[d].a <= 0.001:
				continue
			idxs.append(a)
			idxs.append(b)
			idxs.append(c)
			idxs.append(b)
			idxs.append(d)
			idxs.append(c)
	if idxs.is_empty():
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = nrms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idxs
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var mi := MeshInstance3D.new()
	mi.name = "PondWater"
	mi.mesh = mesh
	mi.material_override = water_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func _build_boundary() -> void:
	var body := StaticBody3D.new()
	body.name = "Boundary"
	body.collision_layer = 3
	add_child(body)
	for k in range(4):
		var horiz: bool = k < 2
		var sgn: float = 1.0 if (k % 2 == 0) else -1.0
		var bs := BoxShape3D.new()
		var cs := CollisionShape3D.new()
		if horiz:
			bs.size = Vector3(MAP_SIZE + 4.0, 80.0, 2.0)
			cs.position = Vector3(0.0, 20.0, sgn * (HALF + 1.0))
		else:
			bs.size = Vector3(2.0, 80.0, MAP_SIZE + 4.0)
			cs.position = Vector3(sgn * (HALF + 1.0), 20.0, 0.0)
		cs.shape = bs
		body.add_child(cs)

func _pick_spawn() -> void:
	# Start safely inland, facing toward the beach and ocean.
	var start_point := Vector2(-10.0, -13.0)
	spawn_position = get_safe_position(Vector3(start_point.x, 0.0, start_point.y), 1.0)
	spawn_yaw = PI

# =====================================================================================
#  Procedural meshes (rocks, tubes, tyres, trees, foliage)
# =====================================================================================
func _ico_mid(v: Array, cache: Dictionary, a: int, b: int) -> int:
	var key: int = mini(a, b) * 100000 + maxi(a, b)
	if cache.has(key):
		return cache[key]
	var m: Vector3 = ((v[a] as Vector3) + (v[b] as Vector3)).normalized()
	v.append(m)
	cache[key] = v.size() - 1
	return v.size() - 1

func _icosphere(subdiv: int) -> Array:
	var t: float = (1.0 + sqrt(5.0)) * 0.5
	var v: Array = [Vector3(-1, t, 0), Vector3(1, t, 0), Vector3(-1, -t, 0), Vector3(1, -t, 0), Vector3(0, -1, t), Vector3(0, 1, t), Vector3(0, -1, -t), Vector3(0, 1, -t), Vector3(t, 0, -1), Vector3(t, 0, 1), Vector3(-t, 0, -1), Vector3(-t, 0, 1)]
	for k in range(v.size()):
		v[k] = (v[k] as Vector3).normalized()
	var faces: Array = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]]
	for s in range(subdiv):
		var cache := {}
		var nf: Array = []
		for f in faces:
			var a: int = f[0]
			var b: int = f[1]
			var c: int = f[2]
			var ab: int = _ico_mid(v, cache, a, b)
			var bc: int = _ico_mid(v, cache, b, c)
			var ca: int = _ico_mid(v, cache, c, a)
			nf.append([a, ab, ca])
			nf.append([b, bc, ab])
			nf.append([c, ca, bc])
			nf.append([ab, bc, ca])
		faces = nf
	return [v, faces]

# angular, chiselled boulder: sphere + noise + random cutting planes, flat bottom
func _make_rock(subdiv: int, nseed: int, squash: Vector3, planes: int, roughness: float, col_a: Color, col_b: Color) -> ArrayMesh:
	var ico: Array = _icosphere(subdiv)
	var verts: Array = ico[0]
	var faces: Array = ico[1]
	var r := RandomNumberGenerator.new()
	r.seed = nseed
	var nz := _mk_noise(nseed, 1.0, 4)
	var pl_n: Array = []
	var pl_o: Array = []
	for k in range(planes):
		pl_n.append(Vector3(r.randf_range(-1.0, 1.0), r.randf_range(-0.6, 1.0), r.randf_range(-1.0, 1.0)).normalized())
		pl_o.append(r.randf_range(0.62, 0.9))
	var mb := MB.new()
	for d in verts:
		var dir: Vector3 = d
		var rad: float = 1.0 + roughness * nz.get_noise_3dv(dir * 1.7)
		var p: Vector3 = Vector3(dir.x * squash.x, dir.y * squash.y, dir.z * squash.z) * rad
		for k in range(planes):
			var nn: Vector3 = pl_n[k]
			var off: float = pl_o[k]
			var dd: float = p.dot(nn) - off
			if dd > 0.0:
				p -= nn * dd
		p += dir * roughness * 0.06 * nz.get_noise_3dv(dir * 7.0)
		p.y = maxf(p.y, -0.42 * squash.y)
		var cn: float = nz.get_noise_3dv(dir * 1.1 + Vector3(4.0, 2.0, 7.0)) * 0.5 + 0.5
		var col: Color = col_a.lerp(col_b, cn)
		col = col.darkened(clampf(-dir.y * 0.35, 0.0, 0.4))
		mb.vert(p, col)
	for f in faces:
		var i0: int = f[0]
		var i1: int = f[1]
		var i2: int = f[2]
		mb.tri(i0, i1, i2, (mb.v[i0] + mb.v[i1] + mb.v[i2]) / 3.0)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, rock_mat)
	return mesh

# tapered, noisy tube along local +X (logs, branches, planks, tree limbs, trunks)
func _add_tube(mb: MB, xf: Transform3D, length: float, rings: int, segs: int, r0: float, r1: float, squash: Vector2, pexp: float, bend: float, noise_amp: float, nseed: int, col_side: Color, col_cap: Color, col_var: float, cap_start: bool = true, cap_end: bool = true) -> void:
	var nz := _mk_noise(nseed, 1.3, 3)
	var base: int = mb.v.size()
	for r in range(rings + 1):
		var t: float = float(r) / float(rings)
		var x: float = t * length
		var yb: float = bend * sin(t * PI)
		var rad: float = lerpf(r0, r1, t)
		for s in range(segs):
			var a: float = TAU * float(s) / float(segs)
			var ca: float = cos(a)
			var sa: float = sin(a)
			var k: float = pow(pow(absf(ca), pexp) + pow(absf(sa), pexp), -1.0 / pexp)
			var rr: float = rad * (1.0 + noise_amp * nz.get_noise_3d(ca * 1.5, sa * 1.5, x * 3.0))
			var lp: Vector3 = Vector3(x, yb + ca * k * rr * squash.x, sa * k * rr * squash.y)
			var cn: float = nz.get_noise_3d(ca * 0.8 + 3.0, sa * 0.8, x * 1.2) * 0.5 + 0.5
			mb.vert(xf * lp, col_side.darkened(cn * col_var))
	for r in range(rings):
		for s in range(segs):
			var am: float = TAU * (float(s) + 0.5) / float(segs)
			var hint: Vector3 = xf.basis * Vector3(0.0, cos(am), sin(am))
			var a0: int = base + r * segs + s
			var b0: int = base + r * segs + (s + 1) % segs
			var c0: int = a0 + segs
			var d0: int = b0 + segs
			mb.tri(a0, b0, c0, hint)
			mb.tri(b0, d0, c0, hint)
	if cap_start:
		_add_cap(mb, base, segs, col_cap, xf.basis * Vector3(-1.0, 0.0, 0.0))
	if cap_end:
		_add_cap(mb, base + rings * segs, segs, col_cap, xf.basis * Vector3(1.0, 0.0, 0.0))

func _add_cap(mb: MB, ring_base: int, segs: int, col: Color, hint: Vector3) -> void:
	var ids: Array = []
	var c: Vector3 = Vector3.ZERO
	for s in range(segs):
		ids.append(mb.vert(mb.v[ring_base + s], col))
		c += mb.v[ring_base + s]
	c /= float(segs)
	var ci: int = mb.vert(c, col.lightened(0.1))
	for s in range(segs):
		mb.tri(ci, ids[s], ids[(s + 1) % segs], hint)

func _tube_mesh(length: float, rings: int, segs: int, r0: float, r1: float, squash: Vector2, pexp: float, bend: float, noise_amp: float, nseed: int, col_side: Color, col_cap: Color, col_var: float) -> ArrayMesh:
	var mb := MB.new()
	_add_tube(mb, Transform3D(Basis.IDENTITY, Vector3(-length * 0.5, 0.0, 0.0)), length, rings, segs, r0, r1, squash, pexp, bend, noise_amp, nseed, col_side, col_cap, col_var)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, prop_mat)
	return mesh

func _make_tire() -> ArrayMesh:
	var mb := MB.new()
	var nz := _mk_noise(seed_value + 31, 1.5, 2)
	var big_r: float = 0.34
	var small_r: float = 0.13
	var maj: int = 22
	var mnr: int = 10
	for a in range(maj):
		var th: float = TAU * float(a) / float(maj)
		for b in range(mnr):
			var ph: float = TAU * float(b) / float(mnr)
			var lug: float = 0.06 * float(a % 2) * smoothstep(0.3, 0.9, cos(ph))
			var rr: float = small_r * (1.0 + lug) * (1.0 + 0.05 * nz.get_noise_2d(th * 3.0, ph * 3.0))
			var p: Vector3 = Vector3((big_r + rr * cos(ph)) * cos(th), rr * 1.3 * sin(ph), (big_r + rr * cos(ph)) * sin(th))
			var shade: float = 0.5 + 0.5 * nz.get_noise_2d(th * 2.0, ph * 2.0)
			mb.vert(p, Color(0.055, 0.055, 0.06).lightened(shade * 0.25))
	for a in range(maj):
		for b in range(mnr):
			var a0: int = a * mnr + b
			var b0: int = a * mnr + (b + 1) % mnr
			var c0: int = ((a + 1) % maj) * mnr + b
			var d0: int = ((a + 1) % maj) * mnr + (b + 1) % mnr
			var ctr: Vector3 = Vector3(big_r * cos(TAU * (float(a) + 0.5) / float(maj)), 0.0, big_r * sin(TAU * (float(a) + 0.5) / float(maj)))
			var hint: Vector3 = (mb.v[a0] + mb.v[d0]) * 0.5 - ctr
			mb.tri(a0, b0, c0, hint)
			mb.tri(b0, d0, c0, hint)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, prop_mat)
	return mesh

func _add_card(mb: MB, center: Vector3, normal: Vector3, size: float, shade: float, sway: float) -> void:
	var n: Vector3 = normal.normalized()
	var t1: Vector3 = n.cross(Vector3.UP)
	if t1.length() < 0.05:
		t1 = n.cross(Vector3.RIGHT)
	t1 = t1.normalized()
	var t2: Vector3 = n.cross(t1).normalized()
	var col := Color(shade, shade, shade, sway)
	var h: float = size * 0.5
	var v0: int = mb.vert(center - t1 * h - t2 * h, col, Vector2(0, 0))
	var v1: int = mb.vert(center + t1 * h - t2 * h, col, Vector2(1, 0))
	var v2: int = mb.vert(center + t1 * h + t2 * h, col, Vector2(1, 1))
	var v3: int = mb.vert(center - t1 * h + t2 * h, col, Vector2(0, 1))
	mb.tri(v0, v1, v2, n)
	mb.tri(v0, v2, v3, n)

# broadleaf tree: noisy trunk, root buttresses, 7 limbs, leaf-cluster cards (alpha-scissor shader)
func _make_tree(nseed: int, height: float, leaf_a: Color, leaf_b: Color) -> ArrayMesh:
	var r := RandomNumberGenerator.new()
	r.seed = nseed
	var k_s: float = height / 6.5
	var bark := MB.new()
	var leaves := MB.new()
	var trunk_h: float = height * 0.62
	var rb: float = 0.30 * k_s
	var bark_c := Color(0.20, 0.14, 0.09)
	var up_basis := Basis(Vector3(0, 1, 0), Vector3(-1, 0, 0), Vector3(0, 0, 1))
	_add_tube(bark, Transform3D(up_basis, Vector3.ZERO), trunk_h, 12, 10, rb, rb * 0.28, Vector2.ONE, 2.0, 0.0, 0.10, nseed, bark_c, bark_c, 0.6, false, true)
	for k in range(4):
		var phi: float = TAU * float(k) / 4.0 + r.randf() * 0.6
		var d: Vector3 = Vector3(cos(phi), -0.25, sin(phi)).normalized()
		var y_ax: Vector3 = (Vector3.UP - d * Vector3.UP.dot(d)).normalized()
		_add_tube(bark, Transform3D(Basis(d, y_ax, d.cross(y_ax)), Vector3(0, 0.25 * k_s, 0)), 0.9 * k_s, 4, 6, rb * 0.6, rb * 0.1, Vector2.ONE, 2.0, 0.0, 0.1, nseed + 50 + k, bark_c, bark_c, 0.5, false, true)
	var tips: Array = []
	for k in range(7):
		var f: float = float(k) / 6.0
		var hb: float = trunk_h * (0.45 + 0.55 * f)
		var phi2: float = r.randf() * TAU + float(k) * 2.4
		var elev: float = deg_to_rad(r.randf_range(25.0, 55.0))
		var d2: Vector3 = Vector3(cos(phi2) * cos(elev), sin(elev), sin(phi2) * cos(elev)).normalized()
		var blen: float = r.randf_range(1.6, 2.6) * k_s
		var y2: Vector3 = (Vector3.UP - d2 * Vector3.UP.dot(d2)).normalized()
		var org: Vector3 = Vector3(0, hb, 0)
		_add_tube(bark, Transform3D(Basis(d2, y2, d2.cross(y2)), org), blen, 5, 6, 0.10 * k_s, 0.025 * k_s, Vector2.ONE, 2.0, 0.12 * k_s, 0.08, nseed + 10 + k, bark_c, bark_c, 0.5, false, true)
		tips.append(org + d2 * blen)
	tips.append(Vector3(0, trunk_h + 0.6 * k_s, 0))
	for ti in range(tips.size()):
		var tip: Vector3 = tips[ti]
		var cards: int = 16 if ti == tips.size() - 1 else 12
		for c in range(cards):
			var off: Vector3 = Vector3(r.randf_range(-1.0, 1.0), r.randf_range(-0.6, 1.0), r.randf_range(-1.0, 1.0)).normalized() * r.randf_range(0.2, 1.2) * k_s
			var ctr: Vector3 = tip + off
			var nrm: Vector3 = Vector3(r.randf_range(-1.0, 1.0), r.randf_range(-1.0, 1.0), r.randf_range(-1.0, 1.0))
			var shade: float = clampf(0.62 + 0.4 * (ctr.y / height) + r.randf_range(-0.1, 0.1), 0.45, 1.0)
			_add_card(leaves, ctr, nrm, r.randf_range(1.2, 1.8) * k_s, shade, 1.0)
	var mesh := ArrayMesh.new()
	bark.add_to(mesh)
	leaves.add_to(mesh)
	mesh.surface_set_material(0, prop_mat)
	mesh.surface_set_material(1, _make_foliage_mat(1, leaf_a, leaf_b, 0.04))
	return mesh

func _make_grass_mesh() -> ArrayMesh:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value + 90
	var mb := MB.new()
	for b in range(11):
		var ang: float = r.randf() * TAU
		var off: Vector2 = Vector2(cos(ang), sin(ang)) * r.randf_range(0.0, 0.18)
		var yaw: float = r.randf() * TAU
		var dir: Vector3 = Vector3(cos(yaw), 0.0, sin(yaw))
		var side: Vector3 = Vector3(-sin(yaw), 0.0, cos(yaw))
		var h: float = r.randf_range(0.30, 0.62)
		var w: float = r.randf_range(0.018, 0.032)
		var lean: float = r.randf_range(0.1, 0.45)
		var base: Vector3 = Vector3(off.x, 0.0, off.y)
		var tint: float = r.randf()
		var ids: Array = []
		for ri in range(4):
			var t: float = [0.0, 0.35, 0.7, 1.0][ri]
			var pos: Vector3 = base + dir * (lean * h * t * t * 1.4) + Vector3.UP * (h * t * (1.0 - 0.25 * t * lean))
			var ww: float = w * (1.0 - 0.85 * t * t)
			var col: Color = Color(0.09, 0.17, 0.04).lerp(Color(0.38, 0.58, 0.16), clampf(t * 0.9 + tint * 0.15, 0.0, 1.0))
			col.a = t * t
			ids.append([mb.vert(pos - side * ww, col), mb.vert(pos + side * ww, col)])
		for k in range(3):
			var l0: int = ids[k][0]
			var r0: int = ids[k][1]
			var l1: int = ids[k + 1][0]
			var r1: int = ids[k + 1][1]
			mb.tri(l0, r0, l1, dir)
			mb.tri(r0, r1, l1, dir)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, grass_mat)
	return mesh

func _make_fern_mesh() -> ArrayMesh:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value + 91
	var mb := MB.new()
	for f in range(9):
		var yaw: float = TAU * float(f) / 9.0 + r.randf() * 0.4
		var dir: Vector3 = Vector3(cos(yaw), 0.0, sin(yaw))
		var side: Vector3 = Vector3(-sin(yaw), 0.0, cos(yaw))
		var flen: float = r.randf_range(0.55, 0.85)
		var wd: float = r.randf_range(0.16, 0.24)
		var rise: float = r.randf_range(0.28, 0.5)
		var ids: Array = []
		for ri in range(4):
			var t: float = [0.0, 0.33, 0.66, 1.0][ri]
			var pos: Vector3 = dir * (flen * t) + Vector3.UP * (rise * sin(t * PI * 0.75) + 0.05)
			var sh: float = 0.65 + 0.35 * t
			var col := Color(sh, sh, sh, t * t)
			ids.append([mb.vert(pos - side * wd, col, Vector2(0.0, t)), mb.vert(pos + side * wd, col, Vector2(1.0, t))])
		for k in range(3):
			var l0: int = ids[k][0]
			var r0: int = ids[k][1]
			var l1: int = ids[k + 1][0]
			var r1: int = ids[k + 1][1]
			mb.tri(l0, r0, l1, Vector3.UP)
			mb.tri(r0, r1, l1, Vector3.UP)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, fern_mat)
	return mesh

func _make_shrub_mesh() -> ArrayMesh:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value + 92
	var mb := MB.new()
	for c in range(20):
		var off: Vector3 = Vector3(r.randf_range(-1.0, 1.0), r.randf_range(-0.5, 1.0), r.randf_range(-1.0, 1.0)).normalized() * r.randf_range(0.1, 0.55)
		var ctr: Vector3 = Vector3(0.0, 0.55, 0.0) + off
		var nrm: Vector3 = Vector3(r.randf_range(-1.0, 1.0), r.randf_range(-1.0, 1.0), r.randf_range(-1.0, 1.0))
		_add_card(mb, ctr, nrm, r.randf_range(0.8, 1.2), clampf(0.6 + 0.5 * ctr.y + r.randf_range(-0.1, 0.1), 0.45, 1.0), 1.0)
	var mesh := ArrayMesh.new()
	mb.add_to(mesh)
	mesh.surface_set_material(0, shrub_mat)
	return mesh

# =====================================================================================
#  Scattering (MultiMeshInstance3D) + simple colliders
# =====================================================================================
func _rand_pos(margin: float) -> Vector2:
	return Vector2(rng.randf_range(-HALF + margin, HALF - margin), rng.randf_range(-HALF + margin, HALF - margin))

func _ok(p: Vector2, max_mud: float, max_trail: float, max_slope: float) -> bool:
	if _bil(mud, p.x, p.y) > max_mud:
		return false
	if _bil(trl, p.x, p.y) > max_trail:
		return false
	if _bil(slp, p.x, p.y) > max_slope:
		return false
	var h: float = _bil(hgt, p.x, p.y)
	if _pond_depth(p.x, p.y, h) > 0.0:
		return false
	return true

func _count(n: int) -> int:
	return maxi(0, int(round(float(n) * density_scale)))

func _make_mmi(mesh: Mesh, xforms: Array, shadow: bool, vis_end: float, mname: String) -> void:
	if xforms.size() == 0:
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in range(xforms.size()):
		mm.set_instance_transform(i, xforms[i])
	var mi := MultiMeshInstance3D.new()
	mi.name = mname
	mi.multimesh = mm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if vis_end > 0.0:
		mi.visibility_range_end = vis_end
	add_child(mi)

func _col_sphere(pos: Vector3, radius: float) -> void:
	var cs := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = radius
	cs.shape = sp
	cs.position = pos
	_prop_body.add_child(cs)

func _col_cyl(xf: Transform3D, radius: float, height: float) -> void:
	var cs := CollisionShape3D.new()
	var cy := CylinderShape3D.new()
	cy.radius = radius
	cy.height = height
	cs.shape = cy
	cs.transform = xf
	_prop_body.add_child(cs)

func _ground_xf(p: Vector2, yaw: float, scale: float, sink: float) -> Transform3D:
	var y: float = _bil(hgt, p.x, p.y) - sink * scale
	return Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(scale, scale, scale)), Vector3(p.x, y, p.y))

func _scatter_all() -> void:
	# ---------------- trees
	var tree_a: ArrayMesh = _make_tree(seed_value + 101, 6.5, Color(0.10, 0.24, 0.06), Color(0.30, 0.50, 0.13))
	var tree_b: ArrayMesh = _make_tree(seed_value + 102, 8.0, Color(0.12, 0.25, 0.06), Color(0.36, 0.52, 0.12))
	var tx: Array = [[], []]
	var placed: Array = []
	var want_in: int = _count(tree_count)
	var want_rim: int = _count(rim_tree_count)
	var tries: int = 0
	while placed.size() < want_in and tries < 800:
		tries += 1
		var p: Vector2 = _rand_pos(6.0)
		if not _ok(p, 0.10, 0.02, 0.45):
			continue
		var close: bool = false
		for q in placed:
			if (q as Vector2).distance_to(p) < 5.5:
				close = true
				break
		if close:
			continue
		placed.append(p)
		_add_tree_instance(p, tx, rng.randf_range(0.85, 1.25))
	var rim_placed: Array = []
	tries = 0
	while rim_placed.size() < want_rim and tries < 800:
		tries += 1
		var side: int = rng.randi() % 4
		var along: float = rng.randf_range(-HALF + 1.0, HALF - 1.0)
		var inset: float = rng.randf_range(1.5, 6.5)
		var p2: Vector2
		if side == 0:
			p2 = Vector2(along, -HALF + inset)
		elif side == 1:
			p2 = Vector2(along, HALF - inset)
		elif side == 2:
			p2 = Vector2(-HALF + inset, along)
		else:
			p2 = Vector2(HALF - inset, along)
		if not _ok(p2, 0.2, 0.05, 1.2):
			continue
		var close2: bool = false
		for q2 in rim_placed:
			if (q2 as Vector2).distance_to(p2) < 3.2:
				close2 = true
				break
		if close2:
			continue
		rim_placed.append(p2)
		_add_tree_instance(p2, tx, rng.randf_range(1.1, 1.5))
	_make_mmi(tree_a, tx[0], true, 0.0, "TreesA")
	_make_mmi(tree_b, tx[1], true, 0.0, "TreesB")

	# ---------------- rocks
	var rock0: ArrayMesh = _make_rock(3, seed_value + 201, Vector3(1.0, 0.75, 0.9), 9, 0.22, Color(0.30, 0.28, 0.26), Color(0.52, 0.48, 0.42))
	var rock1: ArrayMesh = _make_rock(2, seed_value + 202, Vector3(1.0, 0.7, 0.85), 7, 0.25, Color(0.28, 0.26, 0.24), Color(0.48, 0.44, 0.38))
	var rock2: ArrayMesh = _make_rock(2, seed_value + 203, Vector3(0.9, 0.6, 1.1), 8, 0.2, Color(0.33, 0.30, 0.27), Color(0.55, 0.50, 0.43))
	var bx: Array = []
	var n_b: int = _count(boulder_count)
	tries = 0
	while bx.size() < n_b and tries < 600:
		tries += 1
		var pb: Vector2 = _outcrop_c + Vector2(rng.randf_range(-9.0, 9.0), rng.randf_range(-9.0, 9.0)) if bx.size() % 2 == 0 else _rand_pos(4.0)
		if absf(pb.x) > HALF - 3.0 or absf(pb.y) > HALF - 3.0:
			continue
		if not _ok(pb, 0.15, 0.55, 0.9):
			continue
		var sb: float = rng.randf_range(0.9, 1.7)
		var xb: Transform3D = _ground_xf(pb, rng.randf() * TAU, sb, 0.15)
		bx.append(xb)
		_col_sphere(xb.origin + Vector3(0, 0.25 * sb, 0), 0.8 * sb)
	_make_mmi(rock0, bx, true, 0.0, "Boulders")
	var m1: Array = []
	var m2: Array = []
	var n_m: int = _count(rock_count)
	tries = 0
	while (m1.size() + m2.size()) < n_m and tries < 600:
		tries += 1
		var pm: Vector2 = _rand_pos(3.0)
		if not _ok(pm, 0.25, 0.6, 0.8):
			continue
		var sm: float = rng.randf_range(0.35, 0.7)
		var xm: Transform3D = _ground_xf(pm, rng.randf() * TAU, sm, 0.12)
		if rng.randf() < 0.5:
			m1.append(xm)
		else:
			m2.append(xm)
		if sm > 0.45:
			_col_sphere(xm.origin + Vector3(0, 0.15 * sm, 0), 0.7 * sm)
	var n_s: int = _count(stone_count)
	tries = 0
	var made: int = 0
	while made < n_s and tries < 1500:
		tries += 1
		var ps: Vector2 = _rand_pos(2.0)
		var trv: float = _bil(trl, ps.x, ps.y)
		if rng.randf() < 0.6 and (trv < 0.08 or trv > 0.75):
			continue
		if not _ok(ps, 0.7, 1.0, 0.7):
			continue
		var ss: float = rng.randf_range(0.12, 0.28)
		var xs: Transform3D = _ground_xf(ps, rng.randf() * TAU, ss, 0.2)
		if rng.randf() < 0.5:
			m1.append(xs)
		else:
			m2.append(xs)
		made += 1
	_make_mmi(rock1, m1, false, 55.0, "RocksA")
	_make_mmi(rock2, m2, false, 55.0, "RocksB")

	# ---------------- logs, tyres, planks, branches
	var log_a: ArrayMesh = _tube_mesh(3.4, 16, 14, 0.25, 0.21, Vector2.ONE, 2.0, 0.03, 0.14, seed_value + 301, Color(0.20, 0.14, 0.09), Color(0.56, 0.45, 0.30), 0.7)
	var log_b: ArrayMesh = _tube_mesh(2.2, 12, 12, 0.18, 0.15, Vector2.ONE, 2.0, 0.04, 0.16, seed_value + 302, Color(0.23, 0.17, 0.11), Color(0.58, 0.47, 0.32), 0.7)
	var lx: Array = [[], []]
	var n_l: int = _count(log_count)
	tries = 0
	var lmade: int = 0
	while lmade < n_l and tries < 600:
		tries += 1
		var pl: Vector2 = _rand_pos(4.0)
		var trl_v: float = _bil(trl, pl.x, pl.y)
		if rng.randf() < 0.6 and (trl_v < 0.02 or trl_v > 0.35):
			continue
		if not _ok(pl, 0.25, 0.6, 0.35):
			continue
		var which: int = lmade % 2
		var len_l: float = 3.4 if which == 0 else 2.2
		var rad_l: float = 0.24 if which == 0 else 0.17
		var yaw_l: float = rng.randf() * TAU
		var axis: Vector3 = Vector3(cos(yaw_l), 0.0, -sin(yaw_l))
		var h1: float = _bil(hgt, pl.x - axis.x * len_l * 0.5, pl.y - axis.z * len_l * 0.5)
		var h2: float = _bil(hgt, pl.x + axis.x * len_l * 0.5, pl.y + axis.z * len_l * 0.5)
		var pitch: float = atan2(h2 - h1, len_l)
		var bas: Basis = Basis(Vector3.UP, yaw_l) * Basis(Vector3(0, 0, 1), pitch)
		var origin: Vector3 = Vector3(pl.x, (h1 + h2) * 0.5 + rad_l * 0.55, pl.y)
		lx[which].append(Transform3D(bas, origin))
		_col_cyl(Transform3D(bas * Basis(Vector3(0, 0, 1), PI * 0.5), origin), rad_l * 0.9, len_l)
		lmade += 1
	_make_mmi(log_a, lx[0], true, 0.0, "LogsA")
	_make_mmi(log_b, lx[1], true, 0.0, "LogsB")

	var tire_mesh: ArrayMesh = _make_tire()
	var tix: Array = []
	var n_t: int = _count(tire_count)
	tries = 0
	while tix.size() < n_t and tries < 400:
		tries += 1
		var pt: Vector2 = _rand_pos(4.0)
		if not _ok(pt, 0.5, 0.5, 0.35):
			continue
		var tb: Basis = Basis.from_euler(Vector3(rng.randf_range(-0.4, 0.4), rng.randf() * TAU, rng.randf_range(-0.4, 0.4)))
		tix.append(Transform3D(tb, Vector3(pt.x, _bil(hgt, pt.x, pt.y) + 0.05, pt.y)))
	_make_mmi(tire_mesh, tix, false, 60.0, "Tires")

	var plank_mesh: ArrayMesh = _tube_mesh(1.3, 6, 12, 0.13, 0.13, Vector2(0.28, 1.0), 6.0, 0.02, 0.05, seed_value + 311, Color(0.38, 0.33, 0.26), Color(0.55, 0.46, 0.33), 0.5)
	var px: Array = []
	var n_p: int = _count(plank_count)
	tries = 0
	while px.size() < n_p and tries < 400:
		tries += 1
		var pp: Vector2 = _rand_pos(3.0)
		if not _ok(pp, 0.6, 0.6, 0.4):
			continue
		var pb2: Basis = Basis.from_euler(Vector3(rng.randf_range(-0.12, 0.12), rng.randf() * TAU, rng.randf_range(-0.12, 0.12)))
		px.append(Transform3D(pb2, Vector3(pp.x, _bil(hgt, pp.x, pp.y) + 0.04, pp.y)))
	_make_mmi(plank_mesh, px, false, 60.0, "Planks")

	var branch_mesh: ArrayMesh = _tube_mesh(1.8, 7, 6, 0.045, 0.012, Vector2.ONE, 2.0, 0.18, 0.15, seed_value + 321, Color(0.22, 0.15, 0.09), Color(0.5, 0.4, 0.28), 0.5)
	var brx: Array = []
	var n_br: int = _count(branch_count)
	tries = 0
	while brx.size() < n_br and tries < 600:
		tries += 1
		var pbr: Vector2 = _rand_pos(2.5)
		if not _ok(pbr, 0.6, 0.9, 0.5):
			continue
		var bb: Basis = Basis.from_euler(Vector3(rng.randf_range(-0.15, 0.15), rng.randf() * TAU, rng.randf_range(-0.15, 0.15)))
		brx.append(Transform3D(bb, Vector3(pbr.x, _bil(hgt, pbr.x, pbr.y) + 0.03, pbr.y)))
	_make_mmi(branch_mesh, brx, false, 55.0, "Branches")

	# ---------------- foliage
	var gx: Array = []
	var n_g: int = _count(grass_count)
	tries = 0
	while gx.size() < n_g and tries < n_g * 4:
		tries += 1
		var pg: Vector2 = _rand_pos(1.0)
		if not _ok(pg, 0.12, 0.25, 0.5):
			continue
		if _bil(rock, pg.x, pg.y) > 0.35:
			continue
		gx.append(_ground_xf(pg, rng.randf() * TAU, rng.randf_range(0.7, 1.4), 0.02))
	_make_mmi(_make_grass_mesh(), gx, false, 42.0, "Grass")
	var fx: Array = []
	var n_f: int = _count(fern_count)
	tries = 0
	while fx.size() < n_f and tries < n_f * 6:
		tries += 1
		var pf: Vector2 = _rand_pos(1.5)
		if not _ok(pf, 0.1, 0.1, 0.5):
			continue
		fx.append(_ground_xf(pf, rng.randf() * TAU, rng.randf_range(0.8, 1.3), 0.0))
	_make_mmi(_make_fern_mesh(), fx, false, 55.0, "Ferns")
	var sx: Array = []
	var n_sh: int = _count(shrub_count)
	tries = 0
	while sx.size() < n_sh and tries < n_sh * 8:
		tries += 1
		var psh: Vector2 = _rand_pos(2.5)
		if not _ok(psh, 0.1, 0.06, 0.5):
			continue
		sx.append(_ground_xf(psh, rng.randf() * TAU, rng.randf_range(0.8, 1.4), 0.0))
	_make_mmi(_make_shrub_mesh(), sx, false, 60.0, "Shrubs")

func _add_tree_instance(p: Vector2, lists: Array, scale: float) -> void:
	var variant: int = rng.randi() % 2
	var xf: Transform3D = _ground_xf(p, rng.randf() * TAU, scale, 0.1)
	(lists[variant] as Array).append(xf)
	var h: float = 4.0 * scale * (1.0 if variant == 0 else 1.2)
	_col_cyl(Transform3D(Basis.IDENTITY, xf.origin + Vector3(0, h * 0.5, 0)), 0.32 * scale, h)
