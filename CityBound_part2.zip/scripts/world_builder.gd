extends Node3D
# Builds the hilly offroad test map from the baked data in assets/map (see tools/make_map.py):
# terrain chunks + height-map collision, forest, grass, bushes, rocks, huts, gate and fences.

const Meta = preload("res://scripts/map_meta.gd")
const MAP_DIR: String = "res://assets/map/"
const TEX_DIR: String = "res://assets/tex/"
const CHUNKS: int = 4

var heights: PackedFloat32Array = PackedFloat32Array()
var spacing: float = 1.0
var half: float = 200.0
var terrain_mat: ShaderMaterial = null
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.seed = 777
	spacing = Meta.SIZE / float(Meta.N - 1)
	half = Meta.SIZE * 0.5
	heights = _read_floats(MAP_DIR + "height.bin")
	if heights.size() != Meta.N * Meta.N:
		push_error("height.bin missing or wrong size - add *.bin to the export include filter")
		return
	_make_terrain_material()
	_make_terrain()
	_make_terrain_collision()
	_make_vegetation()
	_make_props()

# ---------------------------------------------------------------- helpers
func _read_bytes(path: String) -> PackedByteArray:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("Cannot open " + path)
		return PackedByteArray()
	return f.get_buffer(f.get_length())

func _read_floats(path: String) -> PackedFloat32Array:
	return _read_bytes(path).to_float32_array()

func get_height(x: float, z: float) -> float:
	var n: int = Meta.N
	var fx: float = clampf((x + half) / spacing, 0.0, float(n - 1) - 0.001)
	var fz: float = clampf((z + half) / spacing, 0.0, float(n - 1) - 0.001)
	var i: int = int(floor(fx))
	var j: int = int(floor(fz))
	var tx: float = fx - float(i)
	var tz: float = fz - float(j)
	var h00: float = heights[j * n + i]
	var h10: float = heights[j * n + i + 1]
	var h01: float = heights[(j + 1) * n + i]
	var h11: float = heights[(j + 1) * n + i + 1]
	return lerpf(lerpf(h00, h10, tx), lerpf(h01, h11, tx), tz)

func _tex(name: String) -> Texture2D:
	return load(TEX_DIR + name) as Texture2D

func _flat_mat(c: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

# ---------------------------------------------------------------- terrain
func _make_terrain_material() -> void:
	terrain_mat = ShaderMaterial.new()
	terrain_mat.shader = load("res://shaders/terrain.gdshader") as Shader
	var img: Image = Image.create_from_data(1024, 1024, false, Image.FORMAT_RGBA8, _read_bytes(MAP_DIR + "detail.bin"))
	img.generate_mipmaps()
	terrain_mat.set_shader_parameter("detail_map", ImageTexture.create_from_image(img))
	terrain_mat.set_shader_parameter("grass_tex", _tex("grass.png"))
	terrain_mat.set_shader_parameter("dirt_tex", _tex("dirt.png"))
	terrain_mat.set_shader_parameter("rock_tex", _tex("rock.png"))
	terrain_mat.set_shader_parameter("grass_nrm", _tex("grass_n.png"))
	terrain_mat.set_shader_parameter("dirt_nrm", _tex("dirt_n.png"))
	terrain_mat.set_shader_parameter("rock_nrm", _tex("rock_n.png"))
	terrain_mat.set_shader_parameter("map_size", Meta.SIZE)

func _make_terrain() -> void:
	var n: int = Meta.N
	var cells: int = (n - 1) / CHUNKS
	var side: int = cells + 1
	var idx := PackedInt32Array()
	for j in range(cells):
		for i in range(cells):
			var a: int = j * side + i
			var b: int = a + 1
			var c: int = a + side
			var d: int = c + 1
			idx.append(a)
			idx.append(b)
			idx.append(c)
			idx.append(b)
			idx.append(d)
			idx.append(c)
	var root := Node3D.new()
	root.name = "TerrainChunks"
	add_child(root)
	for cj in range(CHUNKS):
		for ci in range(CHUNKS):
			var verts := PackedVector3Array()
			var norms := PackedVector3Array()
			verts.resize(side * side)
			norms.resize(side * side)
			for j in range(side):
				var gj: int = cj * cells + j
				for i in range(side):
					var gi: int = ci * cells + i
					var h: float = heights[gj * n + gi]
					var hl: float = heights[gj * n + maxi(gi - 1, 0)]
					var hr: float = heights[gj * n + mini(gi + 1, n - 1)]
					var hd: float = heights[maxi(gj - 1, 0) * n + gi]
					var hu: float = heights[mini(gj + 1, n - 1) * n + gi]
					verts[j * side + i] = Vector3(-half + float(gi) * spacing, h, -half + float(gj) * spacing)
					norms[j * side + i] = Vector3(hl - hr, 2.0 * spacing, hd - hu).normalized()
			var arrays: Array = []
			arrays.resize(Mesh.ARRAY_MAX)
			arrays[Mesh.ARRAY_VERTEX] = verts
			arrays[Mesh.ARRAY_NORMAL] = norms
			arrays[Mesh.ARRAY_INDEX] = idx
			var mesh := ArrayMesh.new()
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			var mi := MeshInstance3D.new()
			mi.name = "Chunk_%d_%d" % [ci, cj]
			mi.mesh = mesh
			mi.material_override = terrain_mat
			root.add_child(mi)

func _make_terrain_collision() -> void:
	var body := StaticBody3D.new()
	body.name = "TerrainBody"
	var shape := HeightMapShape3D.new()
	shape.map_width = Meta.N
	shape.map_depth = Meta.N
	shape.map_data = heights
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.scale = Vector3(spacing, 1.0, spacing)
	body.add_child(cs)
	add_child(body)

# ---------------------------------------------------------------- vegetation
func _cone(st: SurfaceTool, base_y: float, height: float, radius: float, seg: int, c_base: Color, c_top: Color, jit: float) -> void:
	var ring: Array = []
	for i in range(seg):
		var a: float = TAU * float(i) / float(seg)
		var rr: float = radius * (1.0 + rng.randf_range(-jit, jit))
		ring.append(Vector3(cos(a) * rr, base_y, sin(a) * rr))
	ring.append(ring[0])
	var apex := Vector3(0.0, base_y + height, 0.0)
	var slope: float = radius / height
	for i in range(seg):
		var a0: float = TAU * float(i) / float(seg)
		var a1: float = TAU * float(i + 1) / float(seg)
		var n0 := Vector3(cos(a0), slope, sin(a0)).normalized()
		var n1 := Vector3(cos(a1), slope, sin(a1)).normalized()
		var na: Vector3 = ((n0 + n1) * 0.5).normalized()
		st.set_normal(n0)
		st.set_color(c_base)
		st.set_uv(Vector2(float(i) / float(seg) * 2.0, 1.0))
		st.add_vertex(ring[i])
		st.set_normal(n1)
		st.set_color(c_base)
		st.set_uv(Vector2(float(i + 1) / float(seg) * 2.0, 1.0))
		st.add_vertex(ring[i + 1])
		st.set_normal(na)
		st.set_color(c_top)
		st.set_uv(Vector2((float(i) + 0.5) / float(seg) * 2.0, 0.0))
		st.add_vertex(apex)

func _make_pine(tiers: int, seg: int) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_cone(st, -0.3, 9.5, 0.34, 6, Color(0.42, 0.3, 0.2), Color(0.3, 0.22, 0.15), 0.0)
	for t in range(tiers):
		var f: float = float(t) / float(maxi(tiers - 1, 1))
		var radius: float = lerpf(2.7, 0.9, f)
		var h: float = lerpf(3.4, 2.4, f)
		var base_y: float = 1.5 + float(t) * (7.0 / float(tiers))
		var shade: float = lerpf(0.62, 0.95, f)
		_cone(st, base_y, h, radius, seg, Color(shade * 0.78, shade * 0.85, shade * 0.75), Color(shade, shade * 1.05, shade * 0.9), 0.16)
	return st.commit()

func _make_pine_far() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_cone(st, 0.0, 10.0, 0.3, 4, Color(0.4, 0.3, 0.2), Color(0.3, 0.22, 0.15), 0.0)
	_cone(st, 1.5, 6.5, 2.7, 7, Color(0.5, 0.6, 0.5), Color(0.7, 0.8, 0.65), 0.1)
	_cone(st, 5.0, 5.5, 1.8, 7, Color(0.55, 0.65, 0.55), Color(0.8, 0.9, 0.72), 0.1)
	return st.commit()

func _make_grass_mesh() -> ArrayMesh:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	var w: float = 0.55
	var h: float = 0.75
	for q in range(3):
		var a: float = PI * float(q) / 3.0
		var dx: float = cos(a) * w
		var dz: float = sin(a) * w
		var b: int = verts.size()
		verts.append(Vector3(-dx, 0.0, -dz))
		verts.append(Vector3(dx, 0.0, dz))
		verts.append(Vector3(dx, h, dz))
		verts.append(Vector3(-dx, h, -dz))
		for k in range(4):
			norms.append(Vector3.UP)
		uvs.append(Vector2(0.0, 1.0))
		uvs.append(Vector2(1.0, 1.0))
		uvs.append(Vector2(1.0, 0.0))
		uvs.append(Vector2(0.0, 0.0))
		# both sides are rendered (cull_disabled) so the winding does not matter
		idx.append(b)
		idx.append(b + 1)
		idx.append(b + 2)
		idx.append(b)
		idx.append(b + 2)
		idx.append(b + 3)
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

# kind: 0 tree, 1 grass, 2 bush, 3 rock
func _spawn_instances(data: PackedFloat32Array, cell: float, mesh: Mesh, mat: Material, kind: int, cast_shadow: bool, vis_begin: float, vis_end: float) -> void:
	var count: int = data.size() / 6
	var groups: Dictionary = {}
	for k in range(count):
		var cx: int = int(floor((data[k * 6] + half) / cell))
		var cz: int = int(floor((data[k * 6 + 2] + half) / cell))
		var key: int = cx * 1000 + cz
		if not groups.has(key):
			groups[key] = []
		groups[key].append(k)
	for key in groups.keys():
		var list: Array = groups[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = true
		mm.mesh = mesh
		mm.instance_count = list.size()
		for n in range(list.size()):
			var o: int = int(list[n]) * 6
			var pos := Vector3(data[o], data[o + 1], data[o + 2])
			var sc: float = data[o + 3]
			var yaw: float = data[o + 4]
			var t: float = data[o + 5]
			var scl := Vector3(sc, sc, sc)
			var col := Color(1, 1, 1)
			if kind == 0:
				col = Color(0.82, 0.92, 0.78).lerp(Color(1.0, 1.05, 0.9), t)
				pos.y -= 0.15
			elif kind == 1:
				col = Color(0.8, 0.88, 0.52).lerp(Color(1.0, 1.0, 0.85), t)
			elif kind == 2:
				scl = Vector3(sc, sc * 0.8, sc)
				col = Color(0.2, 0.34, 0.16).lerp(Color(0.3, 0.45, 0.2), t)
				if t > 0.6:
					col = Color(0.3, 0.36, 0.72).lerp(Color(0.55, 0.45, 0.8), (t - 0.6) * 2.5)
			elif kind == 3:
				scl = Vector3(sc, sc * (0.5 + 0.35 * t), sc * 0.85)
				var g: float = 0.7 + 0.3 * t
				col = Color(g, g * 0.97, g * 0.92)
				pos.y -= sc * 0.2
			var bs := Basis(Vector3.UP, yaw) * Basis.from_scale(scl)
			mm.set_instance_transform(n, Transform3D(bs, pos))
			mm.set_instance_color(n, col)
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = mat
		if not cast_shadow:
			mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mmi.visibility_range_begin = vis_begin
		mmi.visibility_range_end = vis_end
		add_child(mmi)

func _make_vegetation() -> void:
	# --- trees (near + far LOD) and trunk collision
	var trees: PackedFloat32Array = _read_floats(MAP_DIR + "trees.bin")
	var pine_mat := StandardMaterial3D.new()
	pine_mat.albedo_texture = _tex("pine.png")
	pine_mat.vertex_color_use_as_albedo = true
	pine_mat.roughness = 1.0
	pine_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	pine_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_spawn_instances(trees, 40.0, _make_pine(5, 9), pine_mat, 0, true, 0.0, 180.0)
	_spawn_instances(trees, 40.0, _make_pine_far(), pine_mat, 0, true, 180.0, 0.0)
	var trunk_shape := CylinderShape3D.new()
	trunk_shape.radius = 0.35
	trunk_shape.height = 8.0
	var tb := StaticBody3D.new()
	tb.name = "TreeTrunks"
	add_child(tb)
	for k in range(trees.size() / 6):
		var cs := CollisionShape3D.new()
		cs.shape = trunk_shape
		cs.position = Vector3(trees[k * 6], trees[k * 6 + 1] + 4.0, trees[k * 6 + 2])
		tb.add_child(cs)

	# --- grass (dedicated map layer; no distance culling)
	var grass_mat := ShaderMaterial.new()
	grass_mat.shader = load("res://shaders/grass.gdshader") as Shader
	grass_mat.set_shader_parameter("tex", _tex("grass_card.png"))
	_spawn_instances(_read_floats(MAP_DIR + "grass.bin"), 24.0, _make_grass_mesh(), grass_mat, 1, false, 0.0, 0.0)

	# --- blue-berry bushes
	var bush_mesh := SphereMesh.new()
	bush_mesh.radius = 0.8
	bush_mesh.height = 1.3
	bush_mesh.radial_segments = 8
	bush_mesh.rings = 4
	var bush_mat := StandardMaterial3D.new()
	bush_mat.vertex_color_use_as_albedo = true
	bush_mat.roughness = 1.0
	_spawn_instances(_read_floats(MAP_DIR + "bushes.bin"), 40.0, bush_mesh, bush_mat, 2, true, 0.0, 0.0)

	# --- rocks
	var rock_mesh := SphereMesh.new()
	rock_mesh.radius = 0.9
	rock_mesh.height = 1.6
	rock_mesh.radial_segments = 7
	rock_mesh.rings = 4
	var rock_mat := StandardMaterial3D.new()
	rock_mat.albedo_texture = _tex("rock.png")
	rock_mat.normal_enabled = true
	rock_mat.normal_texture = _tex("rock_n.png")
	rock_mat.uv1_triplanar = true
	rock_mat.uv1_world_triplanar = true
	rock_mat.uv1_scale = Vector3(0.35, 0.35, 0.35)
	rock_mat.vertex_color_use_as_albedo = true
	rock_mat.roughness = 0.9
	rock_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_spawn_instances(_read_floats(MAP_DIR + "rocks.bin"), 40.0, rock_mesh, rock_mat, 3, true, 0.0, 220.0)

# ---------------------------------------------------------------- props: huts, haystacks, gate, fences
func _box_node(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi

func _box_collider(body: StaticBody3D, pos: Vector3, size: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	cs.position = pos
	body.add_child(cs)

func _make_props() -> void:
	var wood := _flat_mat(Color(0.55, 0.42, 0.3), 1.0)
	var dark_wood := _flat_mat(Color(0.3, 0.21, 0.14), 1.0)
	var roof := _flat_mat(Color(0.62, 0.44, 0.38), 0.95)
	var door := _flat_mat(Color(0.18, 0.12, 0.09), 1.0)
	var stone := StandardMaterial3D.new()
	stone.albedo_texture = _tex("rock.png")
	stone.uv1_triplanar = true
	stone.uv1_world_triplanar = true
	stone.uv1_scale = Vector3(0.3, 0.3, 0.3)
	stone.roughness = 0.9
	var hay_mat := _flat_mat(Color(0.74, 0.58, 0.34), 1.0)

	for hv in Meta.HUTS:
		var v: Vector4 = hv
		var body := StaticBody3D.new()
		body.position = Vector3(v.x, v.y, v.z)
		body.rotation.y = v.w
		add_child(body)
		_box_node(body, Vector3(0, 1.25, 0), Vector3(5.0, 2.5, 4.0), wood)
		_box_node(body, Vector3(-1.3, 3.35, 0), Vector3(3.1, 0.16, 4.7), roof, Vector3(0, 0, 32))
		_box_node(body, Vector3(1.3, 3.35, 0), Vector3(3.1, 0.16, 4.7), roof, Vector3(0, 0, -32))
		_box_node(body, Vector3(0, 0.9, 2.03), Vector3(0.95, 1.8, 0.08), door)
		_box_node(body, Vector3(1.6, 1.5, 2.03), Vector3(0.7, 0.6, 0.06), door)
		_box_node(body, Vector3(-2.7, 0.1, 0.0), Vector3(0.5, 0.2, 4.0), dark_wood)
		_box_collider(body, Vector3(0, 1.25, 0), Vector3(5.0, 2.5, 4.0))

	for hv in Meta.HAY:
		var v: Vector4 = hv
		var body := StaticBody3D.new()
		body.position = Vector3(v.x, v.y, v.z)
		add_child(body)
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 1.4 * v.w
		sm.height = 2.0 * v.w
		sm.radial_segments = 12
		sm.rings = 6
		mi.mesh = sm
		mi.material_override = hay_mat
		mi.position = Vector3(0, 0.25 * v.w, 0)
		body.add_child(mi)
		var cs := CollisionShape3D.new()
		var ss := SphereShape3D.new()
		ss.radius = 1.2 * v.w
		cs.shape = ss
		cs.position = Vector3(0, 0.3 * v.w, 0)
		body.add_child(cs)

	# log gate across the main road
	var gate := StaticBody3D.new()
	gate.name = "Gate"
	gate.position = Meta.GATE
	gate.rotation.y = Meta.GATE_YAW
	add_child(gate)
	for sx in [-3.6, 3.6]:
		_box_node(gate, Vector3(sx, 1.8, 0), Vector3(1.5, 3.6, 1.5), stone)
		_box_collider(gate, Vector3(sx, 1.8, 0), Vector3(1.5, 3.6, 1.5))
	_box_node(gate, Vector3(0, 3.55, 0), Vector3(8.2, 0.38, 0.45), dark_wood)
	_box_node(gate, Vector3(-1.5, 4.7, 0), Vector3(3.9, 0.3, 0.3), dark_wood, Vector3(0, 0, 33.7))
	_box_node(gate, Vector3(1.5, 4.7, 0), Vector3(3.9, 0.3, 0.3), dark_wood, Vector3(0, 0, -33.7))

	# fences (posts + rails) between consecutive posts of the same run
	var fdata: PackedFloat32Array = _read_floats(MAP_DIR + "fences.bin")
	var fcount: int = fdata.size() / 6
	if fcount > 0:
		var post_mesh := BoxMesh.new()
		post_mesh.size = Vector3(0.14, 1.2, 0.14)
		var rail_mesh := BoxMesh.new()
		rail_mesh.size = Vector3(0.08, 0.09, 1.0)
		var posts := MultiMesh.new()
		posts.transform_format = MultiMesh.TRANSFORM_3D
		posts.mesh = post_mesh
		posts.instance_count = fcount
		var rails: Array = []
		for k in range(fcount):
			var p := Vector3(fdata[k * 6], fdata[k * 6 + 1], fdata[k * 6 + 2])
			posts.set_instance_transform(k, Transform3D(Basis(), p + Vector3(0, 0.55, 0)))
			if k + 1 < fcount:
				var p2 := Vector3(fdata[(k + 1) * 6], fdata[(k + 1) * 6 + 1], fdata[(k + 1) * 6 + 2])
				if p.distance_to(p2) < 3.5:
					rails.append([p, p2])
		var pmi := MultiMeshInstance3D.new()
		pmi.multimesh = posts
		pmi.material_override = dark_wood
		pmi.visibility_range_end = 0.0
		pmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		add_child(pmi)
		var rm := MultiMesh.new()
		rm.transform_format = MultiMesh.TRANSFORM_3D
		rm.mesh = rail_mesh
		rm.instance_count = rails.size() * 2
		for k in range(rails.size()):
			var a: Vector3 = rails[k][0]
			var b: Vector3 = rails[k][1]
			var dir: Vector3 = b - a
			var seg_len: float = dir.length()
			var rb := Basis.looking_at(dir.normalized(), Vector3.UP) * Basis.from_scale(Vector3(1, 1, seg_len))
			var mid: Vector3 = (a + b) * 0.5
			rm.set_instance_transform(k * 2, Transform3D(rb, mid + Vector3(0, 0.45, 0)))
			rm.set_instance_transform(k * 2 + 1, Transform3D(rb, mid + Vector3(0, 0.9, 0)))
		var rmi := MultiMeshInstance3D.new()
		rmi.multimesh = rm
		rmi.material_override = wood
		rmi.visibility_range_end = 0.0
		rmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		add_child(rmi)
