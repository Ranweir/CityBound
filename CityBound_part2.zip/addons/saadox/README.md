# SAADOX integration for CityBound (Godot 4.3)

This folder preserves the supplied SA_DOX source tree intact. The original `.shader` files target the source GTA/OpenGL renderer and are **not** directly loadable as Godot `.gdshader` files. They are retained under `source/SA_DOX/glShader` as the reference implementation for subsequent ports.

## Integrated into the running CityBound project

- SA_DOX 2.0 `timecyc.dat` data is already converted into `res://scripts/sadox_timecyc.gd` and sampled by `TimeCycWeatherManager.gd` for day/night and weather colour/light/fog changes.
- Four weather states (clear, overcast, rain, post-rain), rain particles, wetness accumulation/drying, and shader global `road_wetness` are driven by the existing weather manager.
- The Godot-native sky shader `res://shaders/sky_clouds.gdshader` implements the SAADOX-inspired atmospheric scattering, sun/moon, stars and animated noise clouds. Clouds are now enabled by default.
- Existing Godot-native terrain/water shaders use rain wetness and puddle/ripple inputs. Existing water interaction system provides wheel/foot splashes, wake, expanding rings and water-entry audio.
- Full supplied SAADOX texture set is copied to `res://assets/sadox/full/`; previously referenced game textures remain at their original paths.

## Preserved source assets

All supplied SA_DOX files (INI settings, timecycle/colorcycle/object data, script sources, shader sources, and textures) are preserved in `source/SA_DOX/`. These are source references, not all runtime-integrated Godot features. In particular the GTA renderer's SSR, SSAO, SSGI, cascaded shadow, God-ray, volumetric-cloud, rain-on-vehicle and post-processing pipelines require separate Godot render-pipeline ports; simply copying their GLSL/HLSL-like source would not make them execute. No false claim of direct compatibility is made.
