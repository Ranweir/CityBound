"""Solves the rider's sitting pose on the bike (IK, offline) and prints the RIDE_POSE table used by scripts/player.gd.
Usage: python3 tools/make_ride_pose.py [assets/character.glb]
Targets (bike space, metres): hips on the seat, toes on the foot pegs, palms on the grips, torso leaning forward."""
import json, struct, sys
import numpy as np
from scipy.spatial.transform import Rotation as Rot
from scipy.optimize import least_squares

path = sys.argv[1] if len(sys.argv) > 1 else 'assets/character.glb'
d = open(path, 'rb').read(); jl, = struct.unpack_from('<I', d, 12); js = json.loads(d[20:20 + jl])
N = js['nodes']; names = [n['name'] for n in N]; idx = {n: i for i, n in enumerate(names)}
par = {c: i for i, n in enumerate(N) for c in n.get('children', [])}
M = np.array([[-1, 0, 0], [0, 0, 1], [0, 1, 0]], float)   # model (Z-up, faces -Y) -> bike space (Godot, front -Z), model yawed PI

def fk(delta):
    W = {}
    def go(i):
        if i in W: return W[i]
        n = N[i]; t = np.array(n.get('translation', [0, 0, 0])); q = Rot.from_quat(n.get('rotation', [0, 0, 0, 1]))
        if names[i] in delta: q = q * Rot.from_rotvec(delta[names[i]])
        if i == 2: R, p = q, t                      # node 2 = 'Model' (node 0 is the Z-up -> Y-up wrapper, ignored here)
        else:
            Rp, pp = go(par[i]); R = Rp * q; p = pp + Rp.apply(t)
        W[i] = (R, p); return W[i]
    for i in range(2, len(N)): go(i)
    return W

PELV0 = fk({})[idx['Pelvis']][1]
SEAT_HIP = np.array([0.0, 0.955, 0.36])
T = SEAT_HIP - M @ PELV0
PEG = np.array([0.205, 0.405, 0.285]); GRIP = np.array([0.3196, 0.945, -0.3807])
free = ['Pelvis', 'Spine_1', 'Spine_2', 'Neck', 'Head', 'Bip01_L_Clavicle', 'Bip01_R_Clavicle', 'L_UpperArm', 'R_UpperArm',
        'L_ForeArm', 'R_ForeArm', 'L_Hand', 'R_Hand', 'L_Thigh', 'R_Thigh', 'L_Calf', 'R_Calf', 'L_Foot', 'R_Foot']
hinge = {'L_Calf': [2], 'R_Calf': [2]}
def unpack(x):
    dl = {}; k = 0
    for b in free:
        v = np.zeros(3)
        for a in hinge.get(b, [0, 1, 2]): v[a] = x[k]; k += 1
        dl[b] = v
    return dl
def G(W, b, off=(0, 0, 0)):
    R, p = W[idx[b]]; return M @ (p + R.apply(np.array(off))) + T
def cost(x):
    W = fk(unpack(x)); r = []
    for s, sg in (('L', -1), ('R', 1)):
        r += list((G(W, f'{s}_Toe0') - np.array([sg * PEG[0], PEG[1] + 0.035, PEG[2]])) * 6)
        r += list((G(W, f'{s}_Hand', (0.07, 0, 0)) - np.array([sg * GRIP[0], GRIP[1], GRIP[2]])) * 8)
        knee = G(W, f'{s}_Calf'); hip = G(W, f'{s}_Thigh'); ank = G(W, f'{s}_Foot')
        r.append(max(0, 0.08 + (knee - (hip + ank) / 2)[2]) * 5)       # knee forward
        r.append(max(0, knee[0] * sg - 0.26) * 5); r.append(max(0, 0.17 - sg * knee[0]) * 5)
        el = G(W, f'{s}_ForeArm'); sh = G(W, f'{s}_UpperArm'); wr = G(W, f'{s}_Hand')
        r.append(max(0, 0.04 - (el - (sh + wr) / 2)[0] * sg) * 5); r.append(max(0, (el - (sh + wr) / 2)[1]) * 2)
    nk = G(W, 'Neck'); hd = G(W, 'Head'); r += [nk[0] * 5, hd[0] * 5, (nk[2] + 0.16) * 3, (nk[1] - 1.30) * 3]
    hx = G(W, 'Head', (1, 0, 0)) - hd; r += list((hx - np.array([0, np.cos(np.radians(25)), -np.sin(np.radians(25))])) * 2.0)
    r += [G(W, 'Spine_2')[0] * 5]
    return np.concatenate([r, x * 0.15])

nx = sum(len(hinge.get(b, [0, 1, 2])) for b in free)
sol = least_squares(cost, np.zeros(nx), max_nfev=4000)
dl = unpack(sol.x)
print('const RIDE_POSE := {')
for b in free: print('\t"%s": Vector3(%.5f, %.5f, %.5f),' % ((b,) + tuple(dl[b])))
print('}')
print('const RIDE_MODEL_POS := Vector3(%.5f, %.5f, %.5f)   # model position in bike space (+ feet offset 1.07 m handled in code)' % tuple(T))
