import struct, json, io, re, numpy as np
from PIL import Image
from dff import parse_dff
from ifp import parse_ifp, u
from rw import chunks

SRC_DFF="Skin/Mai Shiranui Tactical Camo.dff"
SRC_TXD="Skin/Mai Shiranui Tactical Camo.txd"
SRC_IFP="anim/ped.ifp"
ANIMS={"idle":"IDLE_stance","walk":"WALK_player","run":"run_player"}

# ---------- TXD -> PIL images ----------
def load_txd(path):
    d=open(path,'rb').read(); tex={}
    for t,p,s,v in chunks(d,12,len(d)):
        if t!=0x15: continue
        st=p+12
        name=d[st+8:st+40].split(b'\0')[0].decode('latin1')
        raster,fourcc,w,h,depth,mips,rtype,comp=struct.unpack_from('<IIHHBBBB',d,st+72)
        dsz,=struct.unpack_from('<I',d,st+88); data=d[st+92:st+92+dsz]
        if comp in (8,9,12):   # DXT1/3/5
            hdr=b'DDS '+struct.pack('<7I',124,0x81007,h,w,len(data),0,1)+b'\0'*44
            hdr+=struct.pack('<2I4s5I',32,4,struct.pack('<I',fourcc),0,0,0,0,0)+struct.pack('<5I',0x1000,0,0,0,0)
            img=Image.open(io.BytesIO(hdr+data)); img.load(); img=img.convert('RGBA')
            has_alpha = comp!=8
        else:
            raise SystemExit(f'unsupported texture format {name} {comp} {hex(raster)}')
        a=np.array(img)[:,:,3]
        if has_alpha and a.min()>=250: has_alpha=False
        if w*h>512*1024:
            img=img.resize((w//2,h//2),Image.LANCZOS)
        if not has_alpha: img=img.convert('RGB')
        tex[name]=(img,has_alpha)
    return tex

# ---------- math ----------
def mat2q(R):
    t=np.trace(R)
    if t>0:
        s=np.sqrt(t+1)*2; q=np.array([(R[2,1]-R[1,2])/s,(R[0,2]-R[2,0])/s,(R[1,0]-R[0,1])/s,s/4])
    else:
        i=int(np.argmax(np.diag(R))); j,k=(i+1)%3,(i+2)%3
        s=np.sqrt(1+R[i,i]-R[j,j]-R[k,k])*2
        q=np.zeros(4); q[i]=s/4; q[3]=(R[k,j]-R[j,k])/s; q[j]=(R[j,i]+R[i,j])/s; q[k]=(R[k,i]+R[i,k])/s
    return q/np.linalg.norm(q)
def q2mat(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])

def clean(n): 
    n=re.sub(r'[^A-Za-z0-9]+','_',n.strip()).strip('_'); return n or 'Bone'

# ---------- load ----------
def load_all():
    fr,ge,at=parse_dff(SRC_DFF); g=ge[0]
    names=[]
    for i,f in enumerate(fr):
        n='Model' if i==0 else clean(f['name'] or f'F{i}')
        if i==1: n='Root'
        while n in names: n+='_'
        names.append(n)
    nid2f={f['nodeid']:i for i,f in enumerate(fr) if f['nodeid'] is not None}
    hier=fr[1]['hier']
    joints=[nid2f[h[0]] for h in hier]       # skin bone index -> frame index
    return fr,g,names,nid2f,joints

def rest_locals(fr):
    out=[]
    for f in fr:
        out.append((mat2q(f['rot'].T),f['pos'].copy()))
    return out
def world_mats(fr,locs):
    W=[None]*len(fr)
    for i,f in enumerate(fr):
        M=np.eye(4); M[:3,:3]=q2mat(locs[i][0]); M[:3,3]=locs[i][1]
        W[i]=M if f['parent']<0 else W[f['parent']]@M
    return W

def load_anims(fr,nid2f):
    d,a=parse_ifp(SRC_IFP); res={}
    for key,aname in ANIMS.items():
        v=a[aname]; chans={}
        for o in v['objs']:
            fi=nid2f.get(o['bid'])
            if fi is None: continue
            T=[];Q=[];P=[]; sz=16 if o['ft']==4 else 10
            for k in range(o['nf']):
                b=o['off']+k*sz
                x,y,z,w,tm=u(d,b,'4hH')
                q=np.array([x,y,z,w],float)/4096; q/=np.linalg.norm(q)
                T.append(tm/60.0); Q.append(q)
                if sz==16: P.append(np.array(u(d,b+10,'3h'),float)/1024)
            chans[fi]=(np.array(T),np.array(Q),np.array(P) if P else None)
        res[key]=chans
    return res

# ---------- GLB ----------
class GLB:
    def __init__(s): s.bin=bytearray(); s.bv=[]; s.acc=[]
    def view(s,data,target=None):
        while len(s.bin)%4: s.bin.append(0)
        o=len(s.bin); s.bin+=data
        e=dict(buffer=0,byteOffset=o,byteLength=len(data))
        if target: e['target']=target
        s.bv.append(e); return len(s.bv)-1
    def accessor(s,arr,ctype,typ,target=None,minmax=False,normalized=False):
        arr=np.ascontiguousarray(arr); bv=s.view(arr.tobytes(),target)
        a=dict(bufferView=bv,componentType=ctype,count=int(arr.shape[0]),type=typ)
        if normalized: a['normalized']=True
        if minmax: a['min']=arr.min(0).tolist(); a['max']=arr.max(0).tolist()
        s.acc.append(a); return len(s.acc)-1

def build(out):
    fr,g,names,nid2f,joints=load_all()
    tex=load_txd(SRC_TXD)
    locs=rest_locals(fr); W=world_mats(fr,locs)
    anims=load_anims(fr,nid2f)
    G=GLB()
    # --- mesh data (Z-up model space, kept as-is) ---
    V=g['verts'].astype('<f4'); N=g['normals'].astype('<f4'); UV=g['uv'].astype('<f4')
    sk=g['skin']
    J=np.array(sk['idx'],dtype='<u2'); WT=sk['w'].astype('<f4'); WT=WT/np.maximum(WT.sum(1,keepdims=True),1e-6)
    pos=G.accessor(V,5126,'VEC3',34962,True); nor=G.accessor(N,5126,'VEC3',34962)
    uv=G.accessor(UV,5126,'VEC2',34962); jn=G.accessor(J,5123,'VEC4',34962); wt=G.accessor(WT,5126,'VEC4',34962)
    # winding fix test
    allind=np.concatenate([i for _,i in g['mesh']['meshes']]).reshape(-1,3)
    fn=np.cross(V[allind[:,1]]-V[allind[:,0]],V[allind[:,2]]-V[allind[:,0]])
    flip = np.mean(np.sum(fn*N[allind[:,0]],1)>0) < 0.5
    # --- materials / textures ---
    images=[];textures=[];materials=[];prims=[]
    for mi,m in enumerate(g['mats']):
        mat=dict(name=m['tex'] or f'mat{mi}',pbrMetallicRoughness=dict(metallicFactor=0.0,roughnessFactor=0.9),doubleSided=True)
        if m['tex'] in tex:
            img,al=tex[m['tex']]; b=io.BytesIO(); img.save(b,'PNG')
            bv=G.view(b.getvalue()); images.append(dict(bufferView=bv,mimeType='image/png',name=m['tex']))
            textures.append(dict(source=len(images)-1,sampler=0))
            mat['pbrMetallicRoughness']['baseColorTexture']=dict(index=len(textures)-1)
            if al:
                low=m['tex'].lower()
                if 'sdw' in low or 'matuge' in low: mat['alphaMode']='BLEND'
                else: mat['alphaMode']='MASK'; mat['alphaCutoff']=0.5
        materials.append(mat)
    for mi,ind in g['mesh']['meshes']:
        ind=ind.astype('<u4').reshape(-1,3)
        if flip: ind=ind[:,[0,2,1]]
        ia=G.accessor(ind.reshape(-1),5125,'SCALAR',34963)
        prims.append(dict(attributes=dict(POSITION=pos,NORMAL=nor,TEXCOORD_0=uv,JOINTS_0=jn,WEIGHTS_0=wt),indices=ia,material=mi))
    # --- skeleton nodes: node 0 = Z-up -> Y-up wrapper, node 1 = mesh, nodes 2.. = frames ---
    nodes=[dict(name='Character',children=[1,2],rotation=[-0.70710678,0,0,0.70710678]),
           dict(name='Body',mesh=0,skin=0)]
    off=2
    for i,f in enumerate(fr):
        q,p=locs[i]
        n=dict(name=names[i],translation=[float(x) for x in p],rotation=[float(x) for x in q])
        ch=[j+off for j,ff in enumerate(fr) if ff['parent']==i]
        if ch: n['children']=ch
        nodes.append(n)
    ibms=np.array([np.linalg.inv(W[fi]).T for fi in joints],dtype='<f4')  # glTF column-major
    ibma=G.accessor(ibms.reshape(-1,16),5126,'MAT4')
    skins=[dict(joints=[fi+off for fi in joints],inverseBindMatrices=ibma,skeleton=2)]
    # --- animations ---
    animations=[]
    for key,chans in anims.items():
        samplers=[];channels=[]
        for fi,(T,Q,P) in chans.items():
            if fi==1: continue   # skip Root bone: no root rotation/travel, game code moves the body
            ta=G.accessor(T.astype('<f4'),5126,'SCALAR',minmax=True)
            qa=G.accessor(Q.astype('<f4'),5126,'VEC4')
            samplers.append(dict(input=ta,output=qa,interpolation='LINEAR'))
            channels.append(dict(sampler=len(samplers)-1,target=dict(node=fi+off,path='rotation')))
            if P is not None:
                pa=G.accessor((locs[fi][1]+(P-P[0])).astype('<f4'),5126,'VEC3')
                samplers.append(dict(input=ta,output=pa,interpolation='LINEAR'))
                channels.append(dict(sampler=len(samplers)-1,target=dict(node=fi+off,path='translation')))
        animations.append(dict(name=key,samplers=samplers,channels=channels))
    gltf=dict(asset=dict(version='2.0',generator='gta-convert'),scene=0,scenes=[dict(nodes=[0])],nodes=nodes,
        meshes=[dict(name='Body',primitives=prims)],skins=skins,materials=materials,textures=textures,images=images,
        samplers=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)],
        accessors=G.acc,bufferViews=G.bv,animations=animations,buffers=[dict(byteLength=len(G.bin))])
    js=json.dumps(gltf).encode(); js+=b' '*((4-len(js)%4)%4)
    binb=bytes(G.bin)+b'\0'*((4-len(G.bin)%4)%4)
    with open(out,'wb') as f:
        f.write(struct.pack('<4sII',b'glTF',2,12+8+len(js)+8+len(binb)))
        f.write(struct.pack('<I4s',len(js),b'JSON')+js); f.write(struct.pack('<I4s',len(binb),b'BIN\0')+binb)
    print('wrote',out,len(js)+len(binb),'bytes; flip winding:',flip)
    return gltf
if __name__=='__main__':
    build('/home/claude/w/character.glb')
