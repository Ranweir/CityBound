"""Adds L_Glute / R_Glute jiggle bones to a converted character .glb and paints their skin weights.
Usage: python3 add_glute_bones.py in.glb out.glb
The new bones are children of Pelvis (no animation of their own); weights are taken from the existing
Spine_1 / Thigh weights in a soft radius around each glute, so legs still deform normally."""
import json, struct, sys, numpy as np

RADIUS = 0.13      # metres, falloff radius around each glute centre
MAX_W = 0.55       # max share of a vertex's weight given to the glute bone

def qmat(q):
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])

def main(src, dst):
    d = open(src, 'rb').read()
    jl = struct.unpack('<I', d[12:16])[0]
    j = json.loads(d[20:20+jl])
    bo = 20 + jl + 8
    bl = struct.unpack('<I', d[20+jl:24+jl])[0]
    b = bytearray(d[bo:bo+bl])
    nodes = j['nodes']
    if any(n.get('name') == 'L_Glute' for n in nodes):
        raise SystemExit('glute bones already present')

    def view(i):
        a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
        return a, bv['byteOffset'] + a.get('byteOffset', 0)
    at = j['meshes'][0]['primitives'][0]['attributes']
    a, o = view(at['POSITION']); V = np.frombuffer(b, '<f4', a['count']*3, o).reshape(-1, 3)
    a, o = view(at['JOINTS_0']); J = np.frombuffer(b, '<u2', a['count']*4, o).reshape(-1, 4)   # writable (bytearray)
    a, o = view(at['WEIGHTS_0']); WT = np.frombuffer(b, '<f4', a['count']*4, o).reshape(-1, 4)

    # world matrices (mesh space = space of node 0's children)
    par = {}
    for i, n in enumerate(nodes):
        for c in n.get('children', []): par[c] = i
    cache = {}
    def wm(i):
        if i in cache: return cache[i]
        n = nodes[i]; M = np.eye(4); M[:3, :3] = qmat(n.get('rotation', [0, 0, 0, 1])); M[:3, 3] = n.get('translation', [0, 0, 0])
        cache[i] = M if i not in par else wm(par[i]) @ M
        return cache[i]
    inv_wrap = np.linalg.inv(wm(0))
    pelvis = next(i for i, n in enumerate(nodes) if n['name'] == 'Pelvis')
    Wp = inv_wrap @ wm(pelvis)

    skin = j['skins'][0]
    nj = len(skin['joints'])
    centres = {}
    for side, sx, name in (('L', 1.0, 'L_Glute'), ('R', -1.0, 'R_Glute')):
        m = (V[:, 1] < -0.10) & (V[:, 2] > -0.35) & (V[:, 2] < 0.0) & (V[:, 0]*sx > 0.03) & (V[:, 0]*sx < 0.25)
        centres[name] = V[m].mean(0)
    print('glute centres', {k: np.round(v, 3).tolist() for k, v in centres.items()})

    new_ibm = []
    for k, (name, c) in enumerate(centres.items()):
        local = (np.linalg.inv(Wp) @ np.append(c, 1.0))[:3]            # in Pelvis space, identity rotation
        nodes.append(dict(name=name, translation=[float(x) for x in local], rotation=[0, 0, 0, 1]))
        idx = len(nodes) - 1
        nodes[pelvis].setdefault('children', []).append(idx)
        skin['joints'].append(idx)
        jidx = nj + k
        Wb = Wp @ np.array([[1, 0, 0, local[0]], [0, 1, 0, local[1]], [0, 0, 1, local[2]], [0, 0, 0, 1]])
        new_ibm.append(np.linalg.inv(Wb).T)                              # glTF column-major
        sx = 1.0 if name[0] == 'L' else -1.0
        dist = np.linalg.norm(V - c, axis=1)
        f = np.clip(1.0 - dist / RADIUS, 0.0, 1.0)
        f = f*f*(3 - 2*f) * MAX_W
        f[(V[:, 0]*sx) < 0.0] = 0.0                                      # stay on own side
        f[V[:, 1] > c[1] + 0.06] = 0.0                                   # rear only
        for vi in np.nonzero(f > 0.01)[0]:
            w = WT[vi].copy(); jn = J[vi].copy()
            w *= (1.0 - f[vi])
            slot = int(np.argmin(w))                                     # a free (0) slot, else the weakest
            jn[slot] = jidx; w[slot] = f[vi]
            w /= w.sum()
            J[vi] = jn; WT[vi] = w

    # new inverse-bind-matrix accessor (old joints + 2 new)
    old, oo = view(skin['inverseBindMatrices'])
    ibm = np.frombuffer(b, '<f4', old['count']*16, oo).reshape(-1, 16).copy()
    del V, J, WT
    b = bytearray(bytes(b))                                          # detach from numpy views so it can grow
    ibm_all = np.vstack([ibm, np.array(new_ibm, dtype='<f4').reshape(-1, 16)]).astype('<f4')
    while len(b) % 4: b.append(0)
    off = len(b); b += ibm_all.tobytes()
    j['bufferViews'].append(dict(buffer=0, byteOffset=off, byteLength=ibm_all.nbytes))
    j['accessors'].append(dict(bufferView=len(j['bufferViews'])-1, componentType=5126, count=int(ibm_all.shape[0]), type='MAT4'))
    skin['inverseBindMatrices'] = len(j['accessors']) - 1
    j['buffers'][0]['byteLength'] = len(b)

    js = json.dumps(j).encode(); js += b' ' * ((4 - len(js) % 4) % 4)
    bb = bytes(b) + b'\0' * ((4 - len(b) % 4) % 4)
    with open(dst, 'wb') as fh:
        fh.write(struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(bb)))
        fh.write(struct.pack('<I4s', len(js), b'JSON') + js)
        fh.write(struct.pack('<I4s', len(bb), b'BIN\0') + bb)
    print('wrote', dst, 'joints now', len(skin['joints']))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
