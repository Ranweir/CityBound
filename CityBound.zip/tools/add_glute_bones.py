"""Prepares a converted GTA character .glb for jiggle physics.
 * adds L_Glute / R_Glute bones (children of Pelvis) if missing
 * paints skin weights for L_breast / R_breast / Belly / L_Glute / R_Glute (the GTA skin leaves the
   breast, belly and pelvis bones with ZERO vertex weights, so they move nothing until painted)
Weights are taken only from the torso / hip bones (Spine_1, Spine_2, Pelvis, clavicles, thighs),
never from head, hair or arms, so normal animation is unaffected.
Usage: python3 add_glute_bones.py in.glb out.glb"""
import json, struct, sys, numpy as np

def qmat(q):
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])

def main(src, dst):
    d = open(src, 'rb').read()
    jl = struct.unpack('<I', d[12:16])[0]
    j = json.loads(d[20:20+jl])
    bo = 20 + jl + 8
    bl = struct.unpack('<I', d[20+jl:24+jl])[0]
    b = bytearray(d[bo:bo+bl])
    nodes = j['nodes']; skin = j['skins'][0]

    def view(i):
        a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
        return a, bv['byteOffset'] + a.get('byteOffset', 0)
    at = j['meshes'][0]['primitives'][0]['attributes']
    a, o = view(at['POSITION']); V = np.frombuffer(b, '<f4', a['count']*3, o).reshape(-1, 3).copy()
    a, o = view(at['JOINTS_0']); J = np.frombuffer(b, '<u2', a['count']*4, o).reshape(-1, 4).astype(np.int32)
    a, o = view(at['WEIGHTS_0']); WT = np.frombuffer(b, '<f4', a['count']*4, o).reshape(-1, 4).copy()
    jo_J, jo_W = view(at['JOINTS_0'])[1], view(at['WEIGHTS_0'])[1]
    n_verts = len(V)

    par = {}
    for i, n in enumerate(nodes):
        for c in n.get('children', []): par[c] = i
    cache = {}
    def wm(i):
        if i in cache: return cache[i]
        n = nodes[i]; M = np.eye(4); M[:3, :3] = qmat(n.get('rotation', [0, 0, 0, 1])); M[:3, 3] = n.get('translation', [0, 0, 0])
        cache[i] = M if i not in par else wm(par[i]) @ M
        return cache[i]
    inv_wrap = np.linalg.inv(wm(0))
    pelvis = next(i for i, n in enumerate(nodes) if n['name'] == 'Pelvis')
    Wp = inv_wrap @ wm(pelvis)

    def jnames():
        return [nodes[k]['name'] for k in skin['joints']]
    def jid(name): return jnames().index(name)

    # ---- 1) glute bones (rest pose = identity relative to Pelvis) ----
    new_ibm = []
    for name, sx in (('L_Glute', 1.0), ('R_Glute', -1.0)):
        if name in jnames(): continue
        m = (V[:, 1] < -0.10) & (V[:, 2] > -0.35) & (V[:, 2] < 0.0) & (V[:, 0]*sx > 0.03) & (V[:, 0]*sx < 0.25)
        c = V[m].mean(0)
        local = (np.linalg.inv(Wp) @ np.append(c, 1.0))[:3]
        nodes.append(dict(name=name, translation=[float(x) for x in local], rotation=[0, 0, 0, 1]))
        nodes[pelvis].setdefault('children', []).append(len(nodes) - 1)
        skin['joints'].append(len(nodes) - 1)
        T = np.eye(4); T[:3, 3] = local
        new_ibm.append(np.linalg.inv(Wp @ T).T)

    names = jnames()
    # ---- 2) weight painting ----
    torso = {n: names.index(n) for n in ('Spine_1', 'Spine_2', 'Pelvis', 'Root', 'Bip01_L_Clavicle', 'Bip01_R_Clavicle', 'L_Thigh', 'R_Thigh') if n in names}
    def wsum(bones):
        ids = [torso[n] for n in bones if n in torso]
        return (WT * np.isin(J, ids)).sum(1)

    def paint(bone, sx, region, src, radius, max_w, front_of_bone=False):
        """region(V) -> bool mask used to find the centre; moves up to max_w of the `src` bones' weight to `bone`."""
        jb = names.index(bone)
        base = region(V) & (wsum(src) > 0.3)
        if sx: base &= (V[:, 0]*sx > 0.03)
        c = V[base].mean(0)
        if front_of_bone:   # centre on the bone's x/z, at the skin surface in front of it
            bp = (inv_wrap @ wm(skin['joints'][jb]))[:3, 3]
            near = (np.abs(V[:, 0] - bp[0]) < 0.07) & (np.abs(V[:, 2] - bp[2]) < 0.07) & (V[:, 1] > 0.05) & (wsum(src) > 0.3)
            if near.sum() > 5:
                ys = np.sort(V[near, 1])
                c = np.array([bp[0], ys[int(len(ys) * 0.8):].mean(), bp[2]])
        dist = np.linalg.norm(V - c, axis=1)
        f = np.clip(1.0 - dist / radius, 0.0, 1.0)
        f = f*f*(3 - 2*f) * max_w
        if sx: f[(V[:, 0]*sx) < 0.0] = 0.0
        ids = [torso[n] for n in src if n in torso]
        cnt = 0
        for vi in np.nonzero((f > 0.01) & (wsum(src) > 0.05))[0]:
            w = WT[vi].copy(); jn = J[vi].copy()
            src_mask = np.isin(jn, ids)
            moved = f[vi] * w[src_mask].sum()
            w[src_mask] *= (1.0 - f[vi])
            if (jn == jb).any():
                w[jn == jb] += moved
            else:
                slot = int(np.argmin(w)); jn[slot] = jb; w[slot] = moved
            w /= w.sum(); J[vi] = jn; WT[vi] = w; cnt += 1
        print(f'{bone}: centre {np.round(c, 3).tolist()}, {cnt} verts')

    chest = lambda V: (V[:, 1] > 0.05) & (V[:, 2] > 0.36) & (V[:, 2] < 0.56)
    belly = lambda V: (V[:, 1] > 0.04) & (V[:, 2] > -0.15) & (V[:, 2] < 0.12) & (np.abs(V[:, 0]) < 0.15)
    rear = lambda V: (V[:, 1] < -0.10) & (V[:, 2] > -0.35) & (V[:, 2] < 0.0)
    upper = ('Spine_2', 'Bip01_L_Clavicle', 'Bip01_R_Clavicle')
    paint('L_breast', 1.0, chest, upper, 0.11, 0.9, True)
    paint('R_breast', -1.0, chest, upper, 0.11, 0.9, True)
    paint('Belly', 0.0, belly, ('Spine_1', 'Spine_2', 'Pelvis'), 0.12, 0.8)
    hips = ('Spine_1', 'Pelvis', 'L_Thigh', 'R_Thigh')
    paint('L_Glute', 1.0, rear, hips, 0.13, 0.55)
    paint('R_Glute', -1.0, rear, hips, 0.13, 0.55)

    # ---- 3) write back ----
    b[jo_J:jo_J + n_verts*8] = J.astype('<u2').tobytes()
    b[jo_W:jo_W + n_verts*16] = WT.astype('<f4').tobytes()
    if new_ibm:
        old, oo = view(skin['inverseBindMatrices'])
        ibm = np.frombuffer(b, '<f4', old['count']*16, oo).reshape(-1, 16).copy()
        ibm_all = np.vstack([ibm, np.array(new_ibm, dtype='<f4').reshape(-1, 16)]).astype('<f4')
        while len(b) % 4: b.append(0)
        off = len(b); b += ibm_all.tobytes()
        j['bufferViews'].append(dict(buffer=0, byteOffset=off, byteLength=ibm_all.nbytes))
        j['accessors'].append(dict(bufferView=len(j['bufferViews'])-1, componentType=5126, count=int(ibm_all.shape[0]), type='MAT4'))
        skin['inverseBindMatrices'] = len(j['accessors']) - 1
        j['buffers'][0]['byteLength'] = len(b)
    js = json.dumps(j).encode(); js += b' ' * ((4 - len(js) % 4) % 4)
    bb = bytes(b) + b'\0' * ((4 - len(b) % 4) % 4)
    with open(dst, 'wb') as fh:
        fh.write(struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(bb)))
        fh.write(struct.pack('<I4s', len(js), b'JSON') + js)
        fh.write(struct.pack('<I4s', len(bb), b'BIN\0') + bb)
    print('wrote', dst, 'joints', len(skin['joints']))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
