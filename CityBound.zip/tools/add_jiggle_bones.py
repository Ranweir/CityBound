#!/usr/bin/env python3
"""Prepare character.glb for secondary motion (bust / glute jiggle).

What the original GTA-converted rig has:
  * L_breast / R_breast bones exist, but NO vertex is skinned to them
    (chest is 100% Spine_1/Spine_2), so moving them does nothing.
  * There are no glute bones at all.

What this tool does (numpy only, no Blender needed):
  * Adds two bones, L_Glute and R_Glute, as children of Pelvis.
  * Paints smooth skin weights (ellipsoid falloff) onto L_breast / R_breast
    and L_Glute / R_Glute. The old weights are scaled down, never removed, so
    the body stays attached to the skeleton and the walk/run animations look
    the same. Hair, arm and head vertices are left untouched.

Usage:
    python3 tools/add_jiggle_bones.py original.glb assets/character.glb
Run it again on a freshly converted GLB if you regenerate it with convert.py.
Coordinates below are in Godot model space: +Y up, +Z = character's front,
+X = character's LEFT side (the L_ bones).
"""
import json
import struct
import sys

import numpy as np

# name, centre (x, y, z), radii (x, y, z), max weight, parent bone, bone side sign
ZONES = [
    ("L_breast", (+0.085, 0.285, 0.10), (0.105, 0.105, 0.115), 0.95, None, +1, "front"),
    ("R_breast", (-0.085, 0.285, 0.10), (0.105, 0.105, 0.115), 0.95, None, -1, "front"),
    ("L_Glute", (+0.075, -0.09, -0.06), (0.125, 0.160, 0.110), 0.90, "Pelvis", +1, "back"),
    ("R_Glute", (-0.075, -0.09, -0.06), (0.125, 0.160, 0.110), 0.90, "Pelvis", -1, "back"),
]
SKIP_DOMINANT = ("Head", "Jaw", "Brow", "Arm", "Hand", "Finger", "Clav")
SKIP_MATERIAL = ("hair", "pony", "matuge", "eye")

CT = {5126: "f4", 5123: "u2", 5125: "u4", 5121: "u1"}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def quat_to_mat(q):
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


class Glb:
    def __init__(self, path):
        d = open(path, "rb").read()
        jl = struct.unpack("<I", d[12:16])[0]
        self.j = json.loads(d[20:20 + jl])
        bl = struct.unpack("<I", d[20 + jl:24 + jl])[0]
        self.bin = bytearray(d[28 + jl:28 + jl + bl])

    def view(self, i):
        a = self.j["accessors"][i]
        bv = self.j["bufferViews"][a["bufferView"]]
        n = NC[a["type"]]
        dt = np.dtype(CT[a["componentType"]])
        off = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
        st = bv.get("byteStride") or n * dt.itemsize
        return np.ndarray((a["count"], n), dt, self.bin, off, (st, dt.itemsize))

    def save(self, path):
        self.bin += b"\0" * (-len(self.bin) % 4)
        self.j["buffers"][0]["byteLength"] = len(self.bin)
        js = json.dumps(self.j, separators=(",", ":")).encode()
        js += b" " * (-len(js) % 4)
        total = 12 + 8 + len(js) + 8 + len(self.bin)
        with open(path, "wb") as f:
            f.write(struct.pack("<III", 0x46546C67, 2, total))
            f.write(struct.pack("<II", len(js), 0x4E4F534A) + js)
            f.write(struct.pack("<II", len(self.bin), 0x004E4942) + bytes(self.bin))


def node_global(j, i, par):
    """Global matrix of node i relative to the 'Character' root (skeleton/mesh space)."""
    chain = []
    while i in par and par[i] is not None:
        chain.append(i)
        i = par[i]
    M = np.eye(4)
    for k in reversed(chain):
        n = j["nodes"][k]
        L = np.eye(4)
        L[:3, :3] = quat_to_mat(n.get("rotation", [0, 0, 0, 1]))
        L[:3, 3] = n.get("translation", [0, 0, 0])
        M = M @ L
    return M


def to_godot(p):  # glTF mesh space (Z up) -> Godot model space (Y up, +Z front)
    return np.stack([p[:, 0], p[:, 2], -p[:, 1]], 1)


def from_godot(c):
    return np.array([c[0], -c[2], c[1]])


def smooth_falloff(d):
    t = np.clip(1.0 - d, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def build(glb):
    j = glb.j
    nodes = j["nodes"]
    par = {0: None}
    for i, n in enumerate(nodes):
        for c in n.get("children", []):
            par[c] = i
    skin = j["skins"][0]
    joints = skin["joints"]
    names = [nodes[i]["name"] for i in joints]
    prim0 = j["meshes"][0]["primitives"]
    pos = glb.view(prim0[0]["attributes"]["POSITION"]).copy()
    J = glb.view(prim0[0]["attributes"]["JOINTS_0"])
    W = glb.view(prim0[0]["attributes"]["WEIGHTS_0"])
    G = to_godot(pos)

    # vertices that must never move (hair, lashes, eyes)
    protected = np.zeros(len(pos), bool)
    for p in prim0:
        mname = j["materials"][p["material"]]["name"].lower()
        if any(s in mname for s in SKIP_MATERIAL):
            protected[glb.view(p["indices"]).ravel().astype(int)] = True
    dom = J[np.arange(len(J)), W.argmax(1)].astype(int)
    for k, d in enumerate(dom):
        if any(s in names[d] for s in SKIP_DOMINANT):
            protected[k] = True

    ibm = glb.view(skin["inverseBindMatrices"]).reshape(-1, 4, 4)
    new_ibm = [m.copy() for m in ibm]
    new_J = np.array(J, dtype=np.uint16)
    new_W = np.array(W, dtype=np.float32)
    report = {}
    for zname, c, r, wmax, parent, sign, side in ZONES:
        c = np.array(c)
        r = np.array(r)
        d = np.sqrt((((G - c) / r) ** 2).sum(1))
        w = smooth_falloff(d) * wmax
        # keep every zone on its own side / face of the body
        w *= np.clip(sign * G[:, 0] / 0.03, 0, 1)
        zgate = G[:, 2] if side == "front" else -G[:, 2]
        w *= np.clip(zgate / 0.03, 0, 1)
        w[protected] = 0.0
        if zname in names:
            ji = names.index(zname)
        else:
            # create the bone
            pidx = joints[names.index(parent)]
            Mp = node_global(j, pidx, par)
            cen = from_godot(c)
            Mn = np.eye(4)
            Mn[:3, :3] = Mp[:3, :3]
            Mn[:3, 3] = cen
            local_t = np.linalg.inv(Mp[:3, :3]) @ (cen - Mp[:3, 3])
            nodes.append({"name": zname, "translation": [float(v) for v in local_t]})
            nid = len(nodes) - 1
            nodes[pidx].setdefault("children", []).append(nid)
            joints.append(nid)
            names.append(zname)
            new_ibm.append(np.linalg.inv(Mn).T.astype(np.float32))  # glTF is column-major
            ji = len(joints) - 1
        sel = np.where(w > 0.005)[0]
        for v in sel:
            ws = new_W[v] * (1.0 - w[v])
            slot = int(np.argmin(ws))
            new_J[v, slot] = ji
            ws[slot] = w[v]
            new_W[v] = ws / ws.sum()
        report[zname] = int(len(sel))
    return new_J, new_W, np.array(new_ibm, np.float32), report


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    glb = Glb(sys.argv[1])
    new_J, new_W, new_ibm, report = build(glb)
    j = glb.j
    prim0 = j["meshes"][0]["primitives"]
    glb.view(prim0[0]["attributes"]["JOINTS_0"])[:] = new_J
    glb.view(prim0[0]["attributes"]["WEIGHTS_0"])[:] = new_W
    # new inverse-bind-matrix accessor (the old one is too short for the new joints)
    glb.bin += b"\0" * (-len(glb.bin) % 4)
    off = len(glb.bin)
    glb.bin += new_ibm.tobytes()
    j["bufferViews"].append({"buffer": 0, "byteOffset": off, "byteLength": new_ibm.nbytes})
    j["accessors"].append({"bufferView": len(j["bufferViews"]) - 1, "componentType": 5126,
                           "count": len(new_ibm), "type": "MAT4"})
    j["skins"][0]["inverseBindMatrices"] = len(j["accessors"]) - 1
    glb.save(sys.argv[2])
    print("skinned vertices per zone:", report)
    print("joints now:", len(j["skins"][0]["joints"]))


if __name__ == "__main__":
    main()
