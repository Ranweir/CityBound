"""GTA SA vehicle (.dff + .txd) -> car.glb  (Y-up, nose points to -Z, Godot friendly)
Nodes: Body (all body parts merged, paint material named "Paint"), WheelFL/FR/RL/RR."""
import sys, json, io, struct, numpy as np
from dff import parse_dff
from convert import load_txd, GLB, q2mat, mat2q

SRC_DFF = sys.argv[1] if len(sys.argv) > 1 else "car.dff"
SRC_TXD = sys.argv[2] if len(sys.argv) > 2 else "car.txd"
OUT = sys.argv[3] if len(sys.argv) > 3 else "car.glb"
PAINT = (60, 255, 0)          # GTA marker colour = body paint
LIGHT_MARKERS = {(255,175,0),(0,255,200),(185,255,0),(255,60,0),(255,0,175),(0,255,255)}

fr, ge, at = parse_dff(SRC_DFF)
CELL = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0     # vertex-cluster size in metres (0 = full detail)
MAXTEX = int(sys.argv[5]) if len(sys.argv) > 5 else 512
tex = load_txd(SRC_TXD)
from PIL import Image
for k in list(tex):
    im, al = tex[k]
    if max(im.size) > MAXTEX:
        sc = MAXTEX / max(im.size); im = im.resize((max(4, int(im.size[0]*sc)), max(4, int(im.size[1]*sc))), Image.LANCZOS)
    tex[k] = (im, al)

# ---- frame world matrices (column vector convention, like convert.py) ----
W = [None]*len(fr)
for i, f in enumerate(fr):
    M = np.eye(4); M[:3,:3] = f['rot'].T; M[:3,3] = f['pos']
    W[i] = M if f['parent'] < 0 else W[f['parent']] @ M

def zup2yup(p):   # (x,y,z) -> (x,z,-y)
    return np.stack([p[...,0], p[...,2], -p[...,1]], -1)

def world_geom(gi, fi, to_world=True):
    g = ge[gi]
    V = g['verts'].astype(np.float64)
    N = g['normals'].astype(np.float64) if g['normals'] is not None else np.zeros_like(V)
    if to_world:
        R = W[fi][:3,:3]; T = W[fi][:3,3]
        V = V @ R.T + T; N = N @ R.T
    return zup2yup(V).astype('<f4'), zup2yup(N).astype('<f4')

def flip_needed(g, V, N):
    ind = np.concatenate([i for _, i in g['mesh']['meshes']]).reshape(-1, 3)
    fnrm = np.cross(V[ind[:,1]]-V[ind[:,0]], V[ind[:,2]]-V[ind[:,0]])
    return np.mean(np.sum(fnrm*N[ind[:,0]], 1) > 0) < 0.5

G = GLB()
images, textures, materials = [], [], []
mat_cache = {}
tex_cache = {}

def get_tex(name):
    if name in tex_cache: return tex_cache[name]
    img, al = tex[name]; b = io.BytesIO(); img.save(b, 'PNG')
    bv = G.view(b.getvalue())
    images.append(dict(bufferView=bv, mimeType='image/png', name=name))
    textures.append(dict(source=len(images)-1, sampler=0))
    tex_cache[name] = len(textures)-1
    return tex_cache[name]

def get_mat(m):
    col = tuple(m['color']); name = m['tex']
    key = (name, col)
    if key in mat_cache: return mat_cache[key]
    pbr = dict(metallicFactor=0.0, roughnessFactor=0.8)
    mat = dict(pbrMetallicRoughness=pbr)
    if name in tex:
        pbr['baseColorTexture'] = dict(index=get_tex(name))
        al = tex[name][1]
        if al: mat['alphaMode'] = 'MASK'; mat['alphaCutoff'] = 0.5; mat['doubleSided'] = True
        mat['name'] = name
        if col[:3] == PAINT:
            mat['name'] = 'Paint'
            pbr['baseColorFactor'] = [0.78, 0.06, 0.06, 1.0]
            pbr['metallicFactor'] = 0.55; pbr['roughnessFactor'] = 0.3
        elif col[:3] in LIGHT_MARKERS:
            mat['name'] = 'Light_' + name
            mat['emissiveFactor'] = [0, 0, 0]
    else:
        a = col[3]/255.0
        pbr['baseColorFactor'] = [col[0]/255, col[1]/255, col[2]/255, a]
        mat['name'] = 'Glass' if a < 1.0 else 'Plain'
        if a < 1.0:
            mat['alphaMode'] = 'BLEND'; mat['doubleSided'] = True
            pbr['roughnessFactor'] = 0.08; pbr['metallicFactor'] = 0.0
    materials.append(mat); mat_cache[key] = len(materials)-1
    return mat_cache[key]

def cluster(V, N, UV, ind, cell):
    """cheap decimation: merge vertices that share a grid cell AND a texture-coordinate cell"""
    key = np.concatenate([np.floor(V/cell), np.floor(UV*48)], 1).astype(np.int64)
    _, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = inv.reshape(-1)
    n = len(first)
    cnt = np.bincount(inv, minlength=n).astype(np.float64)[:, None]
    V2 = np.zeros((n, 3)); N2 = np.zeros((n, 3)); U2 = np.zeros((n, 2))
    for a, b in ((V, V2), (N, N2), (UV, U2)):
        for c in range(a.shape[1]): b[:, c] = np.bincount(inv, weights=a[:, c], minlength=n)
    V2 /= cnt; U2 /= cnt
    ln = np.linalg.norm(N2, axis=1, keepdims=True); N2 = N2/np.maximum(ln, 1e-6)
    return V2.astype('<f4'), N2.astype('<f4'), U2.astype('<f4'), inv

def build_mesh(parts, name):
    """parts: list of (gi, fi, to_world). Returns glTF mesh dict, merging everything into one vertex pool."""
    pos_l, nor_l, uv_l = [], [], []
    prim_inds = {}   # material idx -> list of index arrays
    base = 0
    for gi, fi, tw in parts:
        g = ge[gi]; V, N = world_geom(gi, fi, tw)
        UV = g['uv'].astype('<f4') if g['uv'] is not None else np.zeros((len(V), 2), '<f4')
        fl = flip_needed(g, V, N)
        remap = None
        if CELL > 0:
            V, N, UV, remap = cluster(V, N, UV, None, CELL if tw else CELL*0.5)
        for mi, ind in g['mesh']['meshes']:
            ind = ind.astype('<u4').reshape(-1, 3)
            if remap is not None:
                ind = remap[ind].astype('<u4')
                ok = (ind[:, 0] != ind[:, 1]) & (ind[:, 1] != ind[:, 2]) & (ind[:, 0] != ind[:, 2])
                ind = ind[ok]
            if fl: ind = ind[:, [0, 2, 1]]
            prim_inds.setdefault(get_mat(g['mats'][mi]), []).append(ind + base)
        pos_l.append(V); nor_l.append(N); uv_l.append(UV); base += len(V)
    V = np.concatenate(pos_l); N = np.concatenate(nor_l); UV = np.concatenate(uv_l)
    pa = G.accessor(V, 5126, 'VEC3', 34962, True); na = G.accessor(N, 5126, 'VEC3', 34962)
    ua = G.accessor(UV, 5126, 'VEC2', 34962)
    prims = []
    for mi, lst in prim_inds.items():
        ind = np.concatenate(lst).reshape(-1)
        ia = G.accessor(ind.astype('<u4'), 5125, 'SCALAR', 34963)
        prims.append(dict(attributes=dict(POSITION=pa, NORMAL=na, TEXCOORD_0=ua), indices=ia, material=mi))
    return dict(name=name, primitives=prims), V

atom = {fi: gi for fi, gi in at}
wheel_atoms = [(gi, fi) for fi, gi in at if fr[fi]['name'] == 'wheel']
body_parts = [(gi, fi, True) for fi, gi in at if fr[fi]['name'] != 'wheel']
wheel_gi, wheel_fi = wheel_atoms[0]
body_mesh, BV = build_mesh(body_parts, 'Body')
wheel_mesh, WV = build_mesh([(wheel_gi, wheel_fi, False)], 'Wheel')   # local, centred on hub

dummy = {f['name']: i for i, f in enumerate(fr) if f['name'] and f['name'].startswith('wheel_') and f['name'].endswith('_dummy')}
def wpos(n):
    p = W[dummy[n]][:3, 3]; return zup2yup(p.astype(np.float64)).tolist()
wp = {k: wpos(f'wheel_{k}_dummy') for k in ('lf', 'rf', 'lb', 'rb')}
nodes = [dict(name='Car', children=[1, 2, 3, 4, 5], ), dict(name='Body', mesh=0)]
for nm, k in (('WheelFL','lf'),('WheelFR','rf'),('WheelRL','lb'),('WheelRR','rb')):
    n = dict(name=nm, mesh=1, translation=wp[k])
    if k.startswith('l'): n['rotation'] = [0, 1, 0, 0]       # 180 deg about Y so the rim faces outward
    nodes.append(n)
gltf = dict(asset=dict(version='2.0', generator='gta-car-convert'), scene=0, scenes=[dict(nodes=[0])], nodes=nodes,
            meshes=[body_mesh, wheel_mesh], materials=materials, textures=textures, images=images,
            samplers=[dict(magFilter=9729, minFilter=9987, wrapS=10497, wrapT=10497)],
            accessors=G.acc, bufferViews=G.bv, buffers=[dict(byteLength=len(G.bin))])
js = json.dumps(gltf).encode(); js += b' '*((4-len(js) % 4) % 4)
binb = bytes(G.bin)+b'\0'*((4-len(G.bin) % 4) % 4)
with open(OUT, 'wb') as f:
    f.write(struct.pack('<4sII', b'glTF', 2, 12+8+len(js)+8+len(binb)))
    f.write(struct.pack('<I4s', len(js), b'JSON')+js); f.write(struct.pack('<I4s', len(binb), b'BIN\0')+binb)
info = dict(wheels=wp, body_min=BV.min(0).tolist(), body_max=BV.max(0).tolist(),
            wheel_min=WV.min(0).tolist(), wheel_max=WV.max(0).tolist())
print(json.dumps(info, indent=1)); print('wrote', OUT, len(js)+len(binb)//1, 'bytes')
print('tris body', sum(len(p) for p in []), 'materials', len(materials))
