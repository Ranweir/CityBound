"""Procedural tileable PBR-ish textures (numpy + PIL). Writes assets/tex/*.png"""
import numpy as np, os
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); OUT=os.path.join(ROOT,'assets','tex'); os.makedirs(OUT,exist_ok=True)
n=512
def tn(beta,seed,ax=1.0,ay=1.0,size=n):
    r=np.random.default_rng(seed); F=np.fft.fft2(r.standard_normal((size,size)))
    fy=np.fft.fftfreq(size)[:,None]*ay; fx=np.fft.fftfreq(size)[None,:]*ax; f=np.sqrt(fx**2+fy**2); f[0,0]=1
    a=np.real(np.fft.ifft2(F/(f**beta)*(np.arange(1)+1))); a[...]=a; a=(a-a.min())/(a.max()-a.min()); return a
def mix(a,b,t): return a*(1-t[...,None])+b*t[...,None]
def blobs(seed,density,sigma,size=n):
    r=np.random.default_rng(seed); m=(r.random((size,size))<density).astype(np.float32)
    b=ndi.gaussian_filter(m,sigma,mode='wrap'); return b/b.max()
def normal_from(h,strength):
    dx=(np.roll(h,-1,1)-np.roll(h,1,1))*strength*n/64; dy=(np.roll(h,-1,0)-np.roll(h,1,0))*strength*n/64
    nz=np.ones_like(h); L=np.sqrt(dx**2+dy**2+nz**2); nrm=np.stack([-dx/L,-dy/L,nz/L],-1); return ((nrm*0.5+0.5)*255).astype(np.uint8)
def save(name,a): Image.fromarray(np.clip(a*255,0,255).astype(np.uint8) if a.dtype!=np.uint8 else a).save(os.path.join(OUT,name),optimize=True)

# ---- grass
c1=np.array([.17,.27,.08]); c2=np.array([.33,.46,.14]); c3=np.array([.52,.58,.22])
t=tn(1.5,1); g=mix(c1,c2,t); g=mix(g,c3,np.clip((tn(1.2,2)-0.62)*3,0,1)*0.6)
streak=tn(1.0,3,ax=0.18,ay=1.6); g*=(0.72+0.5*streak[...,None]); fine=tn(0.4,4); g*=(0.9+0.2*fine[...,None])
hgrass=0.6*streak+0.4*fine; save('grass.png',g); save('grass_n.png',normal_from(ndi.gaussian_filter(hgrass,0.9,mode='wrap'),2.0))
# ---- dirt
base=mix(np.array([.36,.26,.17]),np.array([.52,.40,.28]),tn(1.7,5))
peb=blobs(6,0.0035,2.6); peb2=blobs(7,0.008,1.4)
pm=np.clip((peb-0.28)*4,0,1)+0.7*np.clip((peb2-0.32)*4,0,1); pm=np.clip(pm,0,1)
pcol=mix(np.array([.5,.46,.4]),np.array([.62,.58,.5]),tn(0.8,8))
d=mix(base,pcol,pm*0.85); d*=(0.85+0.3*tn(0.5,9)[...,None]); d*=(1-0.25*np.clip(ndi.gaussian_filter(pm,3)-pm,0,1)[...,None]*3)
hdirt=0.6*pm+0.25*tn(1.3,10)+0.15*tn(0.5,11); save('dirt.png',d); save('dirt_n.png',normal_from(ndi.gaussian_filter(hdirt,0.8,mode='wrap'),2.4))
# ---- rock (periodic voronoi blocks with soft cracks, strata, weathering)
r=np.random.default_rng(12); K=22; pts=r.random((K,2))*n; tone=r.uniform(0.8,1.15,K)
yy,xx=np.mgrid[0:n,0:n]; d1=np.full((n,n),1e9); d2=np.full((n,n),1e9); idx=np.zeros((n,n),int)
for ox in (-n,0,n):
    for oy in (-n,0,n):
        for k,(px,py) in enumerate(pts):
            dd=np.hypot(xx-(px+ox),yy-(py+oy)); m=dd<d1; d2=np.where(m,d1,np.where(dd<d2,dd,d2)); idx=np.where(m,k,idx); d1=np.where(m,dd,d1)
edge=np.clip((d2-d1)/14.0,0,1)
warm=np.clip(np.sin((yy+tn(1.5,15)*260)/11.0)*0.5+0.5,0,1)
rock=mix(np.array([.36,.35,.33]),np.array([.56,.53,.49]),tn(1.4,14))
rock=mix(rock,np.array([.52,.44,.34]),warm*0.28*tn(1.2,22))
rock*=tone[idx][...,None]; rock*=(0.62+0.38*edge[...,None]); rock*=(0.8+0.4*tn(0.9,16)[...,None])
rock=mix(rock,np.array([.32,.42,.2]),np.clip((tn(1.6,23)-0.68)*3,0,1)*0.55)   # moss patches
hrock=0.35*edge+0.4*tn(1.3,17)+0.25*tn(0.6,18)+0.1*tone[idx]
save('rock.png',rock); save('rock_n.png',normal_from(ndi.gaussian_filter(hrock,0.8,mode='wrap'),3.2))
# ---- pine needles (small)
m=128; nn=tn(1.0,19,ax=0.5,ay=1.3,size=m); needles=mix(np.array([.07,.17,.06]),np.array([.2,.36,.12]),nn)*(0.8+0.4*tn(0.4,20,size=m)[...,None]); save('pine.png',needles)
# ---- grass tuft card (RGBA)
S=1024; rgb=Image.new('RGB',(S,S),(60,90,30)); al=Image.new('L',(S,S),0); dr=ImageDraw.Draw(rgb); da=ImageDraw.Draw(al); r=np.random.default_rng(21)
for i in range(34):
    x0=r.uniform(170,S-170); hgt=r.uniform(0.45,0.97)*S; curve=r.uniform(-140,140); w0=r.uniform(20,36)
    col=tuple(int(v) for v in (np.array([.32,.5,.15])*r.uniform(0.7,1.25)*255).clip(0,255))
    L=[];R=[]
    for k in range(13):
        t=k/12; y=S-t*hgt; x=x0+curve*t*t; wd=w0*(1-t)**0.8*0.5+0.6
        L.append((x-wd,y)); R.append((x+wd,y))
    poly=L+R[::-1]; dr.polygon(poly,fill=col); da.polygon(poly,fill=255)
rgb=rgb.resize((256,256),Image.LANCZOS); al=al.resize((256,256),Image.LANCZOS)
a=np.asarray(rgb).astype(np.float32)/255; grad=np.linspace(1.0,0.45,256)[:,None,None]    # darker at the base (bottom rows)
a=a*(0.55+0.65*(1-grad+0.0)) if False else a*np.linspace(1.15,0.5,256)[:,None,None]
card=np.dstack([np.clip(a,0,1),np.asarray(al).astype(np.float32)/255]); Image.fromarray((card*255).astype(np.uint8),'RGBA').save(os.path.join(OUT,'grass_card.png'),optimize=True)
print('textures ok',os.listdir(OUT))
