shader_type spatial;
render_mode cull_disabled, specular_disabled;
// Grass tufts: alpha-scissored cards that sway in the wind and shrink away with distance.

uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_disable;
uniform float sway = 0.10;
uniform float fade_start = 36.0;
uniform float fade_end = 58.0;

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float h = 1.0 - UV.y;
	float ph = TIME * 1.7 + wp.x * 0.45 + wp.z * 0.31;
	VERTEX.x += sin(ph) * sway * h * h;
	VERTEX.z += cos(ph * 0.83) * sway * 0.6 * h * h;
	float dist = length(wp - CAMERA_POSITION_WORLD);
	VERTEX.y *= 1.0 - smoothstep(fade_start, fade_end, dist);
	NORMAL = vec3(0.0, 1.0, 0.0);
}

void fragment() {
	vec4 c = texture(tex, UV);
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	ALBEDO = c.rgb * COLOR.rgb;
	ROUGHNESS = 1.0;
}
