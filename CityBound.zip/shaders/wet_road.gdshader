shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

// =====================================================================
//  City Bound - Part 2: Wet-Road spatial shader (Godot 4.3, GL Compatibility)
//
//  Driven by the global shader uniform "road_wetness" (0..1) that
//  TimeCycWeatherManager.gd (Part 1) publishes every frame.
//
//    road_wetness == 0.0  -> 100% DRY: matte/satin, crisp albedo + normal,
//                            no puddles, no mirror reflections.
//    road_wetness  0..0.55 -> asphalt gets damp: darker, smoother.
//    road_wetness 0.3..1.0 -> puddles grow out of the low spots of the mask,
//                            become flat, dark mirrors (sky / ReflectionProbe).
//
//  Reflections are NOT screen-space (SSR does not exist in Compatibility).
//  The shader only lowers ROUGHNESS and raises SPECULAR; the engine then blends
//  the sky radiance / ReflectionProbe automatically = cheap on mobile.
//
//  Mapping modes:
//    0 = mesh UV (uses built-in NORMAL_MAP)
//    1 = world planar XZ (best for roads / sidewalks built from boxes,
//        no UVs needed, no seams between segments)
// =====================================================================

global uniform float road_wetness;

group_uniforms maps;
uniform sampler2D albedo_tex : source_color, filter_linear_mipmap_anisotropic, repeat_enable, hint_default_white;
uniform sampler2D normal_tex : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D roughness_tex : filter_linear_mipmap, repeat_enable, hint_default_white;   // R channel
uniform sampler2D ao_tex : filter_linear_mipmap, repeat_enable, hint_default_white;          // R channel
uniform sampler2D puddle_mask_tex : filter_linear_mipmap, repeat_enable, hint_default_black; // R: 1 = lowest spot (water collects first)
group_uniforms;

group_uniforms mapping;
uniform int mapping_mode : hint_enum("UV", "World planar XZ") = 1;
uniform float tile_m : hint_range(0.25, 64.0, 0.05) = 6.0;          // metres per texture tile (planar mode)
uniform vec2 uv_scale = vec2(1.0);                                  // UV mode only
uniform float puddle_tile_m : hint_range(2.0, 128.0, 0.5) = 20.0;   // metres per puddle-mask tile (always world space)
group_uniforms;

group_uniforms dry_look;
uniform vec4 albedo_tint : source_color = vec4(1.0);
uniform float dry_roughness : hint_range(0.0, 1.5, 0.01) = 0.88;    // multiplier on roughness map
uniform float dry_specular : hint_range(0.0, 1.0, 0.01) = 0.35;     // 0.5 = engine default, lower = matte
uniform float normal_strength : hint_range(0.0, 2.0, 0.01) = 1.0;
uniform float ao_strength : hint_range(0.0, 1.0, 0.01) = 1.0;
group_uniforms;

group_uniforms wet_look;
uniform float wetness_scale : hint_range(0.0, 2.0, 0.01) = 1.0;
uniform float damp_end : hint_range(0.05, 1.0, 0.01) = 0.55;        // wetness at which the surface is fully damp
uniform float wet_darken : hint_range(0.2, 1.0, 0.01) = 0.55;       // albedo multiplier when damp (asphalt ~0.5, concrete ~0.7)
uniform float wet_roughness_mul : hint_range(0.05, 1.0, 0.01) = 0.45;
uniform float wet_specular : hint_range(0.0, 1.0, 0.01) = 0.55;
group_uniforms;

group_uniforms puddles;
uniform float puddle_start : hint_range(0.0, 0.95, 0.01) = 0.30;    // wetness where puddles begin to appear
uniform float puddle_coverage : hint_range(0.0, 1.0, 0.01) = 0.42;  // 0 = never any puddles
uniform float puddle_edge : hint_range(0.005, 0.3, 0.005) = 0.06;   // softness of the puddle border
uniform float puddle_rim : hint_range(0.0, 0.5, 0.01) = 0.12;       // extra-dark soaked ring around puddles
uniform float puddle_roughness : hint_range(0.0, 0.3, 0.005) = 0.03;
uniform float puddle_darken : hint_range(0.2, 1.0, 0.01) = 0.65;
uniform float puddle_flatten : hint_range(0.0, 1.0, 0.01) = 0.9;    // water hides the bump detail
uniform float puddle_reflect : hint_range(0.0, 1.5, 0.01) = 1.0;    // reflection strength
uniform bool procedural_puddles = false;                            // use built-in noise if no mask texture is supplied
group_uniforms;

varying vec3 w_pos;

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = hash21(i);
	float b = hash21(i + vec2(1.0, 0.0));
	float c = hash21(i + vec2(0.0, 1.0));
	float d = hash21(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void vertex() {
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	bool planar = mapping_mode == 1;
	vec2 uv = planar ? (w_pos.xz / tile_m) : (UV * uv_scale);

	// geometric normal in world space (before any normal map)
	vec3 gn = normalize((INV_VIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
	float top = smoothstep(0.6, 0.95, gn.y);   // 1 on flat, upward faces

	vec3 albedo = texture(albedo_tex, uv).rgb * albedo_tint.rgb;
	float rough_map = texture(roughness_tex, uv).r;
	float ao_map = texture(ao_tex, uv).r;
	vec4 nt = texture(normal_tex, uv);

	// ---------------------------------------------------------- wetness
	float w = clamp(road_wetness * wetness_scale, 0.0, 1.0);
	float damp = smoothstep(0.0, damp_end, w);
	float p_level = smoothstep(puddle_start, 1.0, w);
	float puddle = 0.0;
	float soak = 0.0;

	// everything inside this branch is skipped while the road is dry
	if (p_level > 0.001 && puddle_coverage > 0.001) {
		vec2 puv = w_pos.xz / puddle_tile_m;
		float m;
		if (procedural_puddles) {
			m = vnoise(puv * 4.0) * 0.65 + vnoise(puv * 9.0 + 17.0) * 0.35;
		} else {
			m = texture(puddle_mask_tex, puv).r;
		}
		float t = 1.0 - p_level * puddle_coverage;       // water level: 1.0 (none) -> 1.0 - coverage
		puddle = smoothstep(t, t + puddle_edge, m) * top;
		soak = smoothstep(t - puddle_rim, t, m) * p_level * top;
	}

	// ---------------------------------------------------------- normal
	float ns = normal_strength * (1.0 - puddle * puddle_flatten);
	if (planar) {
		// whiteout/UDN blend of the planar normal map onto the geometric normal.
		// Tangent space on a top face: +X = world X, +Y(green) = world -Z (matches Godot UV orientation).
		ns *= top;
		vec2 nxy = nt.xy * 2.0 - 1.0;
		vec3 wn = normalize(vec3(gn.x + nxy.x * ns, gn.y, gn.z - nxy.y * ns));
		NORMAL = normalize((VIEW_MATRIX * vec4(wn, 0.0)).xyz);
	} else {
		NORMAL_MAP = nt.rgb;
		NORMAL_MAP_DEPTH = ns;
	}

	// ---------------------------------------------------------- albedo
	float dk = mix(1.0, wet_darken, damp);
	dk *= mix(1.0, 0.85, soak);
	dk *= mix(1.0, puddle_darken, puddle);
	vec3 wet_alb = albedo * dk;
	float lum = dot(wet_alb, vec3(0.299, 0.587, 0.114));
	wet_alb = mix(vec3(lum), wet_alb, 1.0 + 0.25 * damp);   // water deepens colours a little
	ALBEDO = clamp(wet_alb, 0.0, 1.0);

	// ---------------------------------------------------------- roughness / specular
	float r_dry = clamp(rough_map * dry_roughness, 0.04, 1.0);
	float r = mix(r_dry, r_dry * wet_roughness_mul, damp);
	r = mix(r, puddle_roughness, puddle);
	ROUGHNESS = clamp(r, 0.02, 1.0);
	METALLIC = 0.0;

	float spec = mix(dry_specular, wet_specular, damp);
	spec = mix(spec, clamp(0.6 * puddle_reflect, 0.0, 1.0), puddle);
	SPECULAR = spec;

	// ---------------------------------------------------------- ambient occlusion
	float ao = mix(1.0, ao_map, ao_strength);
	ao = mix(ao, 1.0, puddle * 0.7);   // water fills the crevices
	AO = ao;
	AO_LIGHT_AFFECT = 0.5;
}
