shader_type sky;
// Procedural sky + fluffy clouds for City Bound (Godot 4.3, Compatibility renderer).
// Clouds are a noise layer projected on a plane overhead, with fake self-shadowing
// (density is sampled a little toward the sun) so they look puffy and 3D.
// Because they live in the sky, they also show up in the car's reflections.

uniform vec3 sky_top = vec3(0.06, 0.13, 0.2);          // raw (display-space) timecyc SkyTop, like SA_DOX
uniform vec3 sky_horizon = vec3(0.66, 0.8, 0.91);      // raw (display-space) timecyc SkyBot
uniform vec3 ground_horizon : source_color = vec3(0.7, 0.8, 0.85);
uniform vec3 ground_bottom : source_color = vec3(0.35, 0.4, 0.3);
uniform float sky_curve = 0.3;
uniform float reflect_env = 1.0;     // strength of the fake tree-line / ground seen in reflections
uniform float game_time = 12.0;      // hour 0..24 (SA_DOX atmospheric scattering uses GTA time steps)
uniform float night_value : hint_range(0.0, 1.0) = 0.0;
uniform vec3 sun_color = vec3(1.0, 0.95, 0.85);
uniform float sky_gain = 1.15;

uniform float sun_vis = 1.0;          // sun disc visibility (weather)
uniform float sun_radius = 0.04;      // radians

uniform bool clouds_on = false;
uniform float cloud_cover : hint_range(0.0, 1.0) = 0.4;
uniform float cloud_scale = 0.32;
uniform vec2 cloud_wind = vec2(0.0035, 0.0012);
uniform vec3 cloud_lit : source_color = vec3(1.0);       // sunlit side
uniform vec3 cloud_shade : source_color = vec3(0.6, 0.68, 0.8);   // shadowed side / belly

uniform sampler2D noise_tex : filter_linear_mipmap, repeat_enable;

// ======================================================================================================
//  SA_DOX 2.0 atmospheric scattering (atmosphericScattering.shader), ported from GTA's z-up space to Godot y-up.
//  skyColorUP = timecyc SkyTop, skyColorHor = timecyc SkyBot, SunDirection = direction towards the sun / moon.
// ======================================================================================================
float tstep(float t1, float t2) {
	return clamp((game_time - t1) / (t2 - t1), 0.0, 1.0);
}
float zenith_density(float x) {
	return 0.7 / pow(max(x - 0.1, 0.0035), 0.75);
}
vec3 jodie_reinhard(vec3 c) {
	vec3 tc = c / (c + 1.0);
	return mix(c / (dot(c, vec3(0.2126, 0.7152, 0.0722)) + 1.0), tc, tc);
}
float sdx_hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
vec3 sdx_atmosphere(vec3 dir, vec3 L) {
	float x1 = tstep(0.0, 4.0);
	float x2 = tstep(4.0, 5.0);
	float x3 = tstep(5.0, 6.0);
	float x4 = tstep(6.0, 7.0);
	float xE = tstep(8.0, 11.0);
	float x5 = tstep(16.0, 17.0);
	float x6 = tstep(18.0, 19.0);
	float x7 = tstep(19.0, 20.0);
	float xG = tstep(20.0, 21.0);
	float xZ = tstep(21.0, 22.0);
	float x8 = tstep(22.0, 23.0);
	float x9 = tstep(23.0, 24.0);

	float up = max(dir.y, 0.0);
	float sky = pow(clamp(0.95 - up, 0.0, 1.0), 5.0);
	float sky2 = pow(max(1.05 - up, 0.0), 40.0);
	vec3 top = sky_top;
	vec3 bot = sky_horizon;
	vec3 absorption = exp2(top * -sky2);

	float vec3v = max(L.y + 0.1, 0.0);
	float vec6 = 0.4;
	vec6 = mix(vec6, 0.5, x5);
	vec6 = mix(vec6, 0.8, x6);
	vec6 = mix(vec6, 0.9, x7);
	vec6 = mix(vec6, 0.9, xG);
	vec6 = mix(vec6, 1.0, xZ);
	vec6 = mix(vec6, 1.0, x8);
	vec6 = mix(vec6, 1.0, x9);

	vec3 sun_abs = exp2(top * -zenith_density(L.y + vec6));
	vec3 s_abs = sun_abs * 0.5 + 0.5 * length(sun_abs);

	float cosine = clamp(dot(dir, L), 0.0, 1.0);

	vec3 att = vec3(0.0);
	att = mix(att, vec3(1.0, 0.9, 0.5) * 3.0, x2);
	att = mix(att, vec3(1.0, 0.949, 0.51) * 4.7, x3);
	att = mix(att, vec3(1.0, 0.949, 0.51) * 2.2, x4);
	att = mix(att, vec3(0.6), xE);
	att = mix(att, vec3(0.6), x5);
	att = mix(att, vec3(1.0, 0.949, 0.51) * 3.0, x6);
	att = mix(att, vec3(1.0, 0.9, 0.5) * 0.8, x7);
	att = mix(att, vec3(1.0, 0.9, 0.5) * 0.6, xG);
	att = mix(att, vec3(1.0, 0.9, 0.5) * 0.4, xZ);
	att = mix(att, vec3(0.0), x8);
	att = mix(att, vec3(0.0), x9);

	float suns = pow(max(cosine, 0.0001), 4000.0);
	vec3 sun = sun_color * suns * absorption;
	vec3 ray = sun_color * (cosine * cosine) * att;

	vec3 col = mix(top, bot, sky) * mix(sky, 1.0, 0.4);
	col = mix(col * absorption, col, vec3v);
	col *= 12.0;
	col *= s_abs;

	vec3 fnight = mix(vec3(0.50, 0.70, 1.0) * 0.2, vec3(0.50, 0.70, 1.0) * 0.30, pow(max(sky, 0.0001), 0.85));
	col = pow(jodie_reinhard(mix(col, fnight, night_value) + ray * 0.75 * s_abs), vec3(1.1)) * 1.1;

	// moon (at night the manager's light is the moon) + stars
	if (night_value > 0.0) {
		float mv = clamp(pow(max(cosine, 0.0001), 2048.0) * 1.65, 0.0, 1.0) * night_value;
		col = mix(col, vec3(1.0), mv);
		if (mv < 1.0) {
			vec2 sp = floor(dir.xz / (dir.y + 0.35) * 60.0);
			float st = step(0.985, sdx_hash(sp)) * sdx_hash(sp + 7.3) * 2.5;
			col += st * smoothstep(0.1, 0.4, dir.y) * clamp(night_value * 5.0, 0.0, 1.0);
		}
	}
	return clamp(col + sun, 0.0, 1.0);
}

float cloud_density(vec2 uv) {
	float base = texture(noise_tex, uv).r;
	float mid = texture(noise_tex, uv * 3.7 + vec2(0.31, 0.17)).r;
	float fine = texture(noise_tex, uv * 9.1 + vec2(0.70, 0.40)).r;
	return base * 0.62 + mid * 0.28 + fine * 0.10;
}

void sky() {
	vec3 dir = normalize(EYEDIR);
	float y = dir.y;

	// ---- SA_DOX atmospheric scattering above the horizon, ground gradient below it
	vec3 Ls = LIGHT0_ENABLED ? normalize(LIGHT0_DIRECTION) : normalize(vec3(0.3, 0.8, 0.2));
	vec3 col;
	if (y >= 0.0) {
		col = pow(sdx_atmosphere(dir, Ls), vec3(2.2)) * sky_gain;      // SA output is display-space, Godot sky is linear
	} else {
		vec3 hz = pow(sdx_atmosphere(vec3(dir.x, 0.0, dir.z), Ls), vec3(2.2)) * sky_gain;
		col = mix(hz * 0.8, ground_bottom, pow(clamp(-y, 0.0, 1.0), sky_curve));
	}

	// what glossy surfaces (car paint / glass) see around them: a dark tree line + ground band.
	// Only in the reflection cubemap, so the visible sky is not affected.
	if (AT_CUBEMAP_PASS) {
		vec3 hor_lin = pow(sky_horizon, vec3(2.2));
		float az = atan(dir.x, dir.z);
		// far hills (hazy, lighter) + near tree line (dark, ragged with gaps) + ground
		float hl = 0.10 + 0.05 * sin(az * 3.0 + 0.7) + 0.03 * sin(az * 8.0 + 2.1);
		float tl = 0.045 + 0.035 * sin(az * 7.0 + 1.3) + 0.02 * sin(az * 19.0) + 0.012 * sin(az * 43.0 + 2.0);
		float hills = 1.0 - smoothstep(hl, hl + 0.02, y);
		float band = 1.0 - smoothstep(tl, tl + 0.03, y);
		vec3 hill_col = mix(hor_lin, ground_bottom, 0.55) * 0.72;
		vec3 env_col = mix(ground_bottom, hor_lin, 0.10) * 0.38;
		col = mix(col, hill_col, hills * reflect_env * 0.85);
		col = mix(col, env_col, band * reflect_env);
		// bright horizon glow strip + contrast so body panels show a clear sky/ground split (Forza-style)
		col += hor_lin * 0.35 * exp(-abs(y - 0.16) * 14.0) * step(0.0, y);
		col = mix(vec3(dot(col, vec3(0.333))), col, 1.12);
		col *= 1.0 + 0.25 * smoothstep(0.0, 0.7, y);
	}

	vec3 L = LIGHT0_ENABLED ? normalize(LIGHT0_DIRECTION) : normalize(vec3(0.3, 0.8, 0.2));
	float sun_dot = dot(dir, L);

	// ---- sun / moon disc + glow (drawn first, clouds cover it)
	if (LIGHT0_ENABLED) {
		float sd = acos(clamp(sun_dot, -1.0, 1.0));
		float disc = 1.0 - smoothstep(sun_radius * 0.85, sun_radius, sd);
		float glow = 0.0;
		vec3 sun_col = LIGHT0_COLOR * clamp(LIGHT0_ENERGY, 0.0, 1.6);
		col += sun_col * (disc * 5.0 * sun_vis + glow) * smoothstep(-0.03, 0.03, y);
	}

	// ---- clouds
	if (clouds_on && y > 0.0) {
		float hfade = smoothstep(0.0, 0.22, y);
		vec2 uv = dir.xz / (y + 0.12) * cloud_scale + cloud_wind * TIME;
		float thr = mix(0.72, 0.28, cloud_cover);
		float d = cloud_density(uv);
		float dens = smoothstep(thr, thr + 0.10, d);
		if (dens > 0.001 && hfade > 0.001) {
			// fake volume: how much denser is the cloud toward the sun? (then this point is in shade)
			vec2 sdir = normalize(L.xz + vec2(0.0001, 0.0));
			vec2 off = sdir * (0.030 + 0.050 * (1.0 - clamp(L.y, 0.0, 1.0))) * cloud_scale * 3.0;
			float dl = cloud_density(uv + off);
			float lit = clamp(0.62 - (dl - d) * 9.0, 0.0, 1.0);
			float core = smoothstep(thr, thr + 0.30, d);
			vec3 cc = mix(cloud_shade, cloud_lit, lit);
			cc *= mix(1.0, 0.74, core);                       // thick centres are darker
			float sun_amt = max(sun_dot, 0.0);
			cc += cloud_lit * pow(sun_amt, 10.0) * (1.0 - core) * 0.9;   // silver lining near the sun
			col = mix(col, cc, dens * hfade * 0.97);
		}
	}
	COLOR = col;
}
