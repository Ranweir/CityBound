shader_type sky;
// Procedural sky + fluffy clouds for City Bound (Godot 4.3, Compatibility renderer).
// Clouds are a noise layer projected on a plane overhead, with fake self-shadowing
// (density is sampled a little toward the sun) so they look puffy and 3D.
// Because they live in the sky, they also show up in the car's reflections.

uniform vec3 sky_top : source_color = vec3(0.2, 0.45, 0.9);
uniform vec3 sky_horizon : source_color = vec3(0.8, 0.9, 1.0);
uniform vec3 ground_horizon : source_color = vec3(0.7, 0.8, 0.85);
uniform vec3 ground_bottom : source_color = vec3(0.35, 0.4, 0.3);
uniform float sky_curve = 0.3;
uniform float reflect_env = 1.0;     // strength of the fake tree-line / ground seen in reflections

uniform float sun_vis = 1.0;          // sun disc visibility (weather)
uniform float sun_radius = 0.04;      // radians

uniform bool clouds_on = false;
uniform float cloud_cover : hint_range(0.0, 1.0) = 0.4;
uniform float cloud_scale = 0.32;
uniform vec2 cloud_wind = vec2(0.0035, 0.0012);
uniform vec3 cloud_lit : source_color = vec3(1.0);       // sunlit side
uniform vec3 cloud_shade : source_color = vec3(0.6, 0.68, 0.8);   // shadowed side / belly

uniform sampler2D noise_tex : filter_linear_mipmap, repeat_enable;

float cloud_density(vec2 uv) {
	float base = texture(noise_tex, uv).r;
	float mid = texture(noise_tex, uv * 3.7 + vec2(0.31, 0.17)).r;
	float fine = texture(noise_tex, uv * 9.1 + vec2(0.70, 0.40)).r;
	return base * 0.62 + mid * 0.28 + fine * 0.10;
}

void sky() {
	vec3 dir = normalize(EYEDIR);
	float y = dir.y;

	// ---- gradient
	vec3 col;
	if (y >= 0.0) {
		col = mix(sky_horizon, sky_top, pow(clamp(y, 0.0, 1.0), sky_curve));
	} else {
		col = mix(ground_horizon, ground_bottom, pow(clamp(-y, 0.0, 1.0), sky_curve));
	}

	// what glossy surfaces (car paint / glass) see around them: a dark tree line + ground band.
	// Only in the reflection cubemap, so the visible sky is not affected.
	if (AT_CUBEMAP_PASS) {
		float az = atan(dir.x, dir.z);
		// far hills (hazy, lighter) + near tree line (dark, ragged with gaps) + ground
		float hl = 0.10 + 0.05 * sin(az * 3.0 + 0.7) + 0.03 * sin(az * 8.0 + 2.1);
		float tl = 0.045 + 0.035 * sin(az * 7.0 + 1.3) + 0.02 * sin(az * 19.0) + 0.012 * sin(az * 43.0 + 2.0);
		float hills = 1.0 - smoothstep(hl, hl + 0.02, y);
		float band = 1.0 - smoothstep(tl, tl + 0.03, y);
		vec3 hill_col = mix(sky_horizon, ground_bottom, 0.55) * 0.72;
		vec3 env_col = mix(ground_bottom, sky_horizon, 0.10) * 0.38;
		col = mix(col, hill_col, hills * reflect_env * 0.85);
		col = mix(col, env_col, band * reflect_env);
		// bright horizon glow strip + contrast so body panels show a clear sky/ground split (Forza-style)
		col += sky_horizon * 0.35 * exp(-abs(y - 0.16) * 14.0) * step(0.0, y);
		col = mix(vec3(dot(col, vec3(0.333))), col, 1.12);
		col *= 1.0 + 0.25 * smoothstep(0.0, 0.7, y);
	}

	vec3 L = LIGHT0_ENABLED ? normalize(LIGHT0_DIRECTION) : normalize(vec3(0.3, 0.8, 0.2));
	float sun_dot = dot(dir, L);

	// ---- sun / moon disc + glow (drawn first, clouds cover it)
	if (LIGHT0_ENABLED) {
		float sd = acos(clamp(sun_dot, -1.0, 1.0));
		float disc = 1.0 - smoothstep(sun_radius * 0.85, sun_radius, sd);
		float glow = exp(-sd * 7.0) * 0.35;
		vec3 sun_col = LIGHT0_COLOR * clamp(LIGHT0_ENERGY, 0.0, 1.6);
		col += sun_col * (disc * 5.0 * sun_vis + glow) * smoothstep(-0.03, 0.03, y);
	}

	// ---- clouds
	if (clouds_on && y > 0.0) {
		float hfade = smoothstep(0.0, 0.22, y);
		vec2 uv = dir.xz / (y + 0.12) * cloud_scale + cloud_wind * TIME;
		float thr = mix(0.72, 0.28, cloud_cover);
		float d = cloud_density(uv);
		float dens = smoothstep(thr, thr + 0.10, d);
		if (dens > 0.001 && hfade > 0.001) {
			// fake volume: how much denser is the cloud toward the sun? (then this point is in shade)
			vec2 sdir = normalize(L.xz + vec2(0.0001, 0.0));
			vec2 off = sdir * (0.030 + 0.050 * (1.0 - clamp(L.y, 0.0, 1.0))) * cloud_scale * 3.0;
			float dl = cloud_density(uv + off);
			float lit = clamp(0.62 - (dl - d) * 9.0, 0.0, 1.0);
			float core = smoothstep(thr, thr + 0.30, d);
			vec3 cc = mix(cloud_shade, cloud_lit, lit);
			cc *= mix(1.0, 0.74, core);                       // thick centres are darker
			float sun_amt = max(sun_dot, 0.0);
			cc += cloud_lit * pow(sun_amt, 10.0) * (1.0 - core) * 0.9;   // silver lining near the sun
			col = mix(col, cc, dens * hfade * 0.97);
		}
	}
	COLOR = col;
}
