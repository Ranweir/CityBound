# City Bound (Godot 4.3, Android)

Hilly offroad test map (terrain, forest, grass, rocks, huts, dirt roads) with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.

## Map (graphics test)
- `tools/make_map.py` + `tools/make_textures.py` generate `assets/map/*.bin` and `assets/tex/*.png` (run them again after changing the map).
- `scripts/world_builder.gd` builds terrain, collision, trees (near/far LOD), grass, bushes, rocks, huts, gate and fences.
- `shaders/terrain.gdshader` blends grass/dirt/rock with normal maps and rain wetness; `shaders/grass.gdshader` sways in the wind.
