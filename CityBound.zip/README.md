# City Bound (Godot 4.3, Android)

Hilly offroad test map (terrain, forest, grass, rocks, huts, dirt roads) with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- ENTER / EXIT button (appears near a vehicle) to get in or out of the Ford F-150 Raptor or the NRG-500 motorbike
- Driving (car and bike) uses arrow buttons instead of the joystick: left/right arrows (bottom left) = steer, up arrow (green) = gas, down arrow (red) = brake/reverse, JUMP = handbrake / brake. PC keys still work.
- PC: WASD / arrows, Space = handbrake
- Right side drag: camera
- Camera distance: hold the "+" (further) / "-" (closer) buttons under the weather buttons; the setting is kept for on foot, car and bike
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.

## Map (graphics test)
- `tools/make_map.py` + `tools/make_textures.py` generate `assets/map/*.bin` and `assets/tex/*.png` (run them again after changing the map).
- `scripts/world_builder.gd` builds terrain, collision, trees (near/far LOD), grass, bushes, rocks, huts, gate and fences.
- `shaders/terrain.gdshader` blends grass/dirt/rock with normal maps and rain wetness; `shaders/grass.gdshader` sways in the wind.

## Motorbike (NRG-500, BMW S1000RR livery)
- `assets/bike/nrg500.glb` is the full quality GTA SA model (~30k triangles, original textures, nothing reduced). `tools/convert_bike.py bike.dff bike.txd .` rebuilds it plus `scripts/bike_meta.gd` (wheel positions, steering axis).
- `scripts/bike.gd`: two-wheel spring/damper suspension on the terrain, the bike leans into corners (lean angle from lateral acceleration), the fork steers around its real rake axis, both wheels spin. Tuning values are `@export` vars at the top (`max_speed`, `accel`, `max_lat_acc`, `max_lean`, ...).
- The player sits on the bike while riding (`player.gd` -> `start_riding`): hips on the seat, hands on the grips, toes on the pegs. `tools/make_ride_pose.py` re-solves that pose.
- The bike is parked to the right of the F-150 at the spawn point (see `_make_bike` in `main.gd`).

## Car quality
`scripts/car.gd`: `full_quality = true` uses the full F-150 model (~246k triangles incl. wheels); set it to `false` for the lighter model (~43k triangles). `paint_color` changes the body colour.

## Clouds
`shaders/sky_clouds.gdshader` is the sky: gradient, sun disc and fluffy noise clouds with fake self-shadowing. Cover and darkness follow the weather (`cloud` / `cdark` in `WEATHER_PARAMS`). Wind speed: `cloud_wind` in the shader.

## Water physics / effects (SnowRunner style)
- `scripts/water_fx.gd`: one instance per vehicle (created in `main.gd` `_make_water_fx`). Bow wave + V wake + waterline foam (wake quad), expanding ripple rings left behind, wheel spray, bow spray, big splash when entering water, and the pond shader bends its normals around the vehicle (`veh0` / `veh1` in `map_builder.gd`).
- `main.gd` `_physics_process`: speed-squared water resistance (`0.12 * depth * v^2`), engine power loss in deep water, floating sway (`water_pitch` / `water_roll` on car and bike) and the body rides slightly higher in water.
- Tuning: ring spacing / sizes and particle counts at the top of `water_fx.gd` (`_make_emitter` calls in `setup`), drag coefficient `0.12` in `main.gd`.

## Terrain textures (PBR photo textures)
- `assets/tex/pbr/` holds grass, gravel (trails + dirt), mud and rock: `*_d.jpg` albedo + `*_n.png` normal map (from the Poly Haven leafy_grass / gravel_road / brown_mud_03 / rock_face 1k sets; normals are built from the displacement maps).
- `shaders/terrain_realistic.gdshader` blends them using the baked surface map; tiling per metre is `grass_scale`, `gravel_scale`, `mud_scale`, `rock_scale`. Colour tints: `grass_tint`, `gravel_tint`, `mud_tint`, `rock_tint`. Normal strength: `tex_normal_strength`.
- Rocks (`rock_mat` in `map_builder.gd`) use the rock texture with triplanar mapping (`tex_mix`).
