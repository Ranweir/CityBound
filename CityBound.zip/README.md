# City Bound (Godot 4.3, Android)

Small test map with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.

## Secondary motion / jiggle (Part 2)
- `scripts/secondary_motion.gd`: velocity-driven damped springs for bust and glute bones. Driven by body velocity changes (start/stop, jump, **landing impulse**) and by the animated spine/pelvis bounce (walk, run, turning). Soft-clamped, substepped, skips missing bones.
- `tools/add_jiggle_bones.py`: the original rig had `L_breast`/`R_breast` bones with **no skin weights** and no glute bones. This tool paints the weights and adds `L_Glute`/`R_Glute` under Pelvis. Already applied to `assets/character.glb`. If you regenerate the GLB with `convert.py`, run: `python3 tools/add_jiggle_bones.py new.glb assets/character.glb`
- UI (top-right, below the weather buttons): `Jiggle: ON/OFF` toggle and an intensity slider (0-200%).
- Code: `player.set_jiggle(on, amount)`; tune per-bone `stiffness`, `damping`, `max_offset`, `axis_scale` in `default_targets()`.
