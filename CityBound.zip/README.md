# City Bound (Godot 4.3, Android)

Small test map with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.

## Car (Part 2)
- `assets/car.glb` is converted from the GTA .dff/.txd with `tools/convert_car.py` (`python3 convert_car.py car.dff car.txd ../assets/car.glb 0.05 256`).
- `scripts/vehicle.gd`: VehicleBody3D, rear-wheel drive, soft suspension, speed-sensitive steering, handbrake drift (GTA SA feel).
- Walk next to the car -> yellow **CAR** button appears -> tap to get in. **EXIT** button to get out.
- Driving controls (no joystick): left side `<` `>` steer, right side `^` gas, `v` brake/reverse, `HB` handbrake. Drag on the right side to look around.
- PC: arrows/WASD drive, Space handbrake, F enter/exit.
- Tuning constants (power, top speed, grip, brake) are at the top of `vehicle.gd`; car colour via `set_paint()`.
