# City Bound (Godot 4.3, Android)

Small test map with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (light push = walk, full push = run)
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.
