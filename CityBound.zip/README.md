# City Bound (Godot 4.3, Android)

Hilly offroad test map (terrain, forest, grass, rocks, huts, dirt roads) with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- ENTER / EXIT button (appears near a vehicle) to get in or out of the Ford F-150 Raptor or the NRG-500 motorbike
- Driving (car and bike) uses arrow buttons instead of the joystick: left/right arrows (bottom left) = steer, up arrow (green) = gas, down arrow (red) = brake/reverse, JUMP = handbrake / brake. PC keys still work.
- PC: WASD / arrows, Space = handbrake
- Right side drag: camera
- Camera distance: hold the "+" (further) / "-" (closer) buttons under the weather buttons; the setting is kept for on foot, car and bike
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.

## Map (graphics test)
- `tools/make_map.py` + `tools/make_textures.py` generate `assets/map/*.bin` and `assets/tex/*.png` (run them again after changing the map).
- `scripts/world_builder.gd` builds terrain, collision, trees (near/far LOD), grass, bushes, rocks, huts, gate and fences.
- `shaders/terrain.gdshader` blends grass/dirt/rock with normal maps and rain wetness; `shaders/grass.gdshader` sways in the wind.

## Motorbike (NRG-500, BMW S1000RR livery)
- `assets/bike/nrg500.glb` is the full quality GTA SA model (~30k triangles, original textures, nothing reduced). `tools/convert_bike.py bike.dff bike.txd .` rebuilds it plus `scripts/bike_meta.gd` (wheel positions, steering axis).
- `scripts/bike.gd`: two-wheel spring/damper suspension on the terrain, the bike leans into corners (lean angle from lateral acceleration), the fork steers around its real rake axis, both wheels spin. Tuning values are `@export` vars at the top (`max_speed`, `accel`, `max_lat_acc`, `max_lean`, ...).
- The player sits on the bike while riding (`player.gd` -> `start_riding`): hips on the seat, hands on the grips, toes on the pegs. `tools/make_ride_pose.py` re-solves that pose.
- The bike is parked to the right of the F-150 at the spawn point (see `_make_bike` in `main.gd`).

## Car quality
`scripts/car.gd`: `full_quality = true` uses the full F-150 model (~246k triangles incl. wheels); set it to `false` for the lighter model (~43k triangles). `paint_color` changes the body colour.

## Clouds
`shaders/sky_clouds.gdshader` is the sky: gradient, sun disc and fluffy noise clouds with fake self-shadowing. Cover and darkness follow the weather (`cloud` / `cdark` in `WEATHER_PARAMS`). Wind speed: `cloud_wind` in the shader.

## Water physics / effects (SnowRunner style)
- `scripts/water_fx.gd`: one instance per vehicle (created in `main.gd` `_make_water_fx`). Bow wave + V wake + waterline foam (wake quad), expanding ripple rings left behind, wheel spray, bow spray, big splash when entering water, and the pond shader bends its normals around the vehicle (`veh0` / `veh1` in `map_builder.gd`).
- `main.gd` `_physics_process`: speed-squared water resistance (`0.12 * depth * v^2`), engine power loss in deep water, floating sway (`water_pitch` / `water_roll` on car and bike) and the body rides slightly higher in water.
- Tuning: ring spacing / sizes and particle counts at the top of `water_fx.gd` (`_make_emitter` calls in `setup`), drag coefficient `0.12` in `main.gd`.

## Terrain textures (PBR photo textures)
- `assets/tex/pbr/` holds grass, gravel (trails + dirt), mud and rock: `*_d.jpg` albedo + `*_n.png` normal map (from the Poly Haven leafy_grass / gravel_road / brown_mud_03 / rock_face sets, resized to 512 px for phones; normals are built from the displacement maps).
- `shaders/terrain_realistic.gdshader` blends them using the baked surface map; tiling per metre is `grass_scale`, `gravel_scale`, `mud_scale`, `rock_scale`. Colour tints: `grass_tint`, `gravel_tint`, `mud_tint`, `rock_tint`. Normal strength: `tex_normal_strength`.
- Rocks (`rock_mat` in `map_builder.gd`) use the rock texture with triplanar mapping (`tex_mix`).

## Driving physics v3 (car)
- `scripts/car.gd`: new tyre model. Pacejka-style lateral force (peaks around 8 deg of slip angle, then the tyre slides and keeps ~60-70% of its grip) with slip-angle relaxation, so grip builds up and fades smoothly instead of snapping. Real tyre grip is about 0.9 g (`grip_accel`); the old value was 1.6 g, which is why nothing ever slid believably.
- Weight transfer: braking loads the nose, throttle loads the tail, and lifting off in a fast corner lets the tail swing. Friction circle: braking and driving eat cornering grip. Rear-biased 4x4 (`rear_drive_share`). Mud / wet ground (`grip` from `main.gd`) lowers all of it.
- Handbrake locks the rear tyres but only the rear brakes slow the car (`handbrake_decel`), so the car keeps its speed and slides instead of stopping.
- Driver aids like GTA: `countersteer_assist` (front wheels turn into the slide) and `stability_assist` (past ~8 deg of body slip the nose is pulled back to the direction of travel, so slides recover instead of spinning for ever). Set both to 0 for a raw simulation.
- Steering lock shrinks with speed down to what the tyres can use (`steer_overshoot` > 1 allows a little understeer slide at the limit).
- The car is airborne = no tyre force. The camera swings towards the direction of travel while sliding (`cam_slide` in `main.gd`).
- Tyre smoke (white on tarmac, tan dust on loose ground) and skid marks (pool of `SKID_POOL` quads, fade after ~14 s) while a tyre slides, spins or the handbrake is held. `enable_fx = false` turns both off.
- Handling knobs (`@export`): `grip_accel`, `rear_grip_bias` (<1 = tail-happy, 1.3 = stable), `cg_height`, `yaw_inertia`, `tire_stiff`, `tire_relax`, `handbrake_rear_grip`, `drive_circle` (1 = full simulation, lower = easier to steer on full throttle), `accel`, `brake_decel`.
- Suspension: each corner has its own spring rate (follows its share of the weight, so the heavy front is stiffer), damping is a damping ratio (`damping_bump` soft / `damping_rebound` firm), springs get progressively stiffer deep in the travel, anti-roll bars (`arb_front`, `arb_rear`), 3-tap terrain sampling per wheel. Tyre forces act at CG height, so the body dives under braking, squats under throttle and rolls in corners (`body_motion` exaggerates it: 1 = exact, 2-3 = GTA look).
- `scripts/bike.gd` still uses the v2 model (same suspension upgrades; braking and cornering grip drop on loose ground).

## Texture performance notes
- Each texture has a hand-written `.import` file (`assets/tex/pbr/*.import`): VRAM-compressed (ASTC) + mipmaps. Textures that are only loaded from scripts are otherwise imported as uncompressed images WITHOUT mipmaps, which is very slow on phones.
- The terrain shader samples a material only where it is visible (`textureGrad` inside branches) and skips the anti-tiling tap and normal maps at a distance (`aa_distance`, `detail_distance`).

## Water (pond) look
- `WATER_SHADER` in `scripts/map_builder.gd`: clear shallows (the bottom shows through), deeper blue-green water, fresnel (grazing view = mirror-like sky reflection), 3 layers of scrolling wave normals (from the generated `wave_nrm` texture, fine ripples fade with distance), foam line at the shoreline, rain rings and the vehicle ripples (`veh0` / `veh1`).
- The water mesh stores the signed water depth in the vertex colour (`COLOR.r = 0.5 + depth / 3.2`), so the shoreline and foam follow the real bank.
- Tuning uniforms: `shallow_col`, `deep_col`, `foam_col`, `wave_strength`.
