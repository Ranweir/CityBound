# City Bound (Godot 4.3, Android)

Small test map with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## SAADox 2.0 graphics (Part 3)
- `scripts/SaadoxGraphics.gd` + `scripts/saadox_panel.gd`: ACES tonemap, colour grade, bloom, Low/Medium/High presets, quick Time/Weather panel (top-left).
- PC keys: F1-F3 quality, 5-8 Morning/Noon/Sunset/Night, F5-F8 Sunny/Cloudy/Rain/Post (wetness jumps instantly), F4 freeze time.

## Wet road + PBR (Part 2)
- `shaders/wet_road.gdshader` + `scripts/PBRMaterialHelper.gd`: dry asphalt at road_wetness 0, puddles and reflections as it rises.

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.
