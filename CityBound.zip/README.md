# City Bound (Godot 4.3, Android)

Chhota test map + Mai character (GTA SA skin) with idle / walk / run animation.

## APK kaise banaye
1. Is poore folder ko GitHub repo mein upload karo (`.github/workflows/build.yml` bhi).
2. Repo ke **Actions** tab mein "Build Android APK" chalega (ya "Run workflow" dabao).
3. Run khatam hone par neeche **Artifacts** mein `CityBound-apk` download karo, zip kholo, APK install karo.

Agar folder upload nahi ho raha: sirf `project.zip` (ye poora zip) repo mein upload karo, aur
`.github/workflows/build.yml` GitHub pe "Create new file" se banao. Workflow zip khud khol lega.

## Controls
- Left side: joystick (halka = walk, poora = run)
- Right side drag: camera
- JUMP button
- PC test: WASD, Space, Q/E camera, Shift = walk

## Assets badalna
`tools/convert.py` GTA SA .dff/.txd/.ifp ko `assets/character.glb` mein badalta hai.
