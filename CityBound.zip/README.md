# City Bound (Godot 4.3, Android)

Small test map with a GTA SA skin character and idle / walk / run animations.

## Build the APK
1. Create the file `.github/workflows/build.yml` in your GitHub repo (paste the workflow content).
2. Upload `CityBound.zip` to the repo root (do not extract it).
3. Open the Actions tab. "Build Android APK" runs automatically.
4. When it finishes, download `CityBound-apk` from Artifacts, unzip it and install the APK.

## Controls
- Left side: joystick (walk at GTA SA pace)
- RUN button (hold) while moving = run
- Right side drag: camera
- JUMP button
- PC testing: WASD, Space, Q/E camera, Shift = walk

## Time cycle and weather (Part 1)
- `scripts/TimeCycWeatherManager.gd`: 24h time cycle (dawn, noon, golden sunset, night), weather (Clear, Overcast, Rain, Post-rain) and `road_wetness` (0..1).
- Test buttons top-right: Clear / Cloudy / Rain / Post / +3h. PC keys: 1-4 weather.
- Weather also changes automatically.

## Secondary motion (jiggle)
- `scripts/secondary_motion.gd`: SkeletonModifier3D with damped springs on L_breast, R_breast, Belly and the new L_Glute / R_Glute bones.
- Top-left: JIGGLE ON/OFF button and Intensity slider (0 to 2).
- Tune per bone in `DEFAULT_TARGETS` (stiffness, damping, max_offset, gain).

## Assets
`tools/convert.py` converts GTA SA .dff / .txd / .ifp files into `assets/character.glb`.
`tools/add_glute_bones.py in.glb out.glb` adds the L_Glute / R_Glute jiggle bones (already applied to the shipped character.glb).
