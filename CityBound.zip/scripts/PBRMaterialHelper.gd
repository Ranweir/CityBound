extends RefCounted
# City Bound - Part 2: PBR material helper (Godot 4.3, GL Compatibility).
#
# Usage (no class_name needed, same style as the rest of the project):
#   const PBR = preload("res://scripts/PBRMaterialHelper.gd")
#   m_asphalt = PBR.make_asphalt()
#
# Every texture is optional. If you pass nothing, small seamless procedural textures
# are generated once and cached. To use real textures:
#   PBR.make_asphalt({"albedo": load("res://assets/asphalt_a.png"),
#                     "normal": load("res://assets/asphalt_n.png"), ...})

const WET_ROAD_SHADER: Shader = preload("res://shaders/wet_road.gdshader")
const TEX_SIZE: int = 256

static var _cache: Dictionary = {}

# =====================================================================
#  1. WET-ROAD MATERIALS (ShaderMaterial, driven by global "road_wetness")
# =====================================================================

## maps keys (all optional): albedo, normal, roughness, ao, puddle  (Texture2D)
## params: any shader uniform name -> value (see wet_road.gdshader)
static func make_wet_road(kind: String, maps: Dictionary = {}, params: Dictionary = {}) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = WET_ROAD_SHADER
	var set_d: Dictionary = _surface_set(kind)
	m.set_shader_parameter("albedo_tex", maps.get("albedo", set_d["albedo"]))
	m.set_shader_parameter("normal_tex", maps.get("normal", set_d["normal"]))
	m.set_shader_parameter("roughness_tex", maps.get("roughness", set_d["rough"]))
	m.set_shader_parameter("ao_tex", maps.get("ao", set_d["ao"]))
	m.set_shader_parameter("puddle_mask_tex", maps.get("puddle", puddle_mask_texture()))
	for k in params:
		m.set_shader_parameter(k, params[k])
	return m

static func make_asphalt(maps: Dictionary = {}, params: Dictionary = {}) -> ShaderMaterial:
	var p: Dictionary = {
		"mapping_mode": 1, "tile_m": 6.0, "puddle_tile_m": 20.0,
		"dry_roughness": 0.88, "dry_specular": 0.35, "normal_strength": 1.0,
		"wet_darken": 0.5, "wet_roughness_mul": 0.45, "wet_specular": 0.55,
		"puddle_start": 0.3, "puddle_coverage": 0.42, "puddle_darken": 0.65,
	}
	p.merge(params, true)
	return make_wet_road("asphalt", maps, p)

static func make_pavement(maps: Dictionary = {}, params: Dictionary = {}) -> ShaderMaterial:
	var p: Dictionary = {
		"mapping_mode": 1, "tile_m": 4.0, "puddle_tile_m": 14.0,
		"dry_roughness": 0.92, "dry_specular": 0.30, "normal_strength": 1.0,
		"wet_darken": 0.68, "wet_roughness_mul": 0.55, "wet_specular": 0.5,
		"puddle_start": 0.4, "puddle_coverage": 0.28, "puddle_darken": 0.75,
	}
	p.merge(params, true)
	return make_wet_road("pavement", maps, p)

## Painted lane lines / crosswalks: stay satin, darken a little when wet, never form puddles.
static func make_road_marking(tint: Color = Color(0.93, 0.93, 0.88)) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = WET_ROAD_SHADER
	m.set_shader_parameter("albedo_tint", tint)
	m.set_shader_parameter("mapping_mode", 1)
	m.set_shader_parameter("dry_roughness", 0.75)
	m.set_shader_parameter("dry_specular", 0.3)
	m.set_shader_parameter("normal_strength", 0.0)
	m.set_shader_parameter("wet_darken", 0.82)
	m.set_shader_parameter("wet_roughness_mul", 0.6)
	m.set_shader_parameter("puddle_coverage", 0.0)
	return m

# =====================================================================
#  2. FOLIAGE (StandardMaterial3D)
# =====================================================================

## Vibrant green leaves. For leaf cards pass an RGBA texture + cutout = true.
static func make_foliage(tint: Color = Color(0.16, 0.62, 0.12), albedo_tex: Texture2D = null, cutout: bool = false, double_sided: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = tint
	if albedo_tex != null:
		m.albedo_texture = albedo_tex
	m.roughness = 0.72
	m.metallic = 0.0
	m.metallic_specular = 0.25
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.backlight_enabled = true                      # light shining through the leaves
	m.backlight = Color(0.28, 0.42, 0.1)
	if cutout:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR   # crisp edges + correct shadows, no sorting
		m.alpha_scissor_threshold = 0.5
	if cutout or double_sided:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m

## Palm frond card: cutout texture, double sided, a bit more yellow-green and glossy.
static func make_palm_frond(albedo_tex: Texture2D = null) -> StandardMaterial3D:
	var m: StandardMaterial3D = make_foliage(Color(0.2, 0.68, 0.14), albedo_tex, albedo_tex != null, true)
	m.roughness = 0.6
	m.metallic_specular = 0.35
	return m

static func make_bark(tint: Color = Color(0.4, 0.28, 0.16)) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = tint
	m.roughness = 0.95
	m.metallic_specular = 0.1
	return m

# =====================================================================
#  3. BUILDING WALLS (StandardMaterial3D, world triplanar)
# =====================================================================

## Brick wall. Default texture: 4 bricks x 16 rows per tile -> tile_m = 1.0 gives 25 x 6 cm bricks.
static func make_brick(tile_m: float = 1.0, maps: Dictionary = {}) -> StandardMaterial3D:
	var d: Dictionary = _brick_set()
	return _wall_material(
		maps.get("albedo", d["albedo"]), maps.get("normal", d["normal"]),
		maps.get("roughness", d["rough"]), maps.get("ao", d["ao"]),
		tile_m, 1.15, 0.9)

## Concrete wall with panel joints (2x2 panels per tile).
static func make_concrete_wall(tile_m: float = 4.0, maps: Dictionary = {}) -> StandardMaterial3D:
	var d: Dictionary = _surface_set("concrete")
	return _wall_material(
		maps.get("albedo", d["albedo"]), maps.get("normal", d["normal"]),
		maps.get("roughness", d["rough"]), maps.get("ao", d["ao"]),
		tile_m, 1.0, 0.95)

static func _wall_material(alb: Texture2D, nrm: Texture2D, rgh: Texture2D, ao: Texture2D, tile_m: float, normal_scale: float, roughness_mul: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = alb
	m.normal_enabled = true
	m.normal_texture = nrm
	m.normal_scale = normal_scale
	m.roughness = roughness_mul
	m.roughness_texture = rgh
	m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_RED
	m.ao_enabled = true
	m.ao_texture = ao
	m.ao_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_RED
	m.ao_light_affect = 0.4
	m.metallic = 0.0
	m.metallic_specular = 0.2
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	var s: float = 1.0 / maxf(tile_m, 0.01)
	m.uv1_scale = Vector3(s, s, s)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	return m

# =====================================================================
#  4. WETNESS FOR STANDARD MATERIALS (walls get slightly darker / smoother)
# =====================================================================

static func apply_wetness(mat: StandardMaterial3D, wetness: float, darken: float = 0.8, rough_mul: float = 0.65) -> void:
	if not mat.has_meta("dry_albedo"):
		mat.set_meta("dry_albedo", mat.albedo_color)
		mat.set_meta("dry_rough", mat.roughness)
	var a: Color = mat.get_meta("dry_albedo")
	var k: float = lerpf(1.0, darken, wetness)
	mat.albedo_color = Color(a.r * k, a.g * k, a.b * k, a.a)
	mat.roughness = float(mat.get_meta("dry_rough")) * lerpf(1.0, rough_mul, wetness)

## Connects TimeCycWeatherManager.road_wetness_changed to a list of StandardMaterial3D.
static func bind_wetness(tc: Node, mats: Array) -> void:
	var update := func(v: float) -> void:
		for m in mats:
			if m is StandardMaterial3D:
				apply_wetness(m, v)
	tc.road_wetness_changed.connect(update)
	update.call(float(tc.road_wetness))

# =====================================================================
#  5. CRISP SHADOWS + MOBILE REFLECTIONS
# =====================================================================

static func tune_sun_shadows(sun: DirectionalLight3D, max_distance: float = 70.0) -> void:
	if sun == null:
		return
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_split_1 = 0.25
	sun.directional_shadow_blend_splits = false     # cheaper, no visible seam at this range
	sun.directional_shadow_max_distance = max_distance
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.0
	sun.shadow_blur = 0.6                           # < 1.0 = sharper edges

## One ReflectionProbe over the whole map. Captured once, then re-captured when the game hour or
## the weather changes (cheap: one cube render, not every frame). The wet-road shader picks it up
## through low ROUGHNESS. If your build ignores probes, the sky radiance still reflects.
static func add_reflection_probe(parent: Node3D, tc: Node = null, half_extents: Vector3 = Vector3(90.0, 12.0, 90.0)) -> ReflectionProbe:
	var p := ReflectionProbe.new()
	p.name = "RoadReflectionProbe"
	p.size = half_extents * 2.0
	p.position = Vector3(0.0, 4.0, 0.0)
	p.box_projection = true
	p.interior = false
	p.enable_shadows = false
	p.ambient_mode = ReflectionProbe.AMBIENT_DISABLED
	p.update_mode = ReflectionProbe.UPDATE_ONCE
	p.intensity = 1.0
	parent.add_child(p)
	if tc != null:
		tc.hour_changed.connect(func(_h: int) -> void: _refresh_probe(p))
		tc.weather_changed.connect(func(_w: int) -> void: _refresh_probe(p))
	return p

static func _refresh_probe(p: ReflectionProbe) -> void:
	if p == null or not p.is_inside_tree() or p.has_meta("refreshing"):
		return
	p.set_meta("refreshing", true)
	p.update_mode = ReflectionProbe.UPDATE_ALWAYS
	await p.get_tree().create_timer(1.5).timeout    # let the incremental sky update catch up
	if is_instance_valid(p):
		p.update_mode = ReflectionProbe.UPDATE_ONCE
		p.remove_meta("refreshing")

# =====================================================================
#  6. PROCEDURAL FALLBACK TEXTURES (seamless, generated once, cached)
# =====================================================================

static func puddle_mask_texture() -> Texture2D:
	if _cache.has("puddle"):
		return _cache["puddle"]
	var img: Image = _noise_img(0.018, 21, 3)
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_cache["puddle"] = t
	return t

static func _noise_img(freq: float, seed_v: int, octaves: int) -> Image:
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.seed = seed_v
	n.frequency = freq
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = octaves
	return n.get_seamless_image(TEX_SIZE, TEX_SIZE, false, false, 0.1, true)

static func _gray(v: float) -> Color:
	return Color(v, v, v, 1.0)

static func _to_tex(img: Image, normal: bool = false) -> Texture2D:
	img.generate_mipmaps(normal)
	return ImageTexture.create_from_image(img)

## kind: "asphalt" | "pavement" (joints every 1 m at 4 m tile) | "concrete" (panel joints)
static func _surface_set(kind: String) -> Dictionary:
	if _cache.has(kind):
		return _cache[kind]
	var s: int = TEX_SIZE
	var base: Color = Color(0.17, 0.17, 0.185)
	var contrast: float = 0.05
	var seam_period: int = 0
	if kind == "pavement":
		base = Color(0.64, 0.63, 0.6)
		contrast = 0.06
		seam_period = 64
	elif kind == "concrete":
		base = Color(0.66, 0.65, 0.62)
		contrast = 0.05
		seam_period = 128
	var coarse: Image = _noise_img(0.012, 11, 3)
	var fine: Image = _noise_img(0.22, 12, 2)
	var alb := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var bump := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var rgh := Image.create(s, s, false, Image.FORMAT_L8)
	var aoi := Image.create(s, s, false, Image.FORMAT_L8)
	for y in range(s):
		for x in range(s):
			var c: float = coarse.get_pixel(x, y).r
			var f: float = fine.get_pixel(x, y).r
			var seam: float = 0.0
			if seam_period > 0 and (x % seam_period < 2 or y % seam_period < 2):
				seam = 1.0
			var v: float = (c - 0.5) * contrast * 1.2 + (f - 0.5) * contrast
			if kind == "asphalt" and f > 0.8:
				v += 0.05                           # bright aggregate chips
			v -= seam * 0.06
			alb.set_pixel(x, y, Color(clampf(base.r + v, 0.0, 1.0), clampf(base.g + v, 0.0, 1.0), clampf(base.b + v * 1.05, 0.0, 1.0), 1.0))
			bump.set_pixel(x, y, _gray(clampf(f * 0.55 + c * 0.25 + 0.2 - seam * 0.5, 0.0, 1.0)))
			rgh.set_pixel(x, y, _gray(clampf(0.82 + f * 0.18 + seam * 0.1, 0.0, 1.0)))
			aoi.set_pixel(x, y, _gray(clampf(0.92 + c * 0.08 - seam * 0.45, 0.0, 1.0)))
	bump.bump_map_to_normal_map(3.0 if kind == "asphalt" else 2.0)
	var d: Dictionary = {
		"albedo": _to_tex(alb), "normal": _to_tex(bump, true),
		"rough": _to_tex(rgh), "ao": _to_tex(aoi),
	}
	_cache[kind] = d
	return d

## Running-bond brick: 4 bricks x 16 rows per tile, 2 px mortar, beveled edges.
static func _brick_set() -> Dictionary:
	if _cache.has("brick"):
		return _cache["brick"]
	var s: int = TEX_SIZE
	var noise: Image = _noise_img(0.2, 31, 2)
	var alb := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var bump := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var rgh := Image.create(s, s, false, Image.FORMAT_L8)
	var aoi := Image.create(s, s, false, Image.FORMAT_L8)
	var mortar := Color(0.7, 0.68, 0.62)
	for y in range(s):
		var row: int = y / 16
		var ry: int = y % 16
		var off: int = (row % 2) * 32
		for x in range(s):
			var xx: int = (x + off) % s
			var bx: int = xx % 64
			var bi: int = xx / 64
			var n: float = noise.get_pixel(x, y).r
			var d: int = mini(mini(ry - 2, 15 - ry), mini(bx - 2, 63 - bx))
			if d < 0:
				alb.set_pixel(x, y, Color(mortar.r + (n - 0.5) * 0.08, mortar.g + (n - 0.5) * 0.08, mortar.b + (n - 0.5) * 0.08, 1.0))
				bump.set_pixel(x, y, _gray(0.0))
				rgh.set_pixel(x, y, _gray(1.0))
				aoi.set_pixel(x, y, _gray(0.55))
			else:
				var id: float = float(hash(Vector2i(row, bi)) & 1023) / 1023.0   # per-brick tint
				var tint: float = (id - 0.5) * 0.18
				var k: float = (n - 0.5) * 0.12
				alb.set_pixel(x, y, Color(clampf(0.62 + tint + k, 0.0, 1.0), clampf(0.27 + tint * 0.5 + k, 0.0, 1.0), clampf(0.2 + tint * 0.4 + k, 0.0, 1.0), 1.0))
				bump.set_pixel(x, y, _gray(clampf(0.55 + minf(float(d) / 3.0, 1.0) * 0.4 + n * 0.05, 0.0, 1.0)))
				rgh.set_pixel(x, y, _gray(clampf(0.8 + n * 0.2, 0.0, 1.0)))
				aoi.set_pixel(x, y, _gray(clampf(0.75 + minf(float(d) / 3.0, 1.0) * 0.25, 0.0, 1.0)))
	bump.bump_map_to_normal_map(4.0)
	var out: Dictionary = {
		"albedo": _to_tex(alb), "normal": _to_tex(bump, true),
		"rough": _to_tex(rgh), "ao": _to_tex(aoi),
	}
	_cache["brick"] = out
	return out
