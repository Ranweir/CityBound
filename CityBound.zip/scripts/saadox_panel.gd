extends Control
# SAADox 2.0 quick-test panel (Time / Weather / Quality).
# Drawn and hit-tested by hand, exactly like touch_ui.gd, because this project has
# emulate_mouse_from_touch = false (regular Buttons would not react to touch).

signal action(group: String, idx: int)

const ORIGIN: Vector2 = Vector2(20.0, 56.0)
const BTN: Vector2 = Vector2(92.0, 36.0)
const GAP: float = 6.0
const HEADER: Array = ["GFX", "AutoWx", "Freeze"]
const ROWS: Array = [
	{"group": "time", "labels": ["Morning", "Noon", "Sunset", "Night"], "color": Color(1.0, 0.75, 0.25)},
	{"group": "weather", "labels": ["Sunny", "Cloudy", "Rain", "Post"], "color": Color(0.35, 0.65, 1.0)},
	{"group": "quality", "labels": ["Low", "Med", "High", "AutoFPS"], "color": Color(0.4, 0.9, 0.45)},
]

var expanded: bool = true
var selected: Dictionary = {"time": -1, "weather": 0, "quality": 1}
var toggles: Array = [true, true, false]   # [expanded, auto weather, time frozen]
var auto_fps: bool = false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func set_selected(group: String, idx: int) -> void:
	selected[group] = idx
	queue_redraw()

func set_toggle(idx: int, on: bool) -> void:
	toggles[idx] = on
	queue_redraw()

func set_auto_fps(on: bool) -> void:
	auto_fps = on
	queue_redraw()

func _rect(row: int, i: int) -> Rect2:
	# row -1 = header, 0.. = ROWS
	var y: float = ORIGIN.y + float(row + 1) * (BTN.y + GAP)
	return Rect2(ORIGIN.x + float(i) * (BTN.x + GAP), y, BTN.x, BTN.y)

func _input(event: InputEvent) -> void:
	if not (event is InputEventScreenTouch):
		return
	var t: InputEventScreenTouch = event
	if not t.pressed:
		return
	for i in range(HEADER.size()):
		if _rect(-1, i).has_point(t.position):
			if i == 0:
				expanded = not expanded
				toggles[0] = expanded
				queue_redraw()
			action.emit("hdr", i)
			get_viewport().set_input_as_handled()   # keep the joystick / camera from starting under the panel
			return
	if not expanded:
		return
	for r in range(ROWS.size()):
		var labels: Array = ROWS[r]["labels"]
		for i in range(labels.size()):
			if _rect(r, i).has_point(t.position):
				action.emit(str(ROWS[r]["group"]), i)
				get_viewport().set_input_as_handled()
				return

func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	for i in range(HEADER.size()):
		_draw_btn(_rect(-1, i), str(HEADER[i]), bool(toggles[i]), Color(0.85, 0.85, 0.85), font)
	if not expanded:
		return
	for r in range(ROWS.size()):
		var group: String = str(ROWS[r]["group"])
		var labels: Array = ROWS[r]["labels"]
		for i in range(labels.size()):
			var on: bool = int(selected[group]) == i
			if group == "quality" and i == 3:
				on = auto_fps
			_draw_btn(_rect(r, i), str(labels[i]), on, ROWS[r]["color"], font)

func _draw_btn(r: Rect2, text: String, on: bool, tint: Color, font: Font) -> void:
	var fill: Color = Color(tint.r * 0.6, tint.g * 0.6, tint.b * 0.6, 0.8) if on else Color(0, 0, 0, 0.45)
	draw_rect(r, fill, true)
	draw_rect(r, Color(1, 1, 1, 0.85 if on else 0.4), false, 2.0)
	draw_string(font, r.position + Vector2(0.0, 25.0), text, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 18, Color(1, 1, 1, 0.95))
