extends CharacterBody3D
# Third-person player: GTA-SA skin (converted .glb) + idle / walk / run animations.

# Speeds are tied to the original GTA SA clips so the feet never slide.
# WALK_CLIP_SPEED / RUN_CLIP_SPEED = metres per second the original clip travels at 1.0x.
const WALK_CLIP_SPEED: float = 0.72
const RUN_CLIP_SPEED: float = 2.11
const WALK_ANIM_SCALE: float = 1.0    # 1.0 = same pace as the GTA SA walk (reference video)
const RUN_ANIM_SCALE: float = 1.0     # 1.0 = original GTA SA run pace
const WALK_SPEED: float = WALK_CLIP_SPEED * WALK_ANIM_SCALE
const RUN_SPEED: float = RUN_CLIP_SPEED * RUN_ANIM_SCALE
const JUMP_VELOCITY: float = 5.2
const GRAVITY: float = 14.0
const FEET_OFFSET: float = 1.07       # model origin is at the hips, feet are 1.07 m lower

var ui = null            # touch_ui.gd instance (set by main.gd)
var cam_pivot: Node3D = null
var model: Node3D = null
var anim: AnimationPlayer = null
var current_state: String = ""
var spawn_pos: Vector3 = Vector3.ZERO
var jiggle = null        # secondary_motion.gd instance (spring/jiggle physics)

func _ready() -> void:
	spawn_pos = global_position
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	var col := CollisionShape3D.new()
	col.shape = shape
	col.position = Vector3(0.0, 0.9, 0.0)
	add_child(col)

	model = Node3D.new()
	add_child(model)
	model.rotation.y = PI   # face -Z (same way the camera looks at start)

	var scene: PackedScene = load("res://assets/character.glb")
	var inst: Node = scene.instantiate()
	model.add_child(inst)
	if inst is Node3D:
		(inst as Node3D).position = Vector3(0.0, FEET_OFFSET, 0.0)

	anim = inst.find_child("AnimationPlayer", true, false) as AnimationPlayer
	if anim != null:
		for n in anim.get_animation_list():
			var a: Animation = anim.get_animation(n)
			a.loop_mode = Animation.LOOP_LINEAR
		_play("idle", 1.0)
	else:
		push_warning("AnimationPlayer not found in character.glb")
	_setup_secondary_motion(inst)

func _setup_secondary_motion(root: Node) -> void:
	var skels: Array = root.find_children("*", "Skeleton3D", true, false)
	if skels.is_empty():
		return
	var skel: Skeleton3D = skels[0]
	jiggle = load("res://scripts/secondary_motion.gd").new()
	jiggle.name = "SecondaryMotion"
	skel.add_child(jiggle)          # SkeletonModifier3D must be a child of the skeleton
	jiggle.setup(skel, self)

func set_jiggle_enabled(on: bool) -> void:
	if jiggle != null:
		jiggle.set_enabled(on)

func set_jiggle_intensity(v: float) -> void:
	if jiggle != null:
		jiggle.intensity = v

func _play(state: String, speed: float) -> void:
	if anim == null:
		return
	if state != current_state:
		if anim.has_animation(state):
			anim.play(state, 0.2)
		current_state = state
	anim.speed_scale = speed

func _physics_process(delta: float) -> void:
	var iv: Vector2 = Vector2.ZERO
	if ui != null:
		iv = ui.move_vec

	# keyboard (for testing on PC)
	var kx: float = 0.0
	var ky: float = 0.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		kx -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		kx += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		ky -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		ky += 1.0
	if kx != 0.0 or ky != 0.0:
		iv = Vector2(kx, ky).normalized()

	var mag: float = minf(iv.length(), 1.0)
	var yaw: float = 0.0
	if cam_pivot != null:
		yaw = cam_pivot.rotation.y
	var dir: Vector3 = Vector3(iv.x, 0.0, iv.y).rotated(Vector3.UP, yaw)

	var speed: float = 0.0
	var state: String = "idle"
	var clip_scale: float = 1.0
	if mag > 0.15:
		var running: bool = Input.is_key_pressed(KEY_SHIFT)
		if ui != null and ui.run_held:
			running = true
		if running:
			speed = RUN_SPEED
			state = "run"
			clip_scale = RUN_ANIM_SCALE
		else:
			speed = WALK_SPEED
			state = "walk"
			clip_scale = WALK_ANIM_SCALE
		dir = dir.normalized()
		var target_yaw: float = atan2(dir.x, dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, target_yaw, 1.0 - exp(-14.0 * delta))
	else:
		dir = Vector3.ZERO

	var accel: float = 1.0 - exp(-12.0 * delta)
	velocity.x = lerpf(velocity.x, dir.x * speed, accel)
	velocity.z = lerpf(velocity.z, dir.z * speed, accel)

	var want_jump: bool = Input.is_key_pressed(KEY_SPACE)
	if ui != null and ui.jump_pressed:
		want_jump = true
		ui.jump_pressed = false

	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif want_jump:
		velocity.y = JUMP_VELOCITY

	move_and_slide()

	if is_on_floor():
		_play(state, clip_scale)
	else:
		_play(current_state if current_state != "" else "idle", 1.0)

	if global_position.y < -30.0:
		global_position = spawn_pos
		velocity = Vector3.ZERO
