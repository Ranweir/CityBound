extends SkeletonModifier3D
# Velocity-driven secondary motion (damped springs) for a skinned character. Godot 4.3+.
#
# HOW IT WORKS
#  * Runs as a SkeletonModifier3D, i.e. AFTER the AnimationPlayer has posed the skeleton,
#    so it layers on top of idle / walk / run without fighting them.
#  * For every target bone it tracks the bone's animated WORLD position. The change of that
#    position's velocity (walking bounce, run bounce, start/stop, turning, jump take-off,
#    landing) is injected into a damped spring as an impulse (inertia). The spring then
#    wobbles back to rest.  Linear + angular body motion are therefore both captured per bone.
#  * Landing gets an extra boost based on the fall speed, turning a small gain on top.
#  * Offsets are clamped (max_offset / max_angle) so nothing can explode or clip wildly.
#  * Missing bones are silently skipped. Disable = modifier inactive + pose restored.
#
# USAGE (see player.gd):
#   var sm = load("res://scripts/secondary_motion.gd").new()
#   skeleton.add_child(sm)          # must be a child of the Skeleton3D
#   sm.setup(skeleton, character_body)
#   sm.enabled = false              # toggle
#   sm.intensity = 0.5              # 0..2 slider

# Per target:  names = bone name candidates (first one found is used)
#              mode = "translate" (soft tissue, moves the bone) or "rotate" (bends bone toward its child)
#              stiffness = spring k in 1/s^2  (higher = faster, tighter)   e.g. 420 -> ~3 Hz
#              damping   = c in 1/s (higher = settles quicker)             e.g. 11 -> a few visible wobbles
#              max_offset = metres, max_angle = degrees (rotate mode), gain = impulse multiplier
const DEFAULT_TARGETS: Array = [
	{"names": ["L_breast", "L_Breast", "Bip01_L_Breast", "L_Bust"], "mode": "translate", "stiffness": 420.0, "damping": 11.0, "max_offset": 0.03, "gain": 2.0},
	{"names": ["R_breast", "R_Breast", "Bip01_R_Breast", "R_Bust"], "mode": "translate", "stiffness": 420.0, "damping": 11.0, "max_offset": 0.03, "gain": 2.0},
	{"names": ["L_Glute", "L_glute", "L_Butt", "L_butt"], "mode": "translate", "stiffness": 360.0, "damping": 15.0, "max_offset": 0.028, "gain": 1.6},
	{"names": ["R_Glute", "R_glute", "R_Butt", "R_butt"], "mode": "translate", "stiffness": 360.0, "damping": 15.0, "max_offset": 0.028, "gain": 1.6},
	{"names": ["Belly", "belly"], "mode": "translate", "stiffness": 300.0, "damping": 14.0, "max_offset": 0.018, "gain": 1.2},
]

const MAX_IMPULSE: float = 3.0          # m/s, per bone per frame (safety)
const MAX_SUBSTEP: float = 1.0 / 90.0   # spring integration step (stable for k up to ~8000)
const TELEPORT_DIST: float = 1.0        # bone jumped further than this in a frame -> reset (respawn)
const LANDING_MIN_SPEED: float = 2.0    # m/s downwards to count as a landing

@export var enabled: bool = true : set = set_enabled
@export_range(0.0, 2.0, 0.05) var intensity: float = 1.0
@export_range(0.0, 2.0, 0.05) var landing_boost: float = 0.8
@export_range(0.0, 2.0, 0.05) var turn_gain: float = 0.5

class Spring:
	var bone: int = -1
	var parent: int = -1
	var child: int = -1
	var rotate_mode: bool = false
	var stiffness: float = 400.0
	var damping: float = 12.0
	var max_offset: float = 0.02
	var max_angle: float = 2.0
	var gain: float = 1.0
	# state (world space)
	var d: Vector3 = Vector3.ZERO
	var v: Vector3 = Vector3.ZERO
	var prev_anchor: Vector3 = Vector3.ZERO
	var prev_vel: Vector3 = Vector3.ZERO
	var has_prev: bool = false
	var has_vel: bool = false
	# pose bookkeeping (so we never accumulate on bones the animation doesn't key)
	var base_pos: Vector3 = Vector3.ZERO
	var base_rot: Quaternion = Quaternion.IDENTITY
	var out_pos: Vector3 = Vector3.ZERO
	var out_rot: Quaternion = Quaternion.IDENTITY
	var has_out: bool = false

var _skel: Skeleton3D = null
var _body: CharacterBody3D = null
var _springs: Array[Spring] = []
var _last_us: int = 0
var _was_on_floor: bool = true
var _prev_vy: float = 0.0
var _prev_yaw: float = 0.0
var _has_yaw: bool = false

# Public read-outs (handy for a debug HUD)
var body_speed: float = 0.0
var yaw_rate: float = 0.0

func setup(skeleton: Skeleton3D, body: CharacterBody3D = null, configs: Array = DEFAULT_TARGETS) -> void:
	_skel = skeleton
	_body = body
	_springs.clear()
	if _skel == null:
		return
	var found: PackedStringArray = PackedStringArray()
	for cfg in configs:
		var idx: int = -1
		for n in cfg.get("names", []):
			idx = _skel.find_bone(str(n))
			if idx != -1:
				break
		if idx == -1:
			continue   # optional bone missing on this rig -> skip silently
		var s := Spring.new()
		s.bone = idx
		s.parent = _skel.get_bone_parent(idx)
		s.stiffness = float(cfg.get("stiffness", 400.0))
		s.damping = float(cfg.get("damping", 12.0))
		s.max_offset = float(cfg.get("max_offset", 0.02))
		s.max_angle = float(cfg.get("max_angle", 2.0))
		s.gain = float(cfg.get("gain", 1.0))
		if str(cfg.get("mode", "translate")) == "rotate":
			var kids: PackedInt32Array = _skel.get_bone_children(idx)
			if kids.size() > 0:
				s.child = kids[0]
				s.rotate_mode = true
		_springs.append(s)
		found.append(_skel.get_bone_name(idx))
	_last_us = Time.get_ticks_usec()
	set_enabled(enabled)
	print("SecondaryMotion bones: ", ", ".join(found) if found.size() > 0 else "(none found)")

func set_enabled(v: bool) -> void:
	enabled = v
	active = v
	if v:
		_reset_state()
	else:
		_restore_pose()

func _reset_state() -> void:
	for s in _springs:
		s.d = Vector3.ZERO
		s.v = Vector3.ZERO
		s.has_prev = false
		s.has_vel = false
		s.has_out = false
	_last_us = Time.get_ticks_usec()

func _restore_pose() -> void:
	if _skel == null:
		return
	for s in _springs:
		if s.has_out:
			_skel.set_bone_pose_position(s.bone, s.base_pos)
			_skel.set_bone_pose_rotation(s.bone, s.base_rot)
			s.has_out = false
		s.d = Vector3.ZERO
		s.v = Vector3.ZERO

func _process_modification() -> void:
	if _skel == null or _springs.is_empty():
		return
	var now: int = Time.get_ticks_usec()
	var dt: float = clampf(float(now - _last_us) * 0.000001, 0.0, 0.05)
	_last_us = now
	var step: bool = dt > 0.0005

	var skel_xf: Transform3D = _skel.global_transform
	var skel_inv: Basis = skel_xf.basis.inverse()

	# --- body level velocities: landing impulse + turning ---------------------------------
	var impulse_mul: float = 1.0
	if step:
		if _body != null:
			body_speed = Vector2(_body.velocity.x, _body.velocity.z).length()
			var on_floor: bool = _body.is_on_floor()
			if on_floor and not _was_on_floor and _prev_vy < -LANDING_MIN_SPEED:
				impulse_mul += landing_boost * clampf(-_prev_vy / 8.0, 0.0, 1.5)
			_was_on_floor = on_floor
			_prev_vy = _body.velocity.y
		var yaw: float = skel_xf.basis.get_euler().y
		if _has_yaw:
			yaw_rate = wrapf(yaw - _prev_yaw, -PI, PI) / dt
		_prev_yaw = yaw
		_has_yaw = true
		impulse_mul *= 1.0 + turn_gain * clampf(absf(yaw_rate) / 8.0, 0.0, 1.0)

	var k_int: float = clampf(intensity, 0.0, 2.0)

	for s in _springs:
		# 1) get this frame's animated pose (undo our previous output if the animation didn't override it)
		var cur_p: Vector3 = _skel.get_bone_pose_position(s.bone)
		var cur_r: Quaternion = _skel.get_bone_pose_rotation(s.bone)
		if s.has_out and cur_p.is_equal_approx(s.out_pos) and cur_r.is_equal_approx(s.out_rot):
			cur_p = s.base_pos
			cur_r = s.base_rot
			_skel.set_bone_pose_position(s.bone, cur_p)
			_skel.set_bone_pose_rotation(s.bone, cur_r)
		s.base_pos = cur_p
		s.base_rot = cur_r

		# 2) animated anchor in world space, then step the spring
		var anchor: Vector3 = skel_xf * _skel.get_bone_global_pose(s.bone).origin
		if step:
			_step_spring(s, anchor, dt, impulse_mul)

		# 3) write the offset back onto the bone
		if k_int > 0.001:
			_apply(s, skel_inv, k_int)

func _step_spring(s: Spring, anchor: Vector3, dt: float, impulse_mul: float) -> void:
	if not s.has_prev:
		s.prev_anchor = anchor
		s.has_prev = true
		return
	var moved: Vector3 = anchor - s.prev_anchor
	s.prev_anchor = anchor
	if moved.length() > TELEPORT_DIST:
		s.d = Vector3.ZERO
		s.v = Vector3.ZERO
		s.has_vel = false
		return
	var vel: Vector3 = moved / dt
	if s.has_vel:
		# change of the bone's velocity = inertial impulse (spring lags behind, then rebounds)
		var dv: Vector3 = (vel - s.prev_vel) * s.gain * impulse_mul
		var dvl: float = dv.length()
		if dvl > MAX_IMPULSE:
			dv *= MAX_IMPULSE / dvl
		s.v -= dv
	s.prev_vel = vel
	s.has_vel = true

	var n: int = maxi(1, ceili(dt / MAX_SUBSTEP))
	var h: float = dt / float(n)
	for i in n:
		s.v += (-s.stiffness * s.d - s.damping * s.v) * h
		s.d += s.v * h
		var dist: float = s.d.length()
		if dist > s.max_offset:
			var nrm: Vector3 = s.d / dist
			s.d = nrm * s.max_offset
			var vn: float = s.v.dot(nrm)
			if vn > 0.0:
				s.v -= nrm * vn

func _apply(s: Spring, skel_inv: Basis, k_int: float) -> void:
	var off: Vector3 = skel_inv * (s.d * k_int)   # offset in skeleton space
	var parent_basis: Basis = Basis.IDENTITY
	if s.parent >= 0:
		parent_basis = _skel.get_bone_global_pose(s.parent).basis

	if not s.rotate_mode:
		var p: Vector3 = s.base_pos + parent_basis.inverse() * off
		_skel.set_bone_pose_position(s.bone, p)
		s.out_pos = p
		s.out_rot = s.base_rot
		s.has_out = true
		return

	# rotate mode: bend the bone so its tip (towards the child) follows the offset
	var tip: Vector3 = _skel.get_bone_global_pose(s.child).origin - _skel.get_bone_global_pose(s.bone).origin
	var l: float = tip.length()
	if l < 0.01:
		return
	var tn: Vector3 = tip / l
	var perp: Vector3 = off - tn * off.dot(tn)
	var mag: float = perp.length()
	if mag < 0.00001:
		return
	var ang: float = minf(mag / l, deg_to_rad(s.max_angle))
	var q_s := Quaternion(tn.cross(perp).normalized(), ang)
	var pr: Quaternion = parent_basis.orthonormalized().get_rotation_quaternion()
	var q_p: Quaternion = pr.inverse() * q_s * pr
	var r: Quaternion = (q_p * s.base_rot).normalized()
	_skel.set_bone_pose_rotation(s.bone, r)
	s.out_rot = r
	s.out_pos = s.base_pos
	s.has_out = true
