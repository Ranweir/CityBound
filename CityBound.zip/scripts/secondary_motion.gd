extends Node
# Secondary motion ("jiggle") for a skinned character: damped springs that drive
# optional bones (bust, glutes) from the character's movement.
#
# Where the motion comes from
#   1. Body velocity changes (CharacterBody3D.velocity, sampled each physics tick):
#      start / stop, direction change, jump take-off and, above all, LANDING.
#      These are applied as velocity kicks (impulses) to the springs.
#   2. Animation-driven motion of the parent bone (spine / pelvis bounce while
#      walking, running or sprinting, and the sideways swing when the model turns).
#      The parent bone's position relative to the body is differentiated twice
#      and fed in as an inertial acceleration.
#
# Safe by design
#   * Missing bones are skipped (one warning, no runtime errors).
#   * Soft-clamped offsets (tanh), substepped integration, NaN guard.
#   * Only a few Vector3 operations per bone per frame (4 bones by default).
#
# Usage (see player.gd):
#   var sm = load("res://scripts/secondary_motion.gd").attach(body, facing_node, character_root)
#   sm.enabled = false          # toggle
#   sm.intensity = 1.0          # 0 .. 2
#
# The offsets are applied as bone *position* offsets, so the target bones must
# have skin weights (tools/add_jiggle_bones.py does that for character.glb).

const MAX_SUBSTEP: float = 1.0 / 120.0
const ACCEL_SMOOTH_HZ: float = 28.0     # low-pass on the differentiated animation motion
const LANDING_MIN_SPEED: float = 2.5    # m/s of downward speed that counts as a landing
const MAX_KICK: float = 0.9             # m/s, hard cap for one impulse

@export var enabled: bool = true:
	set(value):
		if value == enabled:
			return
		enabled = value
		if enabled:
			reset()
		else:
			_release_bones()
@export_range(0.0, 2.0, 0.01) var intensity: float = 1.0
## How strongly animation / turning accelerations drive the springs.
@export_range(0.0, 2.0, 0.01) var anim_gain: float = 0.5
## Spring velocity (m/s) added per 1 m/s of body velocity change (start/stop/jump/landing).
@export_range(0.0, 0.5, 0.005) var impulse_gain: float = 0.10
## Extra multiplier applied to the impulse when landing.
@export_range(1.0, 3.0, 0.05) var landing_boost: float = 1.5
## Extra motion when moving fast (running / sprinting). 1.0 = none.
@export_range(1.0, 2.5, 0.05) var run_boost: float = 1.25
@export var max_accel: float = 45.0     # m/s^2 clamp on the animation-driven acceleration

# One entry per bone. axis_scale is in the character's own frame: x = sideways, y = up, z = forward.
# stiffness -> spring frequency (k = w^2), damping -> c = 2 * zeta * w.
static func default_targets() -> Array:
	return [
		{"id": "bust_l", "bones": PackedStringArray(["L_breast", "Bip01 L Breast", "Breast_L", "breast.L", "L_Bust"]),
			"stiffness": 650.0, "damping": 11.0, "max_offset": 0.022, "axis_scale": Vector3(0.55, 1.0, 0.7)},
		{"id": "bust_r", "bones": PackedStringArray(["R_breast", "Bip01 R Breast", "Breast_R", "breast.R", "R_Bust"]),
			"stiffness": 650.0, "damping": 11.0, "max_offset": 0.022, "axis_scale": Vector3(0.55, 1.0, 0.7)},
		{"id": "glute_l", "bones": PackedStringArray(["L_Glute", "L_Butt", "Glute_L", "Butt_L", "glute.L"]),
			"stiffness": 900.0, "damping": 18.0, "max_offset": 0.016, "axis_scale": Vector3(0.45, 1.0, 0.5)},
		{"id": "glute_r", "bones": PackedStringArray(["R_Glute", "R_Butt", "Glute_R", "Butt_R", "glute.R"]),
			"stiffness": 900.0, "damping": 18.0, "max_offset": 0.016, "axis_scale": Vector3(0.45, 1.0, 0.5)},
	]

class Spring:
	var id: String = ""
	var bone: int = -1
	var parent: int = -1
	var rest_origin: Vector3 = Vector3.ZERO
	var k: float = 700.0
	var c: float = 12.0
	var max_offset: float = 0.02
	var axis_scale: Vector3 = Vector3.ONE
	var x: Vector3 = Vector3.ZERO          # offset, character frame
	var v: Vector3 = Vector3.ZERO          # offset velocity, character frame
	var prev_rel: Vector3 = Vector3.ZERO   # parent anchor, world axes, relative to the body
	var prev_vel: Vector3 = Vector3.ZERO
	var acc: Vector3 = Vector3.ZERO
	var primed: bool = false

var targets: Array = default_targets()

var _body: CharacterBody3D = null
var _frame: Node3D = null
var _skel: Skeleton3D = null
var _springs: Array[Spring] = []
var _prev_body_vel: Vector3 = Vector3.ZERO
var _have_body_vel: bool = false
var _was_on_floor: bool = true

# ------------------------------------------------------------------ setup
static func attach(body: CharacterBody3D, facing: Node3D, character_root: Node) -> Node:
	var sm = load("res://scripts/secondary_motion.gd").new()
	body.add_child(sm)
	sm.setup(body, facing, character_root)
	return sm

func _init() -> void:
	# Run after the AnimationPlayer so our offsets are written on top of the animated pose.
	process_priority = 100
	process_physics_priority = 100

func setup(body: CharacterBody3D, facing: Node3D, search_root: Node) -> bool:
	_body = body
	_frame = facing if facing != null else body
	_springs.clear()
	_skel = null
	if search_root == null:
		return false
	var found: Array = search_root.find_children("*", "Skeleton3D", true, false)
	if found.is_empty():
		push_warning("SecondaryMotion: no Skeleton3D found, jiggle disabled.")
		return false
	_skel = found[0] as Skeleton3D
	_bind_targets()
	return not _springs.is_empty()

func get_active_targets() -> PackedStringArray:
	var out := PackedStringArray()
	for s in _springs:
		out.append(s.id)
	return out

func _norm(s: String) -> String:
	var out: String = ""
	for ch in s.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9"):
			out += ch
	return out

func _bind_targets() -> void:
	var lookup: Dictionary = {}
	for i in range(_skel.get_bone_count()):
		lookup[_norm(_skel.get_bone_name(i))] = i
	var missing: PackedStringArray = PackedStringArray()
	for cfg in targets:
		var bone: int = -1
		var aliases: PackedStringArray = cfg["bones"]
		for alias in aliases:
			var key: String = _norm(alias)
			if lookup.has(key):
				bone = lookup[key]
				break
		if bone < 0 or _skel.get_bone_parent(bone) < 0:
			missing.append(str(cfg["id"]))
			continue
		var sp := Spring.new()
		sp.id = str(cfg["id"])
		sp.bone = bone
		sp.parent = _skel.get_bone_parent(bone)
		sp.rest_origin = _skel.get_bone_rest(bone).origin
		sp.k = float(cfg["stiffness"])
		sp.c = float(cfg["damping"])
		sp.max_offset = maxf(float(cfg["max_offset"]), 0.0005)
		sp.axis_scale = cfg["axis_scale"]
		_springs.append(sp)
	if not missing.is_empty():
		push_warning("SecondaryMotion: bones not found, skipped: %s" % ", ".join(missing))

func reset() -> void:
	for s in _springs:
		s.x = Vector3.ZERO
		s.v = Vector3.ZERO
		s.acc = Vector3.ZERO
		s.prev_vel = Vector3.ZERO
		s.primed = false
	_have_body_vel = false

func _release_bones() -> void:
	if _skel == null or not is_instance_valid(_skel):
		return
	for s in _springs:
		_skel.set_bone_pose_position(s.bone, s.rest_origin)
		s.x = Vector3.ZERO
		s.v = Vector3.ZERO

## Manual hit / bump: world-space velocity change in m/s (same meaning as a body velocity change).
func add_impulse(world_dv: Vector3) -> void:
	_apply_kick(world_dv, 1.0)

# ------------------------------------------------------------------ body velocity -> impulses
func _frame_basis() -> Basis:
	return _frame.global_transform.basis.orthonormalized()

func _apply_kick(world_dv: Vector3, mult: float) -> void:
	if _springs.is_empty() or _frame == null:
		return
	var local_dv: Vector3 = _frame_basis().inverse() * (-world_dv)
	local_dv *= impulse_gain * mult
	local_dv = local_dv.limit_length(MAX_KICK)
	for s in _springs:
		s.v += local_dv * s.axis_scale

func _physics_process(_delta: float) -> void:
	if _body == null or _springs.is_empty() or not enabled:
		return
	var vel: Vector3 = _body.velocity
	var on_floor: bool = _body.is_on_floor()
	if _have_body_vel:
		var dv: Vector3 = vel - _prev_body_vel
		var mult: float = 1.0
		if on_floor and not _was_on_floor and _prev_body_vel.y < -LANDING_MIN_SPEED:
			mult = landing_boost
		if dv.length_squared() > 0.0004:
			_apply_kick(dv, mult)
	_prev_body_vel = vel
	_have_body_vel = true
	_was_on_floor = on_floor

# ------------------------------------------------------------------ spring solver
func _speed_scale() -> float:
	var planar: float = Vector2(_body.velocity.x, _body.velocity.z).length()
	return lerpf(1.0, run_boost, smoothstep(0.5, 2.2, planar))

func _process(delta: float) -> void:
	if not enabled or _springs.is_empty() or _skel == null or not is_instance_valid(_skel) or _body == null:
		return
	if intensity <= 0.001:
		_release_bones()
		return
	var dt: float = clampf(delta, 0.0001, 0.05)
	var fb: Basis = _frame_basis()
	var fb_inv: Basis = fb.inverse()
	var sk_xf: Transform3D = _skel.global_transform
	var body_pos: Vector3 = _body.global_position
	var gain: float = anim_gain * _speed_scale()
	var smooth: float = 1.0 - exp(-dt * ACCEL_SMOOTH_HZ)
	var steps: int = clampi(int(ceil(dt / MAX_SUBSTEP)), 1, 6)
	var h: float = dt / float(steps)

	for s in _springs:
		var parent_pose: Transform3D = _skel.get_bone_global_pose(s.parent)
		var rel: Vector3 = sk_xf * (parent_pose * s.rest_origin) - body_pos
		if not s.primed:
			s.prev_rel = rel
			s.prev_vel = Vector3.ZERO
			s.acc = Vector3.ZERO
			s.primed = true
		else:
			var vel: Vector3 = (rel - s.prev_rel) / dt
			var a_raw: Vector3 = (vel - s.prev_vel) / dt
			s.prev_rel = rel
			s.prev_vel = vel
			s.acc = s.acc.lerp(a_raw, smooth)

		# inertial drive: the mass lags behind the accelerating anchor
		var a_world: Vector3 = s.acc.limit_length(max_accel)
		var drive: Vector3 = -(fb_inv * a_world) * gain * s.axis_scale
		for i in range(steps):
			var acc: Vector3 = drive - s.k * s.x - s.c * s.v
			s.v += acc * h
			s.x += s.v * h

		# safety net
		if not s.x.is_finite() or not s.v.is_finite():
			s.x = Vector3.ZERO
			s.v = Vector3.ZERO
		var hard: float = s.max_offset * 3.0
		if s.x.length() > hard:
			s.x = s.x.limit_length(hard)
			s.v *= 0.5

		# soft clamp (smoothly saturates at max_offset), then scale by the user intensity
		var off: Vector3 = s.x
		var l: float = off.length()
		if l > 0.00001:
			off = off / l * s.max_offset * tanh(l / s.max_offset)
		off *= intensity

		# character frame -> parent bone local space
		var parent_basis: Basis = sk_xf.basis * parent_pose.basis
		var local_off: Vector3 = parent_basis.inverse() * (fb * off)
		_skel.set_bone_pose_position(s.bone, s.rest_origin + local_off)
