extends VehicleBody3D
# Drivable GTA-SA-style car (rear wheel drive, soft bouncy suspension, speed-sensitive steering,
# handbrake drift). Model = res://assets/car.glb (converted from the GTA .dff/.txd).

const MODEL_PATH: String = "res://assets/car.glb"

# --- model measurements (metres, taken from the converted GTA model) ---
const WHEEL_RADIUS: float = 0.341
const REST_LEN: float = 0.20          # suspension rest length
const STATIC_COMP: float = 0.10       # how far the spring is squashed when parked
const WHEEL_POS: Array = [            # hub positions: FL, FR, RL, RR (model space, front = -Z)
	Vector3(-0.822, -0.268, -1.289),
	Vector3(0.822, -0.268, -1.289),
	Vector3(-0.849, -0.235, 1.462),
	Vector3(0.849, -0.235, 1.462),
]
const WHEEL_NODES: Array = ["WheelFL", "WheelFR", "WheelRL", "WheelRR"]
const GROUND_OFFSET: float = 0.61     # distance from car origin down to the tyre contact patch

# --- handling (tuned for a GTA SA feel) ---
const MASS: float = 1300.0
const ENGINE_FORCE: float = 5400.0    # per rear wheel
const TOP_SPEED: float = 50.0         # m/s  (~180 km/h)
const REVERSE_TOP: float = 14.0
const BRAKE_HARD: float = 38.0
const COAST_BRAKE: float = 1.2
const FRONT_GRIP: float = 3.6
const REAR_GRIP: float = 3.1
const HANDBRAKE_GRIP: float = 0.85

var ui = null                 # touch_ui.gd instance (set by main.gd)
var driven: bool = false
var steer_cur: float = 0.0
var wheels: Array = []
var body_mesh: MeshInstance3D = null
var flipped_time: float = 0.0
var spawn_xform: Transform3D = Transform3D.IDENTITY
var fwd_speed: float = 0.0    # signed speed along the nose, m/s

func _ready() -> void:
	mass = MASS
	can_sleep = false
	linear_damp = 0.04
	angular_damp = 0.9
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0.0, -0.32, 0.0)

	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.0, 0.78, 4.9)
	col.shape = box
	col.position = Vector3(0.0, 0.13, 0.0)
	add_child(col)

	var scene: PackedScene = load(MODEL_PATH)
	var inst: Node = scene.instantiate()

	# wheels: the 4 wheel meshes from the model become children of real VehicleWheel3D nodes
	for i in range(4):
		var src: Node3D = inst.find_child(WHEEL_NODES[i], true, false) as Node3D
		var w := VehicleWheel3D.new()
		var hp: Vector3 = WHEEL_POS[i]
		w.position = Vector3(hp.x, hp.y + (REST_LEN - STATIC_COMP), hp.z)
		w.wheel_radius = WHEEL_RADIUS
		w.wheel_rest_length = REST_LEN
		w.suspension_travel = 0.28
		w.suspension_stiffness = 26.0
		w.suspension_max_force = 16000.0
		w.damping_compression = 0.38
		w.damping_relaxation = 0.52
		w.wheel_roll_influence = 0.22
		w.wheel_friction_slip = FRONT_GRIP if i < 2 else REAR_GRIP
		w.use_as_steering = i < 2
		w.use_as_traction = i >= 2
		add_child(w)
		if src != null:
			src.get_parent().remove_child(src)
			src.position = Vector3.ZERO
			w.add_child(src)
		wheels.append(w)

	add_child(inst)
	body_mesh = inst.find_child("Body", true, false) as MeshInstance3D
	set_paint(Color(0.78, 0.06, 0.06))
	spawn_xform = global_transform

func set_paint(c: Color) -> void:
	# recolours the GTA "primary colour" material (named Paint inside the glb)
	if body_mesh == null or body_mesh.mesh == null:
		return
	for s in range(body_mesh.mesh.get_surface_count()):
		var m: Material = body_mesh.mesh.surface_get_material(s)
		if m != null and m.resource_name == "Paint" and m is StandardMaterial3D:
			var d: StandardMaterial3D = (m as StandardMaterial3D).duplicate()
			d.albedo_color = c
			body_mesh.set_surface_override_material(s, d)

func _held(btn: String) -> bool:
	return ui != null and ui.is_held(btn)

func _read_input() -> Dictionary:
	var left: bool = _held("left") or Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A)
	var right: bool = _held("right") or Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)
	var gas: bool = _held("gas") or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)
	var rev: bool = _held("brake") or Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S)
	var hb: bool = _held("hb") or Input.is_key_pressed(KEY_SPACE)
	return {"steer": (1.0 if left else 0.0) - (1.0 if right else 0.0), "gas": gas, "rev": rev, "hb": hb}

func _physics_process(delta: float) -> void:
	var basis_fwd: Vector3 = -global_transform.basis.z
	fwd_speed = linear_velocity.dot(basis_fwd)
	var speed: float = linear_velocity.length()

	var steer_in: float = 0.0
	var gas: bool = false
	var rev: bool = false
	var hb: bool = false
	if driven:
		var inp: Dictionary = _read_input()
		steer_in = inp["steer"]
		gas = inp["gas"]
		rev = inp["rev"]
		hb = inp["hb"]
	else:
		hb = true   # parked: handbrake on

	# ---- engine / brakes ----
	var eng: float = 0.0
	var brk: float = 0.0
	if gas and not rev:
		if fwd_speed < -1.5:
			brk = BRAKE_HARD
		else:
			var f: float = clampf(1.0 - pow(maxf(fwd_speed, 0.0) / TOP_SPEED, 2.0), 0.0, 1.0)
			eng = ENGINE_FORCE * f
	elif rev and not gas:
		if fwd_speed > 1.5:
			brk = BRAKE_HARD
		else:
			var fr: float = clampf(1.0 - (-fwd_speed) / REVERSE_TOP, 0.0, 1.0)
			eng = -ENGINE_FORCE * 0.55 * fr
	else:
		brk = COAST_BRAKE
	if not driven:
		brk = 25.0
		eng = 0.0

	# ---- handbrake: rear wheels lose grip -> GTA style slide ----
	var rear_grip: float = REAR_GRIP
	if hb and driven:
		rear_grip = HANDBRAKE_GRIP
		eng *= 0.35
		brk = maxf(brk, 6.0)
	elif eng > 0.0 and absf(steer_cur) > 0.12:
		# power-oversteer when flooring it in a corner
		rear_grip = REAR_GRIP - 0.7 * clampf(absf(steer_cur) / 0.4, 0.0, 1.0) * clampf(speed / 14.0, 0.0, 1.0)
	for i in range(2, 4):
		(wheels[i] as VehicleWheel3D).wheel_friction_slip = lerpf((wheels[i] as VehicleWheel3D).wheel_friction_slip, rear_grip, 1.0 - exp(-12.0 * delta))

	engine_force = eng
	brake = brk

	# ---- steering: wide at parking speed, narrow at speed, smooth like SA ----
	var sp: float = absf(fwd_speed)
	var max_steer: float = 0.62 / (1.0 + sp * 0.085)
	var target: float = steer_in * max_steer
	var rate: float = 5.5 if absf(steer_in) > 0.01 else 9.0
	steer_cur = move_toward(steer_cur, target, rate * max_steer * delta * 2.0)
	steering = steer_cur

	# ---- a little downforce keeps it planted at speed ----
	if speed > 5.0:
		apply_central_force(Vector3.DOWN * speed * speed * 1.1)

	# ---- flipped over for a while -> put it back on its wheels ----
	if global_transform.basis.y.y < 0.25 and speed < 3.0:
		flipped_time += delta
		if flipped_time > 2.5:
			recover()
	else:
		flipped_time = 0.0

	if global_position.y < -30.0:
		respawn()

func recover() -> void:
	flipped_time = 0.0
	var yaw: float = global_rotation.y
	global_transform = Transform3D(Basis(Vector3.UP, yaw), global_position + Vector3(0.0, 1.2, 0.0))
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO

func respawn() -> void:
	global_transform = spawn_xform
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
