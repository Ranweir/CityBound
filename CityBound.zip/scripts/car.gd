extends CharacterBody3D
# Ford F-150 Raptor with simple arcade driving (no suspension / tyre physics yet).
# Joystick up/down = throttle/brake-reverse, left/right = steer, JUMP button = handbrake.

const CarMeta = preload("res://scripts/car_meta.gd")

@export var max_speed: float = 24.0         # m/s (~86 km/h)
@export var reverse_speed: float = 7.0
@export var accel: float = 9.0
@export var brake_decel: float = 22.0
@export var coast_decel: float = 3.0
@export var max_steer_low: float = 0.58     # rad of front-wheel angle at standstill
@export var max_steer_high: float = 0.16    # rad at top speed
@export var gravity: float = 22.0
@export var full_quality: bool = true                         # false = lighter model (~42k triangles)
@export var paint_color: Color = Color(0.88, 0.89, 0.92)      # body colour

var ui = null                 # touch_ui.gd instance (set by main.gd)
var driven: bool = false      # true while the player sits in the car
var heading: float = 0.0      # yaw in radians (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0
var visual: Node3D = null
var wheel_pivots: Array = []
var wheel_spinners: Array = []
var wheel_spin: float = 0.0

func _ready() -> void:
	floor_max_angle = deg_to_rad(40.0)
	floor_snap_length = 0.7
	floor_stop_on_slope = false
	floor_constant_speed = true
	heading = rotation.y
	_build_collision()
	_build_visual()

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# convex hull: low belly between the wheels, wide at bumper height, narrow cab on top
	var pts := PackedVector3Array([
		Vector3(-1.05, 0.0, -2.2), Vector3(1.05, 0.0, -2.2), Vector3(-1.05, 0.0, 2.3), Vector3(1.05, 0.0, 2.3),
		Vector3(-1.15, 0.45, -3.0), Vector3(1.15, 0.45, -3.0), Vector3(-1.15, 0.45, 3.25), Vector3(1.15, 0.45, 3.25),
		Vector3(-1.1, 1.55, -3.0), Vector3(1.1, 1.55, -3.0), Vector3(-1.1, 1.55, 3.25), Vector3(1.1, 1.55, 3.25),
		Vector3(-1.0, 2.4, -0.8), Vector3(1.0, 2.4, -0.8), Vector3(-1.0, 2.4, 0.9), Vector3(1.0, 2.4, 0.9),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _find_mesh(root: Node, prefix: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name).begins_with(prefix):
			return (c as MeshInstance3D).mesh
	return null

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/car/f150.glb" if full_quality else "res://assets/car/f150_lite.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var wheel_mesh: Mesh = _find_mesh(inst, "Wheel")
	inst.free()
	_style_mesh(body_mesh)
	_style_mesh(wheel_mesh)
	if body_mesh == null or wheel_mesh == null:
		push_error("f150.glb: Body/Wheel mesh not found")
		return
	var body := MeshInstance3D.new()
	body.name = "Body"
	body.mesh = body_mesh
	visual.add_child(body)
	for wp in CarMeta.WHEELS:
		var pos: Vector3 = wp
		var pivot := Node3D.new()
		pivot.position = pos
		visual.add_child(pivot)
		var spinner := Node3D.new()
		pivot.add_child(spinner)
		var wm := MeshInstance3D.new()
		wm.mesh = wheel_mesh
		if pos.x < 0.0:
			wm.rotation.y = PI      # the wheel mesh is modelled for the right side
		spinner.add_child(wm)
		wheel_pivots.append(pivot)
		wheel_spinners.append(spinner)

func _style_mesh(mesh: Mesh) -> void:
	# glossy clear-coated paint; tyres are pure rubber (no sky reflection)
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		if m.resource_name == "Paint":
			m.albedo_color = paint_color
			m.metallic = 0.55
			m.roughness = 0.3
			m.clearcoat_enabled = true
			m.clearcoat = 0.8
			m.clearcoat_roughness = 0.08
		elif m.resource_name == "Tyre":
			m.metallic = 0.0
			m.roughness = 1.0
			m.metallic_specular = 0.0

func _read_input() -> Vector3:
	# returns (throttle, steer, handbrake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var hb: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			hb = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		hb = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), hb)

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var throttle: float = inp.x
	var handbrake: bool = inp.z > 0.5

	# ---- speed
	if handbrake:
		speed = move_toward(speed, 0.0, brake_decel * 1.3 * delta)
	elif throttle > 0.05:
		if speed < -0.5:
			speed += brake_decel * delta
		else:
			speed += accel * throttle * (1.0 - clampf(speed / max_speed, 0.0, 1.0)) * delta + 0.5 * delta
	elif throttle < -0.05:
		if speed > 0.5:
			speed -= brake_decel * (-throttle) * delta
		else:
			speed -= accel * 0.6 * (-throttle) * delta
	else:
		speed = move_toward(speed, 0.0, coast_decel * delta)
	speed = clampf(speed, -reverse_speed, max_speed)

	# ---- steering (bicycle model)
	var steer_limit: float = lerpf(max_steer_low, max_steer_high, clampf(absf(speed) / max_speed, 0.0, 1.0))
	var steer_target: float = -inp.y * steer_limit      # positive angle = turn left
	steer_now = move_toward(steer_now, steer_target, 2.6 * delta)
	heading += speed / CarMeta.WHEELBASE * tan(steer_now) * delta
	rotation.y = heading

	# ---- movement (follows the ground slope)
	var fwd: Vector3 = forward_vector()
	if is_on_floor():
		var n: Vector3 = get_floor_normal()
		var fg: Vector3 = (fwd - n * fwd.dot(n)).normalized()
		velocity = fg * speed
	else:
		velocity.x = fwd.x * speed
		velocity.z = fwd.z * speed
		velocity.y -= gravity * delta
	move_and_slide()

	# speed after collisions (walls / trees slow the car down)
	if is_on_floor():
		var n2: Vector3 = get_floor_normal()
		var fg2: Vector3 = (fwd - n2 * fwd.dot(n2)).normalized()
		speed = velocity.dot(fg2)
	else:
		speed = velocity.dot(fwd)

	_update_visual(delta)

func _update_visual(delta: float) -> void:
	if visual == null:
		return
	# tilt the body to the ground (pitch / roll), wheels roll and steer
	var up: Vector3 = Vector3.UP
	if is_on_floor():
		up = get_floor_normal()
	var fwd: Vector3 = forward_vector()
	var right: Vector3 = fwd.cross(up).normalized()
	var fwd_t: Vector3 = up.cross(right).normalized()
	var target := Basis(right, up, -fwd_t)
	var cur: Quaternion = visual.global_basis.get_rotation_quaternion()
	var tq: Quaternion = target.get_rotation_quaternion()
	visual.global_basis = Basis(cur.slerp(tq, 1.0 - exp(-7.0 * delta)))
	wheel_spin = wrapf(wheel_spin - speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	for i in range(wheel_spinners.size()):
		(wheel_spinners[i] as Node3D).rotation.x = wheel_spin
		if i < 2:
			(wheel_pivots[i] as Node3D).rotation.y = steer_now
