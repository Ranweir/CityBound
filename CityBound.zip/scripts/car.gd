extends CharacterBody3D
# Ford F-150 Raptor: grip-based driving (bicycle tyre model: slip angles, load transfer, drifting) +
# 4-wheel spring/damper suspension (separate bump / rebound damping, anti-roll bars, progressive bump stops)
# on the heightfield terrain.
# Joystick up/down = throttle/brake-reverse, left/right = steer, JUMP button = handbrake (rear wheels lock -> drift).

const CarMeta = preload("res://scripts/car_meta.gd")

@export var max_speed: float = 34.0         # m/s (~122 km/h)
@export var reverse_speed: float = 7.0
@export var accel: float = 15.0
@export var brake_decel: float = 26.0
@export var coast_decel: float = 3.0
@export var max_steer_low: float = 0.58     # rad of front-wheel angle at standstill
@export var max_steer_high: float = 0.16    # rad at top speed
@export var gravity: float = 22.0
@export var full_quality: bool = true                         # false = lighter model (~42k triangles)
@export var paint_color: Color = Color(0.88, 0.89, 0.92)      # body colour

const GLASS_MATS := ["pered_steklo", "lob_steklo", "zad_steklo", "LensFront", "fara_pered", "fara_zad"]
const SELF_LAYER: int = 1 << 19     # car meshes live on layer 20 so the reflection probe does not capture the car itself

@export var use_reflection_probe: bool = false     # live reflections cost a lot on phones; sky reflections stay on
@export var spring_damping: float = 2.6            # per wheel; lower = bouncier, higher = stiffer (bump = 0.85x, rebound = 1.6x)
@export var arb_front: float = 7.0                 # anti-roll bar stiffness (force per m of left/right compression difference)
@export var arb_rear: float = 4.0

# ---- handling (tyre model)
@export var grip_accel: float = 16.0               # lateral / braking acceleration at grip = 1 (m/s^2)
@export var cg_front_ratio: float = 0.46           # CG distance from front axle / wheelbase (<0.5 = front-heavy pickup)
@export var cg_height: float = 1.0                 # m, drives weight transfer under braking / acceleration
@export var yaw_inertia: float = 2.6               # m^2 (mass = 1); higher = lazier rotation
@export var tire_stiff: float = 9.0                # cornering stiffness; higher = snappier, less forgiving
@export var rear_grip_bias: float = 1.06           # >1 = stable (understeer), <1 = tail-happy
@export var handbrake_rear_grip: float = 0.28      # rear grip left while the handbrake is held
@export var susp_ext_rest: float = 0.25            # suspension extension when parked (m)
@export var susp_ext_max: float = 0.50             # full droop (m)

const BUMP_K: float = 500.0                        # bump-stop stiffness
const INERTIA_PITCH: float = 3.0
const INERTIA_ROLL: float = 0.8

var world = null              # map_builder.gd instance (set by main.gd) - used for terrain height
var probe: ReflectionProbe = null
var probe_timer: float = 0.0
var ride_y: float = 0.0       # body height (world Y of the body origin)
var vy: float = 0.0
var pitch: float = 0.0        # + = nose up
var roll: float = 0.0         # + = right side up
var pitch_vel: float = 0.0
var roll_vel: float = 0.0
var ext := PackedFloat32Array([0.25, 0.25, 0.25, 0.25])   # current suspension extension per wheel
var prev_speed: float = 0.0
var long_acc: float = 0.0
var water_pitch: float = 0.0  # extra body tilt while wading (set by main.gd): bow wave + floating sway
var water_roll: float = 0.0
var ui = null                # touch_ui.gd instance (set by main.gd)
var enter_range: float = 7.0  # how close the player must be to get in
var driven: bool = false      # true while the player sits in the car
var heading: float = 0.0      # yaw in radians (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0
var steer_in: float = 0.0     # smoothed steering input (-1..1)
var grip: float = 1.0         # surface grip 0.15..1 (set by main.gd from the terrain under the car)
var lat_speed: float = 0.0    # sideways velocity in the car frame, + = sliding left (m/s)
var yaw_rate: float = 0.0     # rad/s, + = turning left
var lat_acc_f: float = 0.0    # filtered lateral acceleration (feeds body roll)
var slip_extra: float = 0.0   # wheelspin amount 0..1 (visual)
var wheel_spin_rear: float = 0.0
var visual: Node3D = null
var wheel_pivots: Array = []
var wheel_spinners: Array = []
var wheel_spin: float = 0.0

func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING   # no floor logic: height comes from the suspension
	collision_mask = 2        # only props / boundary (layer 2). The terrain is handled by the wheels.
	heading = rotation.y
	ride_y = global_position.y
	for i in range(4):
		ext[i] = susp_ext_rest
	_build_collision()
	_build_visual()
	if use_reflection_probe:
		_build_reflection_probe()

func _ground(x: float, z: float) -> float:
	if world != null:
		return world.get_height(x, z)
	return 0.0

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# convex hull: low belly between the wheels, wide at bumper height, narrow cab on top
	var pts := PackedVector3Array([
		Vector3(-1.05, 0.40, -2.2), Vector3(1.05, 0.40, -2.2), Vector3(-1.05, 0.40, 2.3), Vector3(1.05, 0.40, 2.3),
		Vector3(-1.15, 0.55, -3.0), Vector3(1.15, 0.55, -3.0), Vector3(-1.15, 0.55, 3.25), Vector3(1.15, 0.55, 3.25),
		Vector3(-1.1, 1.55, -3.0), Vector3(1.1, 1.55, -3.0), Vector3(-1.1, 1.55, 3.25), Vector3(1.1, 1.55, 3.25),
		Vector3(-1.0, 2.4, -0.8), Vector3(1.0, 2.4, -0.8), Vector3(-1.0, 2.4, 0.9), Vector3(1.0, 2.4, 0.9),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _build_reflection_probe() -> void:
	# live reflections of terrain, trees and sky on the paint and glass
	probe = ReflectionProbe.new()
	probe.name = "ReflectionProbe"
	probe.position = Vector3(0.0, 1.3, 0.0)
	probe.size = Vector3(40.0, 20.0, 40.0)
	probe.origin_offset = Vector3.ZERO
	probe.box_projection = false
	probe.interior = false
	probe.max_distance = 120.0
	probe.intensity = 1.0
	probe.cull_mask = 0xFFFFF & ~SELF_LAYER
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	add_child(probe)

func _find_mesh(root: Node, prefix: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name).begins_with(prefix):
			return (c as MeshInstance3D).mesh
	return null

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/car/f150.glb" if full_quality else "res://assets/car/f150_lite.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var wheel_mesh: Mesh = _find_mesh(inst, "Wheel")
	inst.free()
	_style_mesh(body_mesh)
	_style_mesh(wheel_mesh)
	if body_mesh == null or wheel_mesh == null:
		push_error("f150.glb: Body/Wheel mesh not found")
		return
	var body := MeshInstance3D.new()
	body.name = "Body"
	body.mesh = body_mesh
	body.layers = SELF_LAYER
	visual.add_child(body)
	for wp in CarMeta.WHEELS:
		var pos: Vector3 = wp
		var pivot := Node3D.new()
		pivot.position = pos
		visual.add_child(pivot)
		var spinner := Node3D.new()
		pivot.add_child(spinner)
		var wm := MeshInstance3D.new()
		wm.mesh = wheel_mesh
		wm.layers = SELF_LAYER
		if pos.x < 0.0:
			wm.rotation.y = PI      # the wheel mesh is modelled for the right side
		spinner.add_child(wm)
		wheel_pivots.append(pivot)
		wheel_spinners.append(spinner)

func _style_mesh(mesh: Mesh) -> void:
	# glossy clear-coated paint; tyres are pure rubber (no sky reflection)
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		if m.resource_name == "Paint":
			m.albedo_color = paint_color
			m.metallic = 0.65
			m.roughness = 0.14
			m.metallic_specular = 0.8
			m.clearcoat_enabled = true
			m.clearcoat = 1.0
			m.clearcoat_roughness = 0.02
			m.rim_enabled = true          # fake fresnel sheen on the paint edges
			m.rim = 0.25
			m.rim_tint = 0.6
		elif m.resource_name in GLASS_MATS:
			m.roughness = 0.02
			m.metallic = 0.3
			m.metallic_specular = 1.0
		elif m.resource_name == "Tyre":
			m.metallic = 0.0
			m.roughness = 1.0
			m.metallic_specular = 0.0

func _read_input() -> Vector3:
	# returns (throttle, steer, handbrake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var hb: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			hb = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		hb = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), hb)

# Pacejka-lite lateral tyre force: rises with slip angle, peaks around 11 deg, then falls to ~70% (= slide).
func _tire(slip_v: float, v_ref: float, cap: float) -> float:
	var al: float = atan2(slip_v, maxf(v_ref, 3.0))
	return -cap * sin(1.5 * atan(tire_stiff * al))

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var throttle: float = inp.x
	var parked: bool = not driven                  # nobody inside: parking brake holds the car
	var handbrake: bool = inp.z > 0.5 and driven
	var mu: float = clampf(grip, 0.15, 1.0)
	var wb: float = CarMeta.WHEELBASE
	var a_cg: float = wb * cg_front_ratio          # CG -> front axle
	var b_cg: float = wb - a_cg                    # CG -> rear axle
	var grip_cap: float = mu * grip_accel          # what all four tyres together can deliver (m/s^2)
	var v_abs: float = absf(speed)

	# ---- longitudinal: engine limited by rear-axle traction (RWD, weight shifts back when accelerating)
	var n_rear: float = clampf(a_cg / wb + cg_height / wb * long_acc / gravity, 0.25, 0.75)
	var drive_cap: float = grip_cap * clampf(n_rear * 2.0, 0.6, 1.4)
	var wheelspin: float = 0.0
	if parked:
		speed = move_toward(speed, 0.0, brake_decel * 1.3 * delta)
	elif handbrake:
		speed = move_toward(speed, 0.0, minf(brake_decel, grip_cap * 1.1) * delta)
	elif throttle > 0.05:
		if speed < -0.5:
			speed += minf(brake_decel, grip_cap * 1.5) * delta
		else:
			# strong pull until close to top speed (quadratic fall-off instead of linear)
			var ratio: float = clampf(speed / max_speed, 0.0, 1.0)
			var a_eng: float = accel * throttle * (1.0 - ratio * ratio) + 0.5
			speed += minf(a_eng, drive_cap) * delta
			wheelspin = clampf((a_eng - drive_cap) / maxf(accel, 1.0), 0.0, 1.0)
	elif throttle < -0.05:
		if speed > 0.5:
			speed -= minf(brake_decel * (-throttle), grip_cap * 1.5) * delta       # braking is grip-limited too
		else:
			speed -= minf(accel * 0.6 * (-throttle), drive_cap) * delta
	else:
		speed = move_toward(speed, 0.0, coast_decel * delta)
	slip_extra = lerpf(slip_extra, wheelspin, 1.0 - exp(-8.0 * delta))

	# ---- terrain slope: gravity along the hill, and cliffs block the way
	var fwd: Vector3 = forward_vector()
	var pos: Vector3 = global_position
	var gc: float = _ground(pos.x, pos.z)
	var f_pt: Vector3 = pos + fwd * 1.9
	var r_pt: Vector3 = pos - fwd * 1.9
	var slope_body: float = (_ground(f_pt.x, f_pt.z) - _ground(r_pt.x, r_pt.z)) / 3.8     # + = nose up
	if absf(speed) > 0.8 or absf(throttle) > 0.05:
		speed -= gravity * 0.4 * slope_body / sqrt(1.0 + slope_body * slope_body) * delta
	var dirn: float = 1.0 if speed >= 0.0 else -1.0
	var lead: Vector3 = pos + fwd * dirn * 3.0
	if (_ground(lead.x, lead.z) - gc) / 3.0 > 1.2:                    # steeper than ~50 deg ahead
		speed = move_toward(speed, 0.0, 70.0 * delta)
	speed = clampf(speed, -reverse_speed, max_speed)
	v_abs = absf(speed)

	# ---- steering: smoothed input, angle limited to what the tyres can hold (a little over = understeer slide)
	var in_rate: float = 6.0 if absf(inp.y) > 0.01 else 9.0
	steer_in = move_toward(steer_in, inp.y, in_rate * delta)
	var lat_cap: float = grip_cap * 0.95
	var grip_angle: float = atan(wb * lat_cap / maxf(v_abs * v_abs, 1.0))
	var steer_limit: float = clampf(grip_angle * 1.4, max_steer_high * 0.45, max_steer_low)
	var steer_target: float = -steer_in * steer_limit      # positive angle = turn left
	var steer_rate: float = lerpf(2.8, 1.6, clampf(v_abs / max_speed, 0.0, 1.0))
	if absf(steer_target) < absf(steer_now):
		steer_rate *= 1.6                                   # self-centering is quicker than turning in
	steer_now = move_toward(steer_now, steer_target, steer_rate * delta)

	# ---- handling: front / rear axle slip angles -> lateral tyre forces -> yaw + sideways slide
	var n_front: float = clampf(b_cg / wb - cg_height / wb * long_acc / gravity, 0.25, 0.8)
	var n_rear2: float = 1.0 - n_front
	var rear_mu: float = mu * rear_grip_bias
	if handbrake and v_abs > 1.0:
		rear_mu = mu * handbrake_rear_grip
	if parked:
		rear_mu = maxf(rear_mu, 1.0)                 # parked: tyres hold, no sliding
	var long_use: float = clampf(absf(long_acc) / maxf(grip_cap, 1.0), 0.0, 0.95)      # friction circle: accelerating eats cornering grip
	var cap_f: float = mu * grip_accel * n_front * 1.0
	var cap_r: float = rear_mu * grip_accel * n_rear2 * sqrt(1.0 - long_use * long_use * 0.6)
	var tan_st: float = tan(steer_now)
	var sub: int = 2
	var dt: float = delta / float(sub)
	var lat_force: float = 0.0
	for _i in range(sub):
		var s_f: float = (lat_speed + a_cg * yaw_rate) - speed * tan_st
		var s_r: float = lat_speed - b_cg * yaw_rate
		var ff: float = _tire(s_f, v_abs, cap_f)
		var fr: float = _tire(s_r, v_abs, cap_r)
		lat_force = ff + fr
		lat_speed += (lat_force - speed * yaw_rate) * dt
		yaw_rate += (a_cg * ff - b_cg * fr) / yaw_inertia * dt
		yaw_rate *= exp(-0.45 * dt)
		speed += yaw_rate * lat_speed * dt                                # frame rotation coupling
	# sliding scrubs speed off
	speed = move_toward(speed, 0.0, absf(lat_speed) * 0.22 * delta)
	# crawling speed: tyre slip angles are meaningless -> follow the simple bicycle geometry
	var kin: float = 1.0 - smoothstep(1.5, 5.0, v_abs)
	yaw_rate = lerpf(yaw_rate, speed / wb * tan_st, kin)
	lat_speed = lerpf(lat_speed, 0.0, kin * clampf(10.0 * delta, 0.0, 1.0))
	# cross-slope: in loose surfaces the car creeps down a camber
	if v_abs > 2.0 and mu < 0.7:
		var left_v: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))
		var cross: float = (_ground(pos.x + left_v.x, pos.z + left_v.z) - _ground(pos.x - left_v.x, pos.z - left_v.z)) * 0.5
		lat_speed -= gravity * 0.25 * (0.7 - mu) * cross * delta
	if absf(yaw_rate) > 3.0:
		yaw_rate = clampf(yaw_rate, -3.0, 3.0)
	lat_speed = clampf(lat_speed, -18.0, 18.0)
	lat_acc_f = lerpf(lat_acc_f, lat_force, 1.0 - exp(-9.0 * delta))

	heading += yaw_rate * delta
	rotation.y = heading
	fwd = forward_vector()
	var left: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))

	# ---- horizontal movement only (props / boundary collide, height is done by the suspension)
	var cs: float = 1.0 / sqrt(1.0 + slope_body * slope_body)           # slope speed -> ground-plane speed
	velocity = fwd * (speed * cs) + left * lat_speed
	velocity.y = 0.0
	global_position.y = ride_y
	move_and_slide()
	global_position.y = ride_y
	speed = velocity.dot(fwd) / maxf(cs, 0.3)                           # trees / rocks slow the car down
	lat_speed = velocity.dot(left)

	# ---- body motion from acceleration / cornering
	var la_raw: float = clampf((speed - prev_speed) / maxf(delta, 0.0001), -20.0, 20.0)
	long_acc = lerpf(long_acc, la_raw, 0.15)
	prev_speed = speed
	_suspension(delta, long_acc * 1.2, -lat_acc_f * 0.7)

	_update_visual(delta, handbrake)

	# optional live reflection probe (off by default)
	if probe != null:
		probe_timer += delta
		if probe_timer > 1.5 and (absf(speed) > 1.0 or probe_timer > 4.0):
			probe_timer = 0.0
			probe.update_mode = ReflectionProbe.UPDATE_ALWAYS
			await get_tree().process_frame
			probe.update_mode = ReflectionProbe.UPDATE_ONCE

# 4 springs: each wheel's attach point is compared with the terrain under the wheel (3 taps = the tyre rolls over small bumps).
func _suspension(delta: float, pitch_torque: float, roll_torque: float) -> void:
	var yaw_basis := Basis(Vector3.UP, heading)
	var body_basis: Basis = yaw_basis * Basis(Vector3.RIGHT, pitch) * Basis(Vector3.BACK, roll)
	var pos: Vector3 = global_position
	var k: float = gravity / (4.0 * maxf(susp_ext_max - susp_ext_rest, 0.05))   # static load = gravity
	var c_bump: float = spring_damping * 0.85          # compression damping (soft: swallows bumps)
	var c_reb: float = spring_damping * 1.6            # rebound damping (firm: stops the body bouncing)
	var fw: Vector3 = Vector3(-sin(heading), 0.0, -cos(heading))
	var fs := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])
	var comp := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])
	var touching := PackedByteArray([0, 0, 0, 0])
	var contacts: int = 0
	for i in range(4):
		var w: Vector3 = CarMeta.WHEELS[i]
		var a: Vector3 = pos + body_basis * Vector3(w.x, w.y + susp_ext_rest, w.z)
		var g0: float = _ground(a.x, a.z)
		var gf: float = _ground(a.x + fw.x * 0.28, a.z + fw.z * 0.28)
		var gb: float = _ground(a.x - fw.x * 0.28, a.z - fw.z * 0.28)
		var g: float = maxf(g0, 0.5 * (gf + gb))                  # tyre envelope: bridges holes, climbs bumps earlier
		var raw: float = a.y - CarMeta.WHEEL_RADIUS - g           # distance wheel-bottom to ground if fully compressed
		var e: float = clampf(raw, 0.0, susp_ext_max)
		var rate: float = clampf((e - ext[i]) / maxf(delta, 0.0001), -12.0, 12.0)
		var f: float = 0.0
		if raw < susp_ext_max:                                   # wheel touches the ground
			contacts += 1
			touching[i] = 1
			var c: float = c_reb if rate > 0.0 else c_bump
			f = k * (susp_ext_max - e) - c * rate
			var stop: float = maxf(0.07 - e, 0.0) / 0.07          # progressive bump stop in the last 7 cm
			f += stop * stop * 45.0
			if raw < 0.0:
				f += BUMP_K * (-raw) - 25.0 * minf(vy, 0.0)      # hard stop
			comp[i] = susp_ext_max - e
		ext[i] = e
		fs[i] = f
	# anti-roll bars: couple left / right wheel of each axle
	var d_front: float = (comp[0] - comp[1]) * arb_front
	var d_rear: float = (comp[2] - comp[3]) * arb_rear
	fs[0] += d_front
	fs[1] -= d_front
	fs[2] += d_rear
	fs[3] -= d_rear
	var fsum: float = 0.0
	var tp: float = pitch_torque
	var tr: float = roll_torque
	for i in range(4):
		var w2: Vector3 = CarMeta.WHEELS[i]
		var fi: float = maxf(fs[i], 0.0) if touching[i] == 1 else 0.0
		fsum += fi
		tp += -w2.z * fi
		tr += w2.x * fi
	vy += (fsum - gravity) * delta
	pitch_vel += tp / INERTIA_PITCH * delta
	roll_vel += tr / INERTIA_ROLL * delta
	var damp: float = exp(-(0.6 if contacts == 0 else 1.0) * delta)
	pitch_vel *= damp
	roll_vel *= damp
	pitch += pitch_vel * delta
	roll += roll_vel * delta
	if absf(pitch) > 1.0:
		pitch = clampf(pitch, -1.0, 1.0)
		pitch_vel = 0.0
	if absf(roll) > 0.9:
		roll = clampf(roll, -0.9, 0.9)
		roll_vel = 0.0
	ride_y += vy * delta
	var gc: float = _ground(pos.x, pos.z)
	if ride_y < gc - 0.6:                                        # safety: never fall through the map
		ride_y = gc + 0.2
		vy = 0.0
	global_position.y = ride_y

func _update_visual(delta: float, handbrake: bool = false) -> void:
	if visual == null:
		return
	visual.basis = Basis(Vector3.RIGHT, pitch + water_pitch) * Basis(Vector3.BACK, roll + water_roll)
	wheel_spin = wrapf(wheel_spin - speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	# rear wheels: spin faster under wheelspin, stop when the handbrake locks them
	var rear_speed: float = speed + signf(speed if absf(speed) > 0.5 else 1.0) * slip_extra * 9.0
	if handbrake and absf(speed) > 1.0:
		rear_speed = speed * 0.1
	wheel_spin_rear = wrapf(wheel_spin_rear - rear_speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	for i in range(wheel_spinners.size()):
		(wheel_spinners[i] as Node3D).rotation.x = wheel_spin if i < 2 else wheel_spin_rear
		var pv := wheel_pivots[i] as Node3D
		var w: Vector3 = CarMeta.WHEELS[i]
		pv.position.y = w.y + susp_ext_rest - ext[i]           # wheels follow the ground, body rides on springs
		if i < 2:
			pv.rotation.y = steer_now
