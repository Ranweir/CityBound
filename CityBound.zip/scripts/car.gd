extends CharacterBody3D
# Ford F-150 Raptor: arcade driving + 4-wheel spring/damper suspension (heave, pitch, roll) on the heightfield terrain.
# Joystick up/down = throttle/brake-reverse, left/right = steer, JUMP button = handbrake.

const CarMeta = preload("res://scripts/car_meta.gd")

@export var max_speed: float = 34.0         # m/s (~122 km/h)
@export var reverse_speed: float = 7.0
@export var accel: float = 15.0
@export var brake_decel: float = 26.0
@export var coast_decel: float = 3.0
@export var max_steer_low: float = 0.58     # rad of front-wheel angle at standstill
@export var max_steer_high: float = 0.16    # rad at top speed
@export var gravity: float = 22.0
@export var full_quality: bool = true                         # false = lighter model (~42k triangles)
@export var paint_color: Color = Color(0.88, 0.89, 0.92)      # body colour

const GLASS_MATS := ["pered_steklo", "lob_steklo", "zad_steklo", "LensFront", "fara_pered", "fara_zad"]
const SELF_LAYER: int = 1 << 19     # car meshes live on layer 20 so the reflection probe does not capture the car itself

@export var use_reflection_probe: bool = false     # live reflections cost a lot on phones; sky reflections stay on
@export var spring_damping: float = 2.6            # per wheel; lower = bouncier, higher = stiffer
@export var susp_ext_rest: float = 0.25            # suspension extension when parked (m)
@export var susp_ext_max: float = 0.50             # full droop (m)

const BUMP_K: float = 500.0                        # bump-stop stiffness
const INERTIA_PITCH: float = 3.0
const INERTIA_ROLL: float = 0.8

var world = null              # map_builder.gd instance (set by main.gd) - used for terrain height
var probe: ReflectionProbe = null
var probe_timer: float = 0.0
var ride_y: float = 0.0       # body height (world Y of the body origin)
var vy: float = 0.0
var pitch: float = 0.0        # + = nose up
var roll: float = 0.0         # + = right side up
var pitch_vel: float = 0.0
var roll_vel: float = 0.0
var ext := PackedFloat32Array([0.25, 0.25, 0.25, 0.25])   # current suspension extension per wheel
var prev_speed: float = 0.0
var long_acc: float = 0.0
var ui = null                 # touch_ui.gd instance (set by main.gd)
var enter_range: float = 7.0  # how close the player must be to get in
var driven: bool = false      # true while the player sits in the car
var heading: float = 0.0      # yaw in radians (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0
var visual: Node3D = null
var wheel_pivots: Array = []
var wheel_spinners: Array = []
var wheel_spin: float = 0.0

func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING   # no floor logic: height comes from the suspension
	collision_mask = 2        # only props / boundary (layer 2). The terrain is handled by the wheels.
	heading = rotation.y
	ride_y = global_position.y
	for i in range(4):
		ext[i] = susp_ext_rest
	_build_collision()
	_build_visual()
	if use_reflection_probe:
		_build_reflection_probe()

func _ground(x: float, z: float) -> float:
	if world != null:
		return world.get_height(x, z)
	return 0.0

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# convex hull: low belly between the wheels, wide at bumper height, narrow cab on top
	var pts := PackedVector3Array([
		Vector3(-1.05, 0.40, -2.2), Vector3(1.05, 0.40, -2.2), Vector3(-1.05, 0.40, 2.3), Vector3(1.05, 0.40, 2.3),
		Vector3(-1.15, 0.55, -3.0), Vector3(1.15, 0.55, -3.0), Vector3(-1.15, 0.55, 3.25), Vector3(1.15, 0.55, 3.25),
		Vector3(-1.1, 1.55, -3.0), Vector3(1.1, 1.55, -3.0), Vector3(-1.1, 1.55, 3.25), Vector3(1.1, 1.55, 3.25),
		Vector3(-1.0, 2.4, -0.8), Vector3(1.0, 2.4, -0.8), Vector3(-1.0, 2.4, 0.9), Vector3(1.0, 2.4, 0.9),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _build_reflection_probe() -> void:
	# live reflections of terrain, trees and sky on the paint and glass
	probe = ReflectionProbe.new()
	probe.name = "ReflectionProbe"
	probe.position = Vector3(0.0, 1.3, 0.0)
	probe.size = Vector3(40.0, 20.0, 40.0)
	probe.origin_offset = Vector3.ZERO
	probe.box_projection = false
	probe.interior = false
	probe.max_distance = 120.0
	probe.intensity = 1.0
	probe.cull_mask = 0xFFFFF & ~SELF_LAYER
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	add_child(probe)

func _find_mesh(root: Node, prefix: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name).begins_with(prefix):
			return (c as MeshInstance3D).mesh
	return null

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/car/f150.glb" if full_quality else "res://assets/car/f150_lite.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var wheel_mesh: Mesh = _find_mesh(inst, "Wheel")
	inst.free()
	_style_mesh(body_mesh)
	_style_mesh(wheel_mesh)
	if body_mesh == null or wheel_mesh == null:
		push_error("f150.glb: Body/Wheel mesh not found")
		return
	var body := MeshInstance3D.new()
	body.name = "Body"
	body.mesh = body_mesh
	body.layers = SELF_LAYER
	visual.add_child(body)
	for wp in CarMeta.WHEELS:
		var pos: Vector3 = wp
		var pivot := Node3D.new()
		pivot.position = pos
		visual.add_child(pivot)
		var spinner := Node3D.new()
		pivot.add_child(spinner)
		var wm := MeshInstance3D.new()
		wm.mesh = wheel_mesh
		wm.layers = SELF_LAYER
		if pos.x < 0.0:
			wm.rotation.y = PI      # the wheel mesh is modelled for the right side
		spinner.add_child(wm)
		wheel_pivots.append(pivot)
		wheel_spinners.append(spinner)

func _style_mesh(mesh: Mesh) -> void:
	# glossy clear-coated paint; tyres are pure rubber (no sky reflection)
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		if m.resource_name == "Paint":
			m.albedo_color = paint_color
			m.metallic = 0.65
			m.roughness = 0.14
			m.metallic_specular = 0.8
			m.clearcoat_enabled = true
			m.clearcoat = 1.0
			m.clearcoat_roughness = 0.02
			m.rim_enabled = true          # fake fresnel sheen on the paint edges
			m.rim = 0.25
			m.rim_tint = 0.6
		elif m.resource_name in GLASS_MATS:
			m.roughness = 0.02
			m.metallic = 0.3
			m.metallic_specular = 1.0
		elif m.resource_name == "Tyre":
			m.metallic = 0.0
			m.roughness = 1.0
			m.metallic_specular = 0.0

func _read_input() -> Vector3:
	# returns (throttle, steer, handbrake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var hb: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			hb = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		hb = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), hb)

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var throttle: float = inp.x
	var handbrake: bool = inp.z > 0.5

	# ---- speed
	if handbrake:
		speed = move_toward(speed, 0.0, brake_decel * 1.3 * delta)
	elif throttle > 0.05:
		if speed < -0.5:
			speed += brake_decel * delta
		else:
			# strong pull until close to top speed (quadratic fall-off instead of linear)
			var ratio: float = clampf(speed / max_speed, 0.0, 1.0)
			speed += accel * throttle * (1.0 - ratio * ratio) * delta + 0.5 * delta
	elif throttle < -0.05:
		if speed > 0.5:
			speed -= brake_decel * (-throttle) * delta
		else:
			speed -= accel * 0.6 * (-throttle) * delta
	else:
		speed = move_toward(speed, 0.0, coast_decel * delta)

	# ---- terrain slope: gravity along the hill, and cliffs block the way
	var fwd: Vector3 = forward_vector()
	var pos: Vector3 = global_position
	var gc: float = _ground(pos.x, pos.z)
	var f_pt: Vector3 = pos + fwd * 1.9
	var r_pt: Vector3 = pos - fwd * 1.9
	var slope_body: float = (_ground(f_pt.x, f_pt.z) - _ground(r_pt.x, r_pt.z)) / 3.8     # + = nose up
	if absf(speed) > 0.8 or absf(throttle) > 0.05:
		speed -= gravity * 0.4 * slope_body / sqrt(1.0 + slope_body * slope_body) * delta
	var dirn: float = 1.0 if speed >= 0.0 else -1.0
	var lead: Vector3 = pos + fwd * dirn * 3.0
	if (_ground(lead.x, lead.z) - gc) / 3.0 > 1.2:                    # steeper than ~50 deg ahead
		speed = move_toward(speed, 0.0, 70.0 * delta)
	speed = clampf(speed, -reverse_speed, max_speed)

	# ---- steering (bicycle model)
	var steer_limit: float = lerpf(max_steer_low, max_steer_high, clampf(absf(speed) / max_speed, 0.0, 1.0))
	var steer_target: float = -inp.y * steer_limit      # positive angle = turn left
	steer_now = move_toward(steer_now, steer_target, 2.6 * delta)
	heading += speed / CarMeta.WHEELBASE * tan(steer_now) * delta
	rotation.y = heading
	fwd = forward_vector()

	# ---- horizontal movement only (props / boundary collide, height is done by the suspension)
	var cs: float = 1.0 / sqrt(1.0 + slope_body * slope_body)           # slope speed -> ground-plane speed
	velocity = Vector3(fwd.x * speed * cs, 0.0, fwd.z * speed * cs)
	global_position.y = ride_y
	move_and_slide()
	global_position.y = ride_y
	var hv: float = velocity.x * fwd.x + velocity.z * fwd.z
	speed = hv / maxf(cs, 0.3)                                          # trees / rocks slow the car down

	# ---- body motion from acceleration / cornering
	var la_raw: float = clampf((speed - prev_speed) / maxf(delta, 0.0001), -20.0, 20.0)
	long_acc = lerpf(long_acc, la_raw, 0.15)
	prev_speed = speed
	var lat_acc: float = speed * speed * tan(steer_now) / CarMeta.WHEELBASE   # + = turning left
	_suspension(delta, long_acc * 1.2, -lat_acc * 0.45)

	_update_visual(delta)

	# optional live reflection probe (off by default)
	if probe != null:
		probe_timer += delta
		if probe_timer > 1.5 and (absf(speed) > 1.0 or probe_timer > 4.0):
			probe_timer = 0.0
			probe.update_mode = ReflectionProbe.UPDATE_ALWAYS
			await get_tree().process_frame
			probe.update_mode = ReflectionProbe.UPDATE_ONCE

# 4 springs: each wheel's attach point is compared with the terrain height under that wheel.
func _suspension(delta: float, pitch_torque: float, roll_torque: float) -> void:
	var yaw_basis := Basis(Vector3.UP, heading)
	var body_basis: Basis = yaw_basis * Basis(Vector3.RIGHT, pitch) * Basis(Vector3.BACK, roll)
	var pos: Vector3 = global_position
	var k: float = gravity / (4.0 * maxf(susp_ext_max - susp_ext_rest, 0.05))   # static load = gravity
	var fsum: float = 0.0
	var tp: float = pitch_torque
	var tr: float = roll_torque
	var contacts: int = 0
	for i in range(4):
		var w: Vector3 = CarMeta.WHEELS[i]
		var a: Vector3 = pos + body_basis * Vector3(w.x, w.y + susp_ext_rest, w.z)
		var g: float = _ground(a.x, a.z)
		var raw: float = a.y - CarMeta.WHEEL_RADIUS - g          # distance wheel-bottom to ground if fully compressed
		var e: float = clampf(raw, 0.0, susp_ext_max)
		var rate: float = clampf((e - ext[i]) / maxf(delta, 0.0001), -12.0, 12.0)
		var f: float = 0.0
		if raw < susp_ext_max:                                   # wheel touches the ground
			contacts += 1
			f = maxf(k * (susp_ext_max - e) - spring_damping * rate, 0.0)
			if raw < 0.0:
				f += BUMP_K * (-raw) - 25.0 * minf(vy, 0.0)      # bump stop
		ext[i] = e
		fsum += f
		tp += -w.z * f
		tr += w.x * f
	vy += (fsum - gravity) * delta
	pitch_vel += tp / INERTIA_PITCH * delta
	roll_vel += tr / INERTIA_ROLL * delta
	var damp: float = exp(-(0.6 if contacts == 0 else 1.2) * delta)
	pitch_vel *= damp
	roll_vel *= damp
	pitch += pitch_vel * delta
	roll += roll_vel * delta
	if absf(pitch) > 1.0:
		pitch = clampf(pitch, -1.0, 1.0)
		pitch_vel = 0.0
	if absf(roll) > 0.9:
		roll = clampf(roll, -0.9, 0.9)
		roll_vel = 0.0
	ride_y += vy * delta
	var gc: float = _ground(pos.x, pos.z)
	if ride_y < gc - 0.6:                                        # safety: never fall through the map
		ride_y = gc + 0.2
		vy = 0.0
	global_position.y = ride_y

func _update_visual(delta: float) -> void:
	if visual == null:
		return
	visual.basis = Basis(Vector3.RIGHT, pitch) * Basis(Vector3.BACK, roll)
	wheel_spin = wrapf(wheel_spin - speed / CarMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	for i in range(wheel_spinners.size()):
		(wheel_spinners[i] as Node3D).rotation.x = wheel_spin
		var pv := wheel_pivots[i] as Node3D
		var w: Vector3 = CarMeta.WHEELS[i]
		pv.position.y = w.y + susp_ext_rest - ext[i]           # wheels follow the ground, body rides on springs
		if i < 2:
			pv.rotation.y = steer_now
