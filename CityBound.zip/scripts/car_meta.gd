# Generated from the converted car model (tools/car/convert_car.py) - metres, Godot axes (-Z = front)
extends RefCounted

const WHEELS: Array = [
	Vector3(-1.057, 0.495, -1.906),   # front left
	Vector3(1.058, 0.495, -1.906),    # front right
	Vector3(-1.057, 0.495, 1.911),    # rear left
	Vector3(1.058, 0.495, 1.911),     # rear right
]
const WHEEL_RADIUS: float = 0.49
const WHEELBASE: float = 3.82
