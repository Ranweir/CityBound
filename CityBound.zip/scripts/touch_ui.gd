extends Control
signal debug_pressed(id: int)
signal jiggle_changed(enabled: bool, intensity: float)
# Touch controls: left side = floating joystick, right side drag = camera, round button = jump.

var move_vec: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var jump_pressed: bool = false
var run_held: bool = false
var jiggle_on: bool = true
var jiggle_amount: float = 1.0   # 0..JIGGLE_MAX

const JOY_RADIUS: float = 95.0
const JUMP_RADIUS: float = 64.0
const RUN_RADIUS: float = 52.0
const JIGGLE_MAX: float = 2.0

var _joy_id: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _look_id: int = -1
var _jump_id: int = -1
var _run_id: int = -1
var _slider_id: int = -1
var debug_labels: Array = ["Clear", "Cloudy", "Rain", "Post", "+3h"]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_delta: float) -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size
	queue_redraw()

func _debug_rect(i: int) -> Rect2:
	var w: float = 96.0
	var gap: float = 8.0
	var total: float = float(debug_labels.size()) * w + float(debug_labels.size() - 1) * gap
	return Rect2(size.x - total - 16.0 + float(i) * (w + gap), 52.0, w, 44.0)

func _slider_rect() -> Rect2:
	return Rect2(size.x - 16.0 - 230.0, 124.0, 230.0, 44.0)

func _toggle_rect() -> Rect2:
	var sr: Rect2 = _slider_rect()
	return Rect2(sr.position.x - 8.0 - 150.0, 124.0, 150.0, 44.0)

func _set_slider_from_x(px: float) -> void:
	var sr: Rect2 = _slider_rect()
	var t: float = clampf((px - (sr.position.x + 14.0)) / (sr.size.x - 28.0), 0.0, 1.0)
	jiggle_amount = snappedf(t * JIGGLE_MAX, 0.05)
	jiggle_changed.emit(jiggle_on, jiggle_amount)

func _run_center() -> Vector2:
	return Vector2(size.x - 290.0, size.y - 85.0)

func _jump_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 130.0)

func _idle_joy_center() -> Vector2:
	return Vector2(170.0, size.y - 160.0)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed:
			var hit_debug: bool = false
			for i in range(debug_labels.size()):
				if _debug_rect(i).has_point(t.position):
					debug_pressed.emit(i)
					hit_debug = true
			if hit_debug:
				pass
			elif _toggle_rect().has_point(t.position):
				jiggle_on = not jiggle_on
				jiggle_changed.emit(jiggle_on, jiggle_amount)
			elif _slider_id == -1 and _slider_rect().grow(8.0).has_point(t.position):
				_slider_id = t.index
				_set_slider_from_x(t.position.x)
			elif _run_id == -1 and t.position.distance_to(_run_center()) < RUN_RADIUS * 1.4:
				_run_id = t.index
				run_held = true
			elif _jump_id == -1 and t.position.distance_to(_jump_center()) < JUMP_RADIUS * 1.4:
				_jump_id = t.index
				jump_pressed = true
			elif _joy_id == -1 and t.position.x < size.x * 0.42 and t.position.y > size.y * 0.25:
				_joy_id = t.index
				_joy_origin = t.position
				_joy_pos = t.position
				move_vec = Vector2.ZERO
			elif _look_id == -1 and t.position.x >= size.x * 0.42:
				_look_id = t.index
		else:
			if t.index == _joy_id:
				_joy_id = -1
				move_vec = Vector2.ZERO
			elif t.index == _slider_id:
				_slider_id = -1
			elif t.index == _look_id:
				_look_id = -1
			elif t.index == _jump_id:
				_jump_id = -1
			elif t.index == _run_id:
				_run_id = -1
				run_held = false
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if d.index == _joy_id:
			_joy_pos = d.position
			var delta_v: Vector2 = (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
			move_vec = delta_v / JOY_RADIUS
		elif d.index == _slider_id:
			_set_slider_from_x(d.position.x)
		elif d.index == _look_id:
			look_delta += d.relative

func _draw() -> void:
	var base_c: Vector2 = _idle_joy_center()
	var knob_c: Vector2 = base_c
	var alpha: float = 0.25
	if _joy_id != -1:
		base_c = _joy_origin
		knob_c = _joy_origin + (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
		alpha = 0.5
	draw_circle(base_c, JOY_RADIUS, Color(1, 1, 1, alpha * 0.45))
	draw_arc(base_c, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, alpha + 0.2), 3.0)
	draw_circle(knob_c, 38.0, Color(1, 1, 1, alpha + 0.2))
	var jc: Vector2 = _jump_center()
	var ja: float = 0.55 if _jump_id != -1 else 0.3
	draw_circle(jc, JUMP_RADIUS, Color(1, 1, 1, ja * 0.6))
	draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ja + 0.25), 3.0)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, jc + Vector2(-JUMP_RADIUS, 9.0), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 26, Color(1, 1, 1, 0.95))

	var rc: Vector2 = _run_center()
	var ra: float = 0.55 if _run_id != -1 else 0.3
	draw_circle(rc, RUN_RADIUS, Color(1, 1, 1, ra * 0.6))
	draw_arc(rc, RUN_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ra + 0.25), 3.0)
	draw_string(font, rc + Vector2(-RUN_RADIUS, 8.0), "RUN", HORIZONTAL_ALIGNMENT_CENTER, RUN_RADIUS * 2.0, 22, Color(1, 1, 1, 0.95))
	for i in range(debug_labels.size()):
		var r: Rect2 = _debug_rect(i)
		draw_rect(r, Color(0, 0, 0, 0.45), true)
		draw_rect(r, Color(1, 1, 1, 0.5), false, 2.0)
		draw_string(font, r.position + Vector2(0.0, 29.0), str(debug_labels[i]), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 22, Color(1, 1, 1, 0.95))

	# jiggle toggle + intensity slider
	var tgr: Rect2 = _toggle_rect()
	draw_rect(tgr, Color(0, 0, 0, 0.45), true)
	draw_rect(tgr, Color(1, 1, 1, 0.5), false, 2.0)
	draw_string(font, tgr.position + Vector2(0.0, 29.0), "Jiggle: " + ("ON" if jiggle_on else "OFF"), HORIZONTAL_ALIGNMENT_CENTER, tgr.size.x, 22, Color(1, 1, 1, 0.95) if jiggle_on else Color(1, 1, 1, 0.55))
	var sr: Rect2 = _slider_rect()
	draw_rect(sr, Color(0, 0, 0, 0.45), true)
	draw_rect(sr, Color(1, 1, 1, 0.5), false, 2.0)
	var x0: float = sr.position.x + 14.0
	var x1: float = sr.position.x + sr.size.x - 14.0
	var cy: float = sr.position.y + sr.size.y * 0.5
	draw_line(Vector2(x0, cy), Vector2(x1, cy), Color(1, 1, 1, 0.35), 4.0)
	var kx: float = lerpf(x0, x1, jiggle_amount / JIGGLE_MAX)
	draw_line(Vector2(x0, cy), Vector2(kx, cy), Color(1, 1, 1, 0.85 if jiggle_on else 0.4), 4.0)
	draw_circle(Vector2(kx, cy), 12.0, Color(1, 1, 1, 0.95 if jiggle_on else 0.5))
	draw_string(font, Vector2(sr.position.x, sr.position.y - 6.0), "%d%%" % int(round(jiggle_amount * 100.0)), HORIZONTAL_ALIGNMENT_RIGHT, sr.size.x, 18, Color(1, 1, 1, 0.9))
