extends Control
# Touch controls: left side = floating joystick, right side drag = camera, round button = jump.

var move_vec: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var jump_pressed: bool = false

const JOY_RADIUS: float = 95.0
const JUMP_RADIUS: float = 64.0

var _joy_id: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _look_id: int = -1
var _jump_id: int = -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_delta: float) -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size
	queue_redraw()

func _jump_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 130.0)

func _idle_joy_center() -> Vector2:
	return Vector2(170.0, size.y - 160.0)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed:
			if _jump_id == -1 and t.position.distance_to(_jump_center()) < JUMP_RADIUS * 1.4:
				_jump_id = t.index
				jump_pressed = true
			elif _joy_id == -1 and t.position.x < size.x * 0.42 and t.position.y > size.y * 0.25:
				_joy_id = t.index
				_joy_origin = t.position
				_joy_pos = t.position
				move_vec = Vector2.ZERO
			elif _look_id == -1 and t.position.x >= size.x * 0.42:
				_look_id = t.index
		else:
			if t.index == _joy_id:
				_joy_id = -1
				move_vec = Vector2.ZERO
			elif t.index == _look_id:
				_look_id = -1
			elif t.index == _jump_id:
				_jump_id = -1
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if d.index == _joy_id:
			_joy_pos = d.position
			var delta_v: Vector2 = (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
			move_vec = delta_v / JOY_RADIUS
		elif d.index == _look_id:
			look_delta += d.relative

func _draw() -> void:
	var base_c: Vector2 = _idle_joy_center()
	var knob_c: Vector2 = base_c
	var alpha: float = 0.25
	if _joy_id != -1:
		base_c = _joy_origin
		knob_c = _joy_origin + (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
		alpha = 0.5
	draw_circle(base_c, JOY_RADIUS, Color(1, 1, 1, alpha * 0.45))
	draw_arc(base_c, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, alpha + 0.2), 3.0)
	draw_circle(knob_c, 38.0, Color(1, 1, 1, alpha + 0.2))
	var jc: Vector2 = _jump_center()
	var ja: float = 0.55 if _jump_id != -1 else 0.3
	draw_circle(jc, JUMP_RADIUS, Color(1, 1, 1, ja * 0.6))
	draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ja + 0.25), 3.0)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, jc + Vector2(-JUMP_RADIUS, 9.0), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 26, Color(1, 1, 1, 0.95))
