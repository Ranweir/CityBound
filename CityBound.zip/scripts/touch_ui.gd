extends Control
signal debug_pressed(id: int)
signal enter_pressed
# Touch controls: left side = floating joystick, right side drag = camera, round button = jump.

var move_vec: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var jump_pressed: bool = false
var run_held: bool = false
var drive_mode: bool = false     # true while sitting in the car: arrow buttons instead of joystick
var show_enter: bool = false     # true when the player stands next to the car
var _held: Dictionary = {}       # button name -> number of fingers on it
var _btn_touch: Dictionary = {}  # touch index -> button name
const ENTER_RADIUS: float = 52.0

const JOY_RADIUS: float = 95.0
const JUMP_RADIUS: float = 64.0
const RUN_RADIUS: float = 52.0

var _joy_id: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _look_id: int = -1
var _jump_id: int = -1
var _run_id: int = -1
var debug_labels: Array = ["Clear", "Cloudy", "Rain", "Post", "+3h"]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_delta: float) -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size
	queue_redraw()

func _debug_rect(i: int) -> Rect2:
	var w: float = 96.0
	var gap: float = 8.0
	var total: float = float(debug_labels.size()) * w + float(debug_labels.size() - 1) * gap
	return Rect2(size.x - total - 16.0 + float(i) * (w + gap), 52.0, w, 44.0)

func _run_center() -> Vector2:
	return Vector2(size.x - 290.0, size.y - 85.0)

func _jump_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 130.0)

func _idle_joy_center() -> Vector2:
	return Vector2(170.0, size.y - 160.0)

func is_held(btn: String) -> bool:
	return int(_held.get(btn, 0)) > 0

func _press(btn: String) -> void:
	_held[btn] = int(_held.get(btn, 0)) + 1

func _release(btn: String) -> void:
	_held[btn] = maxi(int(_held.get(btn, 0)) - 1, 0)

func release_all() -> void:
	_held.clear()
	_btn_touch.clear()
	_joy_id = -1
	move_vec = Vector2.ZERO
	run_held = false
	_run_id = -1
	_jump_id = -1

func _enter_center() -> Vector2:
	return Vector2(size.x - 140.0, size.y - 275.0)

# arrow buttons (drive mode)
func _drive_rect(btn: String) -> Rect2:
	match btn:
		"left":
			return Rect2(36.0, size.y - 196.0, 150.0, 150.0)
		"right":
			return Rect2(210.0, size.y - 196.0, 150.0, 150.0)
		"gas":
			return Rect2(size.x - 190.0, size.y - 356.0, 150.0, 150.0)
		"brake":
			return Rect2(size.x - 190.0, size.y - 190.0, 150.0, 150.0)
		"hb":
			return Rect2(size.x - 360.0, size.y - 160.0, 110.0, 110.0)
		"exit":
			return Rect2(size.x - 360.0, size.y - 290.0, 110.0, 110.0)
	return Rect2()

const DRIVE_BUTTONS: Array = ["left", "right", "gas", "brake", "hb", "exit"]

func _drive_hit(pos: Vector2) -> String:
	for n in DRIVE_BUTTONS:
		if _drive_rect(n).grow(14.0).has_point(pos):
			return n
	return ""

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed:
			var hit_debug: bool = false
			for i in range(debug_labels.size()):
				if _debug_rect(i).has_point(t.position):
					debug_pressed.emit(i)
					hit_debug = true
			if hit_debug:
				pass
			elif drive_mode:
				var nm: String = _drive_hit(t.position)
				if nm == "exit":
					enter_pressed.emit()
				elif nm != "":
					_btn_touch[t.index] = nm
					_press(nm)
				elif _look_id == -1 and t.position.x >= size.x * 0.42:
					_look_id = t.index
			elif show_enter and t.position.distance_to(_enter_center()) < ENTER_RADIUS * 1.4:
				enter_pressed.emit()
			elif _run_id == -1 and t.position.distance_to(_run_center()) < RUN_RADIUS * 1.4:
				_run_id = t.index
				run_held = true
			elif _jump_id == -1 and t.position.distance_to(_jump_center()) < JUMP_RADIUS * 1.4:
				_jump_id = t.index
				jump_pressed = true
			elif _joy_id == -1 and t.position.x < size.x * 0.42 and t.position.y > size.y * 0.25:
				_joy_id = t.index
				_joy_origin = t.position
				_joy_pos = t.position
				move_vec = Vector2.ZERO
			elif _look_id == -1 and t.position.x >= size.x * 0.42:
				_look_id = t.index
		else:
			if _btn_touch.has(t.index):
				_release(_btn_touch[t.index])
				_btn_touch.erase(t.index)
			if t.index == _joy_id:
				_joy_id = -1
				move_vec = Vector2.ZERO
			elif t.index == _look_id:
				_look_id = -1
			elif t.index == _jump_id:
				_jump_id = -1
			elif t.index == _run_id:
				_run_id = -1
				run_held = false
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if _btn_touch.has(d.index):
			var old_n: String = _btn_touch[d.index]
			var new_n: String = _drive_hit(d.position)
			if new_n != old_n and new_n != "exit":
				_release(old_n)
				if new_n == "":
					_btn_touch.erase(d.index)
				else:
					_btn_touch[d.index] = new_n
					_press(new_n)
		if d.index == _joy_id:
			_joy_pos = d.position
			var delta_v: Vector2 = (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
			move_vec = delta_v / JOY_RADIUS
		elif d.index == _look_id:
			look_delta += d.relative

func _draw_arrow(r: Rect2, dir: String, pressed: bool) -> void:
	var a: float = 0.6 if pressed else 0.32
	draw_rect(r, Color(1, 1, 1, a * 0.55), true)
	draw_rect(r, Color(1, 1, 1, a + 0.25), false, 3.0)
	var c: Vector2 = r.get_center()
	var h: float = r.size.x * 0.28
	var pts: PackedVector2Array
	match dir:
		"left":
			pts = PackedVector2Array([c + Vector2(-h, 0.0), c + Vector2(h * 0.8, -h), c + Vector2(h * 0.8, h)])
		"right":
			pts = PackedVector2Array([c + Vector2(h, 0.0), c + Vector2(-h * 0.8, -h), c + Vector2(-h * 0.8, h)])
		"up":
			pts = PackedVector2Array([c + Vector2(0.0, -h), c + Vector2(-h, h * 0.8), c + Vector2(h, h * 0.8)])
		_:
			pts = PackedVector2Array([c + Vector2(0.0, h), c + Vector2(-h, -h * 0.8), c + Vector2(h, -h * 0.8)])
	draw_colored_polygon(pts, Color(1, 1, 1, 0.95))

func _draw_round_btn(r: Rect2, label: String, pressed: bool) -> void:
	var font: Font = ThemeDB.fallback_font
	var c: Vector2 = r.get_center()
	var rad: float = r.size.x * 0.5
	var a: float = 0.6 if pressed else 0.32
	draw_circle(c, rad, Color(1, 1, 1, a * 0.6))
	draw_arc(c, rad, 0.0, TAU, 40, Color(1, 1, 1, a + 0.25), 3.0)
	draw_string(font, c + Vector2(-rad, 9.0), label, HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 24, Color(1, 1, 1, 0.95))

func _draw_debug_buttons() -> void:
	var font: Font = ThemeDB.fallback_font
	_draw_debug_buttons()
	if show_enter:
		var ec: Vector2 = _enter_center()
		draw_circle(ec, ENTER_RADIUS, Color(1, 0.85, 0.2, 0.45))
		draw_arc(ec, ENTER_RADIUS, 0.0, TAU, 40, Color(1, 0.9, 0.3, 0.95), 3.0)
		draw_string(font, ec + Vector2(-ENTER_RADIUS, 8.0), "CAR", HORIZONTAL_ALIGNMENT_CENTER, ENTER_RADIUS * 2.0, 24, Color(1, 1, 1, 1))

func _draw_drive() -> void:
	_draw_arrow(_drive_rect("left"), "left", is_held("left"))
	_draw_arrow(_drive_rect("right"), "right", is_held("right"))
	_draw_arrow(_drive_rect("gas"), "up", is_held("gas"))
	_draw_arrow(_drive_rect("brake"), "down", is_held("brake"))
	_draw_round_btn(_drive_rect("hb"), "HB", is_held("hb"))
	_draw_round_btn(_drive_rect("exit"), "EXIT", false)
	_draw_debug_buttons()

func _draw() -> void:
	if drive_mode:
		_draw_drive()
		return
	var base_c: Vector2 = _idle_joy_center()
	var knob_c: Vector2 = base_c
	var alpha: float = 0.25
	if _joy_id != -1:
		base_c = _joy_origin
		knob_c = _joy_origin + (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
		alpha = 0.5
	draw_circle(base_c, JOY_RADIUS, Color(1, 1, 1, alpha * 0.45))
	draw_arc(base_c, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, alpha + 0.2), 3.0)
	draw_circle(knob_c, 38.0, Color(1, 1, 1, alpha + 0.2))
	var jc: Vector2 = _jump_center()
	var ja: float = 0.55 if _jump_id != -1 else 0.3
	draw_circle(jc, JUMP_RADIUS, Color(1, 1, 1, ja * 0.6))
	draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ja + 0.25), 3.0)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, jc + Vector2(-JUMP_RADIUS, 9.0), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, JUMP_RADIUS * 2.0, 26, Color(1, 1, 1, 0.95))

	var rc: Vector2 = _run_center()
	var ra: float = 0.55 if _run_id != -1 else 0.3
	draw_circle(rc, RUN_RADIUS, Color(1, 1, 1, ra * 0.6))
	draw_arc(rc, RUN_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, ra + 0.25), 3.0)
	draw_string(font, rc + Vector2(-RUN_RADIUS, 8.0), "RUN", HORIZONTAL_ALIGNMENT_CENTER, RUN_RADIUS * 2.0, 22, Color(1, 1, 1, 0.95))
	_draw_debug_buttons()
	if show_enter:
		var ec: Vector2 = _enter_center()
		draw_circle(ec, ENTER_RADIUS, Color(1, 0.85, 0.2, 0.45))
		draw_arc(ec, ENTER_RADIUS, 0.0, TAU, 40, Color(1, 0.9, 0.3, 0.95), 3.0)
		draw_string(font, ec + Vector2(-ENTER_RADIUS, 8.0), "CAR", HORIZONTAL_ALIGNMENT_CENTER, ENTER_RADIUS * 2.0, 24, Color(1, 1, 1, 1))
