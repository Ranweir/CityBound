extends CharacterBody3D
# KamAZ-5320 6x6 army truck - heavy driving model (built on the car.gd tyre model v3)
#  * 6x6: all three axles are driven. The torque curve is very strong at low speed (crawl power: it climbs, ploughs through mud and
#    water and pulls away from a standstill with load) and falls off towards a modest top speed.
#  * heavy: ~9 tonnes. It builds up speed slowly, carries its momentum (long coast / brake distance), turns lazily and wallows on its
#    soft suspension (big dive / squat / body roll). Wide turning circle: the rear bogie scrubs the tyres in tight turns.
#  * tyres: same Pacejka-style lateral force with slip-angle relaxation, load transfer and friction circle as the F-150, but tuned
#    for big offroad tyres (stable, understeer first, slow to break away).
#  * suspension: 6 corners. The middle and rear axle form a walking-beam bogie (both axles share their load, so the truck keeps all
#    wheels planted over bumps).
#  * mud: main.gd presses deeper and wider ruts for this truck (`rut_depth_mul`, `rut_radius`), the body sinks further into soft ground
#    (`mud_sink_mul`) and the wheels throw mud clods while it drives through mud (`mud_k`).
# Joystick up/down = throttle/brake-reverse, left/right = steer, JUMP button = handbrake.

@export var max_speed: float = 23.0         # m/s (~83 km/h)
@export var reverse_speed: float = 6.0
@export var accel: float = 3.8              # engine pull (m/s^2) once rolling; the torque curve adds up to +torque_boost x this at standstill
@export var torque_boost: float = 1.0       # extra pull at very low speed (1 = +100% at standstill, fades out by ~9 m/s)
@export var brake_decel: float = 10.5       # air brakes: strong but slow to build; the tyres limit it
@export var coast_decel: float = 1.6        # heavy: it rolls on
@export var max_steer_low: float = 0.52     # rad of front-wheel angle at standstill
@export var max_steer_high: float = 0.10    # rad at top speed
@export var gravity: float = 22.0           # suspension / jump gravity (arcade scale). Tyres use real 9.81
@export var mass_tonnes: float = 9.0        # used by main.gd (rut pressure, sinking) and for the slope / collision feel
@export var slope_gravity: float = 0.2      # how much a hill slows the truck (the F-150 is 0.4): the torque pulls it up

# visual / mud tuning (read by main.gd)
@export var rut_depth_mul: float = 1.9      # a heavy truck digs deeper than the ground allows a light car (1 = same as the F-150)
@export var rut_radius: float = 0.46        # m, width of the tyre print pressed into the ground
@export var rut_power: float = 2.4          # how fast the ruts deepen per pass
@export var mud_sink_mul: float = 1.7       # the body sinks this much more into soft ground
@export var mud_drag_mul: float = 1.5       # mud drags the heavy truck harder (the 6x6 torque keeps it moving)

const WHEEL_NAMES := ["WheelFL", "WheelFR", "WheelML", "WheelMR", "WheelRL", "WheelRR"]
const SELF_LAYER: int = 1 << 19     # car meshes live on layer 20 so the reflection probe does not capture the car itself
const G_REAL: float = 9.81
const SKID_POOL: int = 72
const SKID_SPACING: float = 0.48

@export var use_reflection_probe: bool = false     # live reflections cost a lot on phones; sky reflections stay on
@export var enable_fx: bool = true                 # tyre smoke / dust + skid marks

# ---- handling (tyre model)
@export var grip_accel: float = 8.2                # tyre grip at mu = 1 (m/s^2). Big offroad tyres, but a lot of mass
@export var cg_front_ratio: float = 0.56           # CG distance from front axle / wheelbase (loaded bed = CG a bit behind the middle)
@export var cg_height: float = 1.25                # m, tall truck: lots of weight transfer under braking / acceleration
@export var yaw_inertia: float = 6.2               # m^2 (mass = 1); heavy = lazy rotation
@export var tire_stiff: float = 8.5                # cornering stiffness; lower = softer, slower response than the car
@export var tire_relax: float = 1.5                # m, tyre relaxation length: grip builds up slowly
@export var rear_grip_bias: float = 1.6            # rear bogie grips a lot: the truck understeers instead of spinning
@export var handbrake_rear_grip: float = 0.55
@export var handbrake_decel: float = 3.0
@export var drive_grip_gain: float = 2.1           # 6 driven wheels + lockable diffs put far more down than lateral grip alone
@export var drive_circle: float = 0.45
@export var rear_drive_share: float = 0.67         # 6x6: front axle 1/3 of the torque, the two rear axles 2/3
@export var awd_adaptive: float = 0.55             # centre-diff behaviour: torque follows the axles that have grip (mud, water, slopes)
@export var steer_overshoot: float = 1.1
@export var countersteer_assist: float = 0.5
@export var stability_assist: float = 1.8          # a heavy truck should not spin out
@export var bogie_scrub: float = 0.55              # tight turns at crawl speed fight the rear bogie (turning circle gets wider)

# ---- suspension (6 corners, soft and long travel: it wallows)
@export var susp_ext_rest: float = 0.28
@export var susp_ext_max: float = 0.66
@export var damping_bump: float = 0.40
@export var damping_rebound: float = 0.70
@export var spring_progressive: float = 3.5
@export var arb_front: float = 6.0
@export var arb_rear: float = 5.0
@export var body_motion: float = 2.1
@export var roll_arm: float = 1.0                  # m, CG height above the roll centre (tall truck = big body roll)
@export var bogie_equalise: float = 0.5            # 0 = independent axles, 1 = walking beam (both bogie axles carry the same load)

const BUMP_K: float = 500.0                        # bump-stop stiffness
const INERTIA_PITCH: float = 5.2
const INERTIA_ROLL: float = 1.7

var world = null              # map_builder.gd instance (set by main.gd) - used for terrain height
var probe: ReflectionProbe = null
var probe_timer: float = 0.0
var ride_y: float = 0.0       # body height (world Y of the body origin)
var vy: float = 0.0
var pitch: float = 0.0        # + = nose up
var roll: float = 0.0         # + = right side up
var pitch_vel: float = 0.0
var roll_vel: float = 0.0
var ext := PackedFloat32Array([0.28, 0.28, 0.28, 0.28, 0.28, 0.28])   # current suspension extension per wheel
var wheel_contact := PackedByteArray([1, 1, 1, 1, 1, 1])        # 1 = wheel touches the ground
var ground_k: float = 1.0     # smoothed share of wheels on the ground (0 = airborne)
var prev_speed: float = 0.0
var long_acc: float = 0.0
var water_pitch: float = 0.0  # extra body tilt while wading (set by main.gd): bow wave + floating sway
var water_roll: float = 0.0
var ui = null                # touch_ui.gd instance (set by main.gd)
var enter_range: float = 7.0  # how close the player must be to get in
var driven: bool = false      # true while the player sits in the car
var heading: float = 0.0      # yaw in radians (same convention as rotation.y, front = -Z)
var speed: float = 0.0        # signed forward speed (m/s)
var steer_now: float = 0.0
var steer_in: float = 0.0     # smoothed steering input (-1..1)
var throttle_s: float = 0.0   # smoothed throttle / brake pedal (-1..1)
var grip: float = 1.0         # surface grip 0.15..1 (set by main.gd from the terrain under the car)
var lat_speed: float = 0.0    # sideways velocity in the car frame, + = sliding left (m/s)
var yaw_rate: float = 0.0     # rad/s, + = turning left
var alpha_f: float = 0.0      # front / rear tyre slip angle (filtered, rad)
var alpha_r: float = 0.0
var lat_acc_f: float = 0.0    # filtered lateral acceleration (feeds body roll)
var slip_extra: float = 0.0   # wheelspin amount 0..1 (visual)
var cam_slide: float = 0.0    # smoothed body slip angle (rad): main.gd swings the camera with it
var wheel_spin_rear: float = 0.0
var visual: Node3D = null
var wheel_pivots: Array = []
var wheel_spinners: Array = []
var wheel_spin: float = 0.0

# tyre smoke / skid marks
var smoke: Array = []
var mud_fx: Array = []
var mud_k: float = 0.0        # 0..1 how soft / muddy the ground under the wheels is (set by main.gd): mud clods fly while > 0
var skid_nodes: Array = []
var skid_age := PackedFloat32Array()
var skid_next: int = 0
var skid_last: Array = []
var _skid_mat: StandardMaterial3D = null

func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING   # no floor logic: height comes from the suspension
	collision_mask = 2        # only props / boundary (layer 2). The terrain is handled by the wheels.
	heading = rotation.y
	ride_y = global_position.y
	for i in range(6):
		ext[i] = susp_ext_rest
	_build_collision()
	_build_visual()
	if use_reflection_probe:
		_build_reflection_probe()
	if enable_fx:
		_build_fx()

func _ground(x: float, z: float) -> float:
	if world != null:
		return world.get_height(x, z)
	return 0.0

func forward_vector() -> Vector3:
	return Vector3(-sin(heading), 0.0, -cos(heading))

func speed_kmh() -> float:
	return absf(speed) * 3.6

func _build_collision() -> void:
	# convex hull: long low chassis, tall cab at the front, cargo bed (walls ~2.05 m) behind it
	var pts := PackedVector3Array([
		Vector3(-1.25, 0.50, -3.35), Vector3(1.25, 0.50, -3.35), Vector3(-1.30, 0.50, 3.50), Vector3(1.30, 0.50, 3.50),
		Vector3(-1.30, 1.15, -3.35), Vector3(1.30, 1.15, -3.35), Vector3(-1.38, 1.30, 3.55), Vector3(1.38, 1.30, 3.55),
		Vector3(-1.15, 2.85, -3.05), Vector3(1.15, 2.85, -3.05), Vector3(-1.15, 2.85, -1.45), Vector3(1.15, 2.85, -1.45),
		Vector3(-1.38, 2.05, -0.55), Vector3(1.38, 2.05, -0.55), Vector3(-1.38, 2.05, 3.55), Vector3(1.38, 2.05, 3.55),
	])
	var shape := ConvexPolygonShape3D.new()
	shape.points = pts
	var cs := CollisionShape3D.new()
	cs.shape = shape
	add_child(cs)

func _build_reflection_probe() -> void:
	# live reflections of terrain, trees and sky on the paint and glass
	probe = ReflectionProbe.new()
	probe.name = "ReflectionProbe"
	probe.position = Vector3(0.0, 1.3, 0.0)
	probe.size = Vector3(40.0, 20.0, 40.0)
	probe.origin_offset = Vector3.ZERO
	probe.box_projection = false
	probe.interior = false
	probe.max_distance = 120.0
	probe.intensity = 1.0
	probe.cull_mask = 0xFFFFF & ~SELF_LAYER
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	add_child(probe)

func _find_mesh(root: Node, prefix: String) -> Mesh:
	for c in root.find_children("*", "MeshInstance3D", true, false):
		if String(c.name) == prefix:
			return (c as MeshInstance3D).mesh
	return null

func _build_visual() -> void:
	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)
	var scene: PackedScene = load("res://assets/truck/kamaz.glb")
	var inst: Node = scene.instantiate()
	var body_mesh: Mesh = _find_mesh(inst, "Body")
	var wheel_meshes: Array = []
	for nm in WHEEL_NAMES:
		wheel_meshes.append(_find_mesh(inst, nm))
	inst.free()
	if body_mesh == null:
		push_error("kamaz.glb: Body mesh not found")
		return
	_style_mesh(body_mesh)
	var body := MeshInstance3D.new()
	body.name = "Body"
	body.mesh = body_mesh
	body.layers = SELF_LAYER
	visual.add_child(body)
	for i in range(6):
		var wmesh: Mesh = wheel_meshes[i]
		if wmesh == null:
			push_error("kamaz.glb: wheel mesh missing: " + WHEEL_NAMES[i])
			return
		_style_mesh(wmesh)
		var pivot := Node3D.new()
		pivot.position = TruckMeta.WHEELS[i]
		visual.add_child(pivot)
		var spinner := Node3D.new()
		pivot.add_child(spinner)
		var wm := MeshInstance3D.new()          # every wheel mesh is already centred on its own axle (left / right are separate meshes)
		wm.mesh = wmesh
		wm.layers = SELF_LAYER
		spinner.add_child(wm)
		wheel_pivots.append(pivot)
		wheel_spinners.append(spinner)

func _style_mesh(mesh: Mesh) -> void:
	# matt army paint and rubber; glass keeps a little sky reflection
	for i in range(mesh.get_surface_count()):
		var m := mesh.surface_get_material(i) as StandardMaterial3D
		if m == null:
			continue
		var n: String = m.resource_name
		if n == "kamaz_mixer_glass_diff1out":
			m.roughness = 0.04
			m.metallic = 0.25
			m.metallic_specular = 1.0
		elif n == "kamaz_wheel_diff1out":
			m.metallic = 0.0
			m.roughness = 1.0
			m.metallic_specular = 0.0
		elif n.begins_with("kamaz_"):
			m.roughness = 0.82
			m.metallic = 0.05
			m.metallic_specular = 0.35

func _read_input() -> Vector3:
	# returns (throttle, steer, handbrake)
	var throttle: float = 0.0
	var steer: float = 0.0
	var hb: float = 0.0
	if not driven:
		return Vector3(0.0, 0.0, 1.0)
	if ui != null:
		throttle = -ui.move_vec.y
		steer = ui.move_vec.x
		if ui.jump_held:
			hb = 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		throttle = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		throttle = -1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		steer = -1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		steer = 1.0
	if Input.is_key_pressed(KEY_SPACE):
		hb = 1.0
	return Vector3(clampf(throttle, -1.0, 1.0), clampf(steer, -1.0, 1.0), hb)


# ---------------------------------------------------------------------------------------------------------------
# tyre smoke / dust and skid marks
func _build_fx() -> void:
	var soft := GradientTexture2D.new()
	var gg := Gradient.new()
	gg.set_color(0, Color(1, 1, 1, 1))
	gg.set_color(1, Color(1, 1, 1, 0))
	gg.add_point(0.55, Color(1, 1, 1, 0.8))
	soft.gradient = gg
	soft.fill = GradientTexture2D.FILL_RADIAL
	soft.fill_from = Vector2(0.5, 0.5)
	soft.fill_to = Vector2(1.0, 0.5)
	soft.width = 64
	soft.height = 64
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 0.0))
	ramp.set_color(1, Color(1, 1, 1, 0.0))
	ramp.add_point(0.15, Color(1, 1, 1, 0.8))
	var grow := Curve.new()
	grow.add_point(Vector2(0.0, 0.5))
	grow.add_point(Vector2(1.0, 2.2))
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = soft
	mat.vertex_color_use_as_albedo = true
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mat.billboard_keep_scale = true
	mat.disable_receive_shadows = true
	var quad := QuadMesh.new()
	quad.size = Vector2(1.0, 1.0)
	quad.material = mat
	for i in range(6):
		var p := CPUParticles3D.new()
		p.top_level = true
		p.amount = 14
		p.lifetime = 1.4
		p.lifetime_randomness = 0.3
		p.local_coords = false
		p.emitting = false
		p.direction = Vector3(0.0, 1.0, 0.0)
		p.spread = 40.0
		p.gravity = Vector3(0.0, 0.5, 0.0)
		p.initial_velocity_min = 0.5
		p.initial_velocity_max = 1.6
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		p.emission_sphere_radius = 0.2
		p.scale_amount_min = 0.9
		p.scale_amount_max = 1.5
		p.scale_amount_curve = grow
		p.color_ramp = ramp
		p.color = Color(0.9, 0.9, 0.9, 0.5)
		p.mesh = quad
		p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(p)
		smoke.append(p)
		skid_last.append(Vector3(1.0e9, 1.0e9, 1.0e9))
	# mud clods thrown up by the tyres (brown lumps with gravity, one emitter per wheel)
	var clod_mat := StandardMaterial3D.new()
	clod_mat.albedo_color = Color(0.20, 0.13, 0.07)
	clod_mat.roughness = 1.0
	var clod := SphereMesh.new()
	clod.radius = 0.09
	clod.height = 0.18
	clod.radial_segments = 6
	clod.rings = 3
	clod.material = clod_mat
	for i in range(6):
		var m := CPUParticles3D.new()
		m.top_level = true
		m.amount = 12
		m.lifetime = 0.9
		m.lifetime_randomness = 0.4
		m.local_coords = false
		m.emitting = false
		m.direction = Vector3(0.0, 1.0, 0.7)
		m.spread = 38.0
		m.gravity = Vector3(0.0, -13.0, 0.0)
		m.initial_velocity_min = 3.0
		m.initial_velocity_max = 7.5
		m.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		m.emission_sphere_radius = 0.22
		m.scale_amount_min = 0.5
		m.scale_amount_max = 1.7
		m.mesh = clod
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(m)
		mud_fx.append(m)
	_skid_mat = StandardMaterial3D.new()
	_skid_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_skid_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_skid_mat.albedo_color = Color(0.03, 0.03, 0.03, 0.5)
	_skid_mat.disable_receive_shadows = true
	_skid_mat.render_priority = 1
	var pm := PlaneMesh.new()
	pm.size = Vector2(0.30, SKID_SPACING + 0.04)
	pm.material = _skid_mat
	skid_age.resize(SKID_POOL)
	for i in range(SKID_POOL):
		var mi := MeshInstance3D.new()
		mi.mesh = pm
		mi.top_level = true
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		skid_nodes.append(mi)
		skid_age[i] = 999.0

func _ground_normal(x: float, z: float) -> Vector3:
	var hx: float = _ground(x + 0.4, z) - _ground(x - 0.4, z)
	var hz: float = _ground(x, z + 0.4) - _ground(x, z - 0.4)
	return Vector3(-hx, 0.8, -hz).normalized()

func _place_skid(pos: Vector3, dir: Vector3) -> void:
	var n: Vector3 = _ground_normal(pos.x, pos.z)
	var zx: Vector3 = dir - n * dir.dot(n)
	if zx.length() < 0.01:
		return
	zx = zx.normalized()
	var xx: Vector3 = n.cross(zx).normalized()
	var mi: MeshInstance3D = skid_nodes[skid_next]
	mi.global_transform = Transform3D(Basis(xx, n, zx), pos)
	mi.transparency = 0.0
	mi.visible = true
	skid_age[skid_next] = 0.0
	skid_next = (skid_next + 1) % SKID_POOL

func _update_fx(delta: float, handbrake: bool, mu: float, air_k: float) -> void:
	if smoke.is_empty() or visual == null:
		return
	var v_abs: float = absf(speed)
	# fade old skid marks (about 14 s)
	for i in range(SKID_POOL):
		if skid_age[i] < 900.0:
			skid_age[i] += delta
			var t: float = skid_age[i] / 14.0
			var mi: MeshInstance3D = skid_nodes[i]
			if t >= 1.0:
				mi.visible = false
				skid_age[i] = 999.0
			else:
				mi.transparency = clampf(t * t, 0.0, 1.0)
	# how hard each axle is sliding (0..1)
	var move_k: float = clampf(maxf(v_abs, absf(lat_speed)) / 3.0, 0.0, 1.0)
	var sl_f: float = clampf((absf(alpha_f) - 0.09) / 0.10, 0.0, 1.0) * move_k * air_k
	var sl_r: float = clampf((absf(alpha_r) - 0.09) / 0.10, 0.0, 1.0) * move_k * air_k
	if handbrake and v_abs > 2.0:
		sl_r = maxf(sl_r, 0.9)
	sl_r = maxf(sl_r, slip_extra * 0.9)
	var loose: bool = mu < 0.6
	var vh := Vector3(velocity.x, 0.0, velocity.z)
	var dirn: Vector3 = vh.normalized() if vh.length() > 0.5 else forward_vector()
	for i in range(6):
		var s: float = sl_f if i < 2 else sl_r
		var p: CPUParticles3D = smoke[i]
		var emit: bool = s > 0.2 and wheel_contact[i] == 1
		p.emitting = emit
		var pv := wheel_pivots[i] as Node3D
		var wp: Vector3 = visual.to_global(pv.position + Vector3(0.0, 0.06 - TruckMeta.WHEEL_RADIUS, 0.0))
		p.global_position = wp
		if emit:
			if loose:
				p.color = Color(0.62, 0.52, 0.38, 0.25 + 0.4 * s)       # dust
			else:
				p.color = Color(0.9, 0.9, 0.9, 0.2 + 0.45 * s)          # tyre smoke
			if not loose and s > 0.45:
				var gp := Vector3(wp.x, _ground(wp.x, wp.z) + 0.07, wp.z)
				var last: Vector3 = skid_last[i]
				if gp.distance_to(last) > SKID_SPACING:
					_place_skid(gp, dirn)
					skid_last[i] = gp
				continue
		skid_last[i] = Vector3(1.0e9, 1.0e9, 1.0e9)
	# mud clods: thrown up and back by every wheel that drives through mud (more with speed / wheelspin)
	var throw: float = clampf((v_abs - 1.5) / 6.0 + slip_extra, 0.0, 1.0)
	var mud_on: bool = mud_k > 0.12 and throw > 0.05
	var back: Vector3 = -forward_vector() * (1.0 if speed >= 0.0 else -1.0)
	for i in range(mud_fx.size()):
		var m: CPUParticles3D = mud_fx[i]
		var on: bool = mud_on and wheel_contact[i] == 1
		m.emitting = on
		if on:
			var pv2 := wheel_pivots[i] as Node3D
			m.global_position = visual.to_global(pv2.position + Vector3(0.0, 0.1 - TruckMeta.WHEEL_RADIUS, 0.0))
			m.direction = Vector3(0.0, 1.0, 0.0) + back * 0.8
			m.initial_velocity_min = 2.0 + 2.5 * throw
			m.initial_velocity_max = 4.0 + 6.0 * throw
			m.amount = 12

# ---------------------------------------------------------------------------------------------------------------
# Pacejka-style lateral tyre force (magic formula without the curvature term): rises with slip angle, peaks around 8 deg,
# then falls to ~60-70% once the tyre slides.
func _tire(alpha: float, cap: float) -> float:
	return -cap * sin(1.6 * atan(tire_stiff * alpha))

# friction circle: grip left for cornering when the axle already uses part of its grip for driving / braking
func _circle(budget: float, fx: float) -> float:
	var r: float = clampf(fx / maxf(budget, 0.5), 0.0, 1.0)
	return budget * (0.30 + 0.70 * sqrt(1.0 - r * r))

func _physics_process(delta: float) -> void:
	var inp: Vector3 = _read_input()
	var parked: bool = not driven                  # nobody inside: parking brake holds the car
	var handbrake: bool = inp.z > 0.5 and driven
	var mu: float = clampf(grip, 0.15, 1.0)
	var wb: float = TruckMeta.WHEELBASE
	var a_cg: float = wb * cg_front_ratio          # CG -> front axle
	var b_cg: float = wb - a_cg                    # CG -> rear axle
	var grip_cap: float = mu * grip_accel          # what all six tyres together can deliver (m/s^2)
	var drive_cap: float = grip_cap * drive_grip_gain
	var v_abs: float = absf(speed)
	var air_k: float = clampf(ground_k * 1.34, 0.0, 1.0)     # airborne: the tyres push on nothing

	# ---- pedals (smoothed: the engine and brakes do not react instantly)
	var thr_target: float = 0.0 if parked else inp.x
	throttle_s = move_toward(throttle_s, thr_target, (3.2 if absf(thr_target) > absf(throttle_s) else 6.0) * delta)     # heavy pedals: the diesel spools up, air brakes build slowly

	# ---- load transfer: throttle loads the rear axle, braking the front
	var n_rear: float = clampf(cg_front_ratio + cg_height / wb * long_acc / G_REAL, 0.25, 0.75)
	var n_front: float = 1.0 - n_rear

	# ---- longitudinal: engine / brakes, limited by what the tyres hold
	var drive: float = 0.0
	var brake: float = 0.0
	var wheelspin: float = 0.0
	if parked:
		speed = move_toward(speed, 0.0, brake_decel * 1.3 * delta)
	else:
		if throttle_s > 0.05:
			if speed < -0.5:
				brake = minf(brake_decel, grip_cap * 1.05)
				speed += brake * delta
			else:
				var ratio: float = clampf(speed / max_speed, 0.0, 1.0)
				# diesel torque curve: huge pull at crawl speed (low range gearing), fading out as the speed rises
				var low_end: float = 1.0 + torque_boost * (1.0 - smoothstep(0.0, 9.0, speed))
				var a_eng: float = accel * throttle_s * low_end * (1.0 - ratio * ratio) + 0.4
				if handbrake:
					a_eng *= 0.5
				drive = minf(a_eng, drive_cap)
				speed += drive * delta
				wheelspin = clampf((a_eng - drive_cap) / maxf(accel, 1.0), 0.0, 1.0)
		elif throttle_s < -0.05:
			if speed > 0.5:
				brake = minf(brake_decel * (-throttle_s), grip_cap * 1.05)
				speed -= brake * delta
			else:
				drive = minf(accel * 0.6 * (-throttle_s), drive_cap)
				speed -= drive * delta
		else:
			speed = move_toward(speed, 0.0, coast_decel * delta)
		if handbrake:
			speed = move_toward(speed, 0.0, handbrake_decel * delta)
	slip_extra = lerpf(slip_extra, wheelspin, 1.0 - exp(-8.0 * delta))

	# ---- terrain slope: gravity along the hill, and cliffs block the way
	var fwd: Vector3 = forward_vector()
	var pos: Vector3 = global_position
	var gc: float = _ground(pos.x, pos.z)
	var f_pt: Vector3 = pos + fwd * 1.9
	var r_pt: Vector3 = pos - fwd * 1.9
	var slope_body: float = (_ground(f_pt.x, f_pt.z) - _ground(r_pt.x, r_pt.z)) / 3.8     # + = nose up
	if absf(speed) > 0.8 or absf(throttle_s) > 0.05:
		speed -= gravity * slope_gravity * slope_body / sqrt(1.0 + slope_body * slope_body) * delta
	var dirn: float = 1.0 if speed >= 0.0 else -1.0
	var lead: Vector3 = pos + fwd * dirn * 3.0
	if (_ground(lead.x, lead.z) - gc) / 3.0 > 1.2:                    # steeper than ~50 deg ahead
		speed = move_toward(speed, 0.0, 70.0 * delta)
	speed = clampf(speed, -reverse_speed, max_speed)
	v_abs = absf(speed)
	var v_tot: float = sqrt(speed * speed + lat_speed * lat_speed)

	# ---- body slip angle (angle between where the nose points and where the car really goes)
	var beta: float = atan2(lat_speed, maxf(v_abs, 1.0)) if speed > 0.0 else 0.0

	# ---- steering: lock shrinks with speed; a little past what the tyres hold = understeer slide.
	#      Countersteer assist: when the tail steps out the front wheels turn into the slide by themselves.
	var in_rate: float = 4.0 if absf(inp.y) > 0.01 else 6.0
	steer_in = move_toward(steer_in, inp.y, in_rate * delta)
	var grip_angle: float = atan(wb * grip_cap * steer_overshoot / maxf(v_abs * v_abs, 1.0))
	var steer_limit: float = clampf(grip_angle, max_steer_high, max_steer_low)
	var beta_ex: float = signf(beta) * maxf(absf(beta) - 0.10, 0.0)
	var assist: float = countersteer_assist * 1.4 * beta_ex * smoothstep(4.0, 9.0, v_tot) * (0.35 if handbrake else 1.0)
	var steer_target: float = clampf(-steer_in * steer_limit + assist, -max_steer_low, max_steer_low)   # positive angle = turn left
	var steer_rate: float = lerpf(1.7, 1.0, clampf(v_abs / max_speed, 0.0, 1.0))     # big steering wheel, heavy axle
	if absf(steer_target) < absf(steer_now):
		steer_rate *= 1.4                                   # self-centering is quicker than turning in
	steer_now = move_toward(steer_now, steer_target, steer_rate * delta)

	# ---- grip budget of each axle (load x friction), reduced by what the axle already spends on driving / braking
	var rear_mu: float = mu * rear_grip_bias
	if handbrake and v_abs > 1.0:
		rear_mu = mu * handbrake_rear_grip
	if parked:
		rear_mu = maxf(rear_mu, 1.0)                 # parked: tyres hold, no sliding
	var bud_f: float = mu * grip_accel * n_front
	var bud_r: float = rear_mu * grip_accel * n_rear
	# 6x6 centre differential (front axle vs the rear bogie): the base split is shifted towards the axle with more grip (load x friction), so a slipping
	# axle does not waste the torque. awd_adaptive = 0 gives a fixed split.
	var rs: float = lerpf(rear_drive_share, clampf(bud_r / maxf(bud_f + bud_r, 0.001), 0.4, 0.8), awd_adaptive)
	var fx_f: float = drive * (1.0 - rs) * drive_circle + brake * 0.65
	var fx_r: float = drive * rs * drive_circle + brake * 0.35
	var cap_f: float = _circle(bud_f, fx_f)
	var cap_r: float = _circle(bud_r, fx_r)

	# ---- cross-slope: gravity pulls the car down a camber, the tyres have to hold it
	var side_force: float = 0.0
	if v_tot > 2.0:
		var left_v: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))
		var cross: float = (_ground(pos.x + left_v.x, pos.z + left_v.z) - _ground(pos.x - left_v.x, pos.z - left_v.z)) * 0.5
		side_force = -G_REAL * 0.8 * cross

	# ---- handling: front / rear axle slip angles -> lateral tyre forces -> yaw + sideways slide
	var tan_st: float = tan(steer_now)
	var sub: int = 3
	var dt: float = delta / float(sub)
	var lat_force: float = 0.0
	var vref: float = maxf(v_abs, 2.0)
	for _i in range(sub):
		var s_f: float = (lat_speed + a_cg * yaw_rate) - speed * tan_st
		var s_r: float = lat_speed - b_cg * yaw_rate
		var k_rel: float = minf(1.0, vref * dt / tire_relax)       # tyre relaxation: slip angle builds up over ~1 m of rolling
		alpha_f += (atan2(s_f, vref) - alpha_f) * k_rel
		alpha_r += (atan2(s_r, vref) - alpha_r) * k_rel
		var ff: float = _tire(alpha_f, cap_f) * air_k
		var fr: float = _tire(alpha_r, cap_r) * air_k
		lat_force = ff + fr
		lat_speed += (lat_force - speed * yaw_rate + side_force) * dt
		yaw_rate += (a_cg * ff - b_cg * fr) / yaw_inertia * dt
		yaw_rate *= exp(-0.12 * dt)
		speed += yaw_rate * lat_speed * dt                                # frame rotation coupling

	# stability assist: past ~8 deg of body slip the nose is pulled back towards the direction of travel
	var sb: float = sin(atan2(lat_speed, maxf(speed, 0.5)))
	var dz: float = signf(sb) * maxf(absf(sb) - 0.14, 0.0)
	if not handbrake and not parked:
		yaw_rate += stability_assist * 6.0 * dz * (1.0 - 0.5 * maxf(throttle_s, 0.0)) * smoothstep(3.0, 8.0, v_tot) * delta
	# sliding scrubs speed off (tyre force has a component against the direction of travel)
	speed = move_toward(speed, 0.0, absf(lat_force) * absf(sin(beta)) * delta)
	# crawling speed: tyre slip angles are meaningless -> follow the simple bicycle geometry
	v_tot = sqrt(speed * speed + lat_speed * lat_speed)
	var kin: float = 1.0 - smoothstep(2.0, 6.5, v_tot)
	# the rear bogie scrubs its tyres sideways in a tight turn: a wider circle and a little speed lost
	var scrub: float = bogie_scrub * clampf(absf(steer_now) / max_steer_low, 0.0, 1.0)
	yaw_rate = lerpf(yaw_rate, speed / wb * tan_st * (1.0 - 0.3 * scrub), kin)
	if kin > 0.0 and absf(speed) > 0.5:
		speed = move_toward(speed, 0.0, scrub * 1.2 * kin * delta)
	lat_speed = lerpf(lat_speed, 0.0, kin * clampf(10.0 * delta, 0.0, 1.0))
	yaw_rate = clampf(yaw_rate, -1.7, 1.7)      # a loaded truck cannot spin like a pickup
	lat_speed = clampf(lat_speed, -18.0, 18.0)
	lat_acc_f = lerpf(lat_acc_f, lat_force, 1.0 - exp(-9.0 * delta))
	cam_slide = lerpf(cam_slide, clampf(beta, -0.6, 0.6), 1.0 - exp(-3.0 * delta))

	heading += yaw_rate * delta
	rotation.y = heading
	fwd = forward_vector()
	var left: Vector3 = Vector3(-cos(heading), 0.0, sin(heading))

	# ---- horizontal movement only (props / boundary collide, height is done by the suspension)
	var cs: float = 1.0 / sqrt(1.0 + slope_body * slope_body)           # slope speed -> ground-plane speed
	velocity = fwd * (speed * cs) + left * lat_speed
	velocity.y = 0.0
	global_position.y = ride_y
	move_and_slide()
	global_position.y = ride_y
	speed = velocity.dot(fwd) / maxf(cs, 0.3)                           # trees / rocks slow the car down
	lat_speed = velocity.dot(left)

	# ---- body motion from acceleration / cornering (tyre forces act at CG height -> dive, squat, roll)
	var la_raw: float = clampf((speed - prev_speed) / maxf(delta, 0.0001), -20.0, 20.0)
	long_acc = lerpf(long_acc, la_raw, 0.15)
	prev_speed = speed
	_suspension(delta, long_acc * cg_height * body_motion, -lat_acc_f * roll_arm * body_motion)

	_update_visual(delta, handbrake)
	if enable_fx:
		_update_fx(delta, handbrake, mu, air_k)

	# optional live reflection probe (off by default)
	if probe != null:
		probe_timer += delta
		if probe_timer > 1.5 and (absf(speed) > 1.0 or probe_timer > 4.0):
			probe_timer = 0.0
			probe.update_mode = ReflectionProbe.UPDATE_ALWAYS
			await get_tree().process_frame
			probe.update_mode = ReflectionProbe.UPDATE_ONCE

# 6 corner springs. Each corner's spring rate follows its share of the weight: the front axle carries (1 - cg_front_ratio) of the
# truck, the middle + rear axle (walking-beam bogie) share the rest. Damping is a damping ratio (bump soft / rebound firm), springs
# stiffen deep in the travel, anti-roll bars couple left / right and the bogie equaliser pushes both axles of a side towards the same load.
# Each wheel attach point is compared with the terrain under the wheel (3 taps = the tyre rolls over small bumps).
func _suspension(delta: float, pitch_torque: float, roll_torque: float) -> void:
	var yaw_basis := Basis(Vector3.UP, heading)
	var body_basis: Basis = yaw_basis * Basis(Vector3.RIGHT, pitch) * Basis(Vector3.BACK, roll)
	var pos: Vector3 = global_position
	var wb: float = TruckMeta.WHEELBASE
	var defl: float = maxf(susp_ext_max - susp_ext_rest, 0.05)           # static deflection (m)
	var omega: float = sqrt(gravity / defl)                              # natural frequency of every corner
	var cg_z: float = (TruckMeta.WHEELS[0] as Vector3).z + wb * cg_front_ratio
	var fw: Vector3 = Vector3(-sin(heading), 0.0, -cos(heading))
	var fs := PackedFloat32Array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var comp := PackedFloat32Array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var touching := PackedByteArray([0, 0, 0, 0, 0, 0])
	var contacts: int = 0
	for i in range(6):
		var w: Vector3 = TruckMeta.WHEELS[i]
		var corner: float = 0.5 * (1.0 - cg_front_ratio) if i < 2 else 0.25 * cg_front_ratio    # share of the weight on this corner (sums to 1)
		var k: float = corner * gravity / defl
		var a: Vector3 = pos + body_basis * Vector3(w.x, w.y + susp_ext_rest, w.z)
		var g0: float = _ground(a.x, a.z)
		var gf: float = _ground(a.x + fw.x * 0.34, a.z + fw.z * 0.34)
		var gb: float = _ground(a.x - fw.x * 0.34, a.z - fw.z * 0.34)
		var g: float = maxf(g0, 0.5 * (gf + gb))                  # tyre envelope: bridges holes, climbs bumps earlier (big tyres = bigger envelope)
		var raw: float = a.y - TruckMeta.WHEEL_RADIUS - g         # distance wheel-bottom to ground if fully compressed
		var e: float = clampf(raw, 0.0, susp_ext_max)
		var rate: float = clampf((e - ext[i]) / maxf(delta, 0.0001), -12.0, 12.0)
		var f: float = 0.0
		if raw < susp_ext_max:                                   # wheel touches the ground
			contacts += 1
			touching[i] = 1
			var c: float = 2.0 * (damping_rebound if rate > 0.0 else damping_bump) * corner * omega
			var cm: float = susp_ext_max - e                      # compression
			var cr: float = cm / susp_ext_max
			var cr0: float = defl / susp_ext_max
			var prog: float = 1.0 + spring_progressive * maxf(cr * cr - cr0 * cr0, 0.0)
			f = k * cm * prog - c * rate
			var stop: float = maxf(0.07 - e, 0.0) / 0.07          # progressive bump stop in the last 7 cm
			f += stop * stop * 45.0 * (corner * 4.0)
			if raw < 0.0:
				f += BUMP_K * (-raw) * (corner * 4.0) - 25.0 * minf(vy, 0.0) * (corner * 4.0)      # hard stop
			comp[i] = cm
		ext[i] = e
		fs[i] = f
	# walking-beam bogie: the middle and rear axle of a side pull towards the same load
	for side in range(2):
		var im: int = 2 + side
		var ir: int = 4 + side
		var avg: float = 0.5 * (fs[im] + fs[ir])
		if touching[im] == 1 and touching[ir] == 1:
			fs[im] = lerpf(fs[im], avg, bogie_equalise)
			fs[ir] = lerpf(fs[ir], avg, bogie_equalise)
	# anti-roll bars: couple left / right wheel of each axle (front, and the bogie as one rear axle)
	var d_front: float = (comp[0] - comp[1]) * arb_front
	var d_rear: float = ((comp[2] + comp[4]) - (comp[3] + comp[5])) * 0.5 * arb_rear
	fs[0] += d_front
	fs[1] -= d_front
	fs[2] += d_rear * 0.5
	fs[4] += d_rear * 0.5
	fs[3] -= d_rear * 0.5
	fs[5] -= d_rear * 0.5
	var fsum: float = 0.0
	var tp: float = pitch_torque
	var tr: float = roll_torque
	for i in range(6):
		var w2: Vector3 = TruckMeta.WHEELS[i]
		var fi: float = maxf(fs[i], 0.0) if touching[i] == 1 else 0.0
		fsum += fi
		tp += -(w2.z - cg_z) * fi                                # torques about the centre of gravity
		tr += w2.x * fi
	vy += (fsum - gravity) * delta
	pitch_vel += tp / INERTIA_PITCH * delta
	roll_vel += tr / INERTIA_ROLL * delta
	var damp: float = exp(-(0.6 if contacts == 0 else 1.0) * delta)
	pitch_vel *= damp
	roll_vel *= damp
	pitch += pitch_vel * delta
	roll += roll_vel * delta
	if absf(pitch) > 1.0:
		pitch = clampf(pitch, -1.0, 1.0)
		pitch_vel = 0.0
	if absf(roll) > 0.9:
		roll = clampf(roll, -0.9, 0.9)
		roll_vel = 0.0
	ride_y += vy * delta
	var gc: float = _ground(pos.x, pos.z)
	if ride_y < gc - 0.6:                                        # safety: never fall through the map
		ride_y = gc + 0.2
		vy = 0.0
	global_position.y = ride_y
	wheel_contact = touching
	ground_k = lerpf(ground_k, float(contacts) / 6.0, 1.0 - exp(-12.0 * delta))

func _update_visual(delta: float, handbrake: bool = false) -> void:
	if visual == null:
		return
	visual.basis = Basis(Vector3.RIGHT, pitch + water_pitch) * Basis(Vector3.BACK, roll + water_roll)
	wheel_spin = wrapf(wheel_spin - speed / TruckMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	# rear wheels: spin faster under wheelspin, stop when the handbrake locks them
	var rear_speed: float = speed + signf(speed if absf(speed) > 0.5 else 1.0) * slip_extra * 9.0
	if handbrake and absf(speed) > 1.0:
		rear_speed = speed * 0.1
	wheel_spin_rear = wrapf(wheel_spin_rear - rear_speed / TruckMeta.WHEEL_RADIUS * delta, -TAU, TAU)
	for i in range(wheel_spinners.size()):
		(wheel_spinners[i] as Node3D).rotation.x = wheel_spin if i < 2 else wheel_spin_rear
		var pv := wheel_pivots[i] as Node3D
		var w: Vector3 = TruckMeta.WHEELS[i]
		pv.position.y = w.y + susp_ext_rest - ext[i]           # wheels follow the ground, body rides on springs
		if i < 2:
			pv.rotation.y = steer_now
