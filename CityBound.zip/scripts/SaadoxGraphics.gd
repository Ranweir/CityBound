extends Node
# SAADox 2.0 - Part 3: post-processing, quality presets, quick time/weather controls.
# Plugs into Part 1 (TimeCycWeatherManager.gd) and Part 2 (wet_road.gdshader + PBRMaterialHelper.gd).
#
# Setup (main.gd, after tc exists and the UI is built):
#   var gfx = load("res://scripts/SaadoxGraphics.gd").new()
#   gfx.tc = tc
#   add_child(gfx)
#
# PC keys:  F1/F2/F3 = Low/Medium/High     5/6/7/8 = Morning/Noon/Sunset/Night
#           F5/F6/F7/F8 = Sunny/Cloudy/Rain/Post-rain (road wetness jumps instantly)
#           F4 = freeze / resume time

signal quality_changed(level: int)

enum Quality { LOW, MEDIUM, HIGH }

const TIME_NAMES: Array = ["Morning", "Noon", "Sunset", "Night"]
const TIME_HOURS: Array = [8.0, 12.0, 17.9, 23.0]
const SAVE_PATH: String = "user://saadox.cfg"

var tc: Node = null                         # TimeCycWeatherManager instance (set before add_child)

@export_group("Look")
@export var tonemap_white: float = 1.0
@export_range(0.5, 1.5, 0.01) var brightness: float = 1.04
@export_range(0.5, 1.5, 0.01) var contrast: float = 1.12     # punchy contrast
@export_range(0.5, 1.8, 0.01) var saturation: float = 1.18   # rich greens
@export_range(0.0, 0.1, 0.005) var warmth: float = 0.035     # warm highlights in the colour grade
@export_range(0.0, 0.05, 0.005) var green_lift: float = 0.015
@export var bloom_amount: float = 0.03

@export_group("Quality")
@export var persist_quality: bool = true
@export var smooth_speed: float = 5.0       # how fast continuous values glide to a new preset
@export var auto_fps: bool = false          # drop one preset when FPS stays low
@export var fps_floor: float = 40.0

@export_group("Test controls")
@export var show_panel: bool = true
@export var instant_wetness: bool = true    # weather buttons also jump road wetness (no waiting for puddles)

var quality: int = Quality.MEDIUM
var ssao_supported: bool = false

var _env: Environment = null
var _sun: DirectionalLight3D = null
var _probe: ReflectionProbe = null
var _panel: Control = null
var _cur: Dictionary = {}
var _tgt: Dictionary = {}
var _dirty: bool = true
var _probe_interval: float = 0.0
var _probe_timer: float = 0.0
var _fps_timer: float = 0.0
var _low_count: int = 0
var _cooldown: float = 6.0

# per-weather multiplier on saturation (rain / cloud look a bit flatter and cooler)
const WEATHER_SAT: Array = [1.0, 0.9, 0.86, 0.96]

# ------------------------------------------------------------------ lifecycle
func _ready() -> void:
	if tc == null:
		tc = get_parent().get_node_or_null("TimeCycWeatherManager")
	if tc == null:
		push_error("SaadoxGraphics: set 'tc' (TimeCycWeatherManager) before add_child().")
		return
	if tc.world_environment != null:
		_env = tc.world_environment.environment
	_sun = tc.sun_light
	_probe = get_tree().root.find_child("RoadReflectionProbe", true, false) as ReflectionProbe
	ssao_supported = RenderingServer.get_current_rendering_method() == "forward_plus"

	_setup_post_processing()
	_cur = {"shadow_dist": 55.0, "shadow_blur": 0.6, "glow": 0.0, "ssao": 1.0, "sat": saturation}
	_tgt = _cur.duplicate()

	var q: int = Quality.HIGH if not OS.has_feature("android") else Quality.MEDIUM
	if persist_quality:
		var cf := ConfigFile.new()
		if cf.load(SAVE_PATH) == OK:
			q = int(cf.get_value("gfx", "quality", q))
			auto_fps = bool(cf.get_value("gfx", "auto_fps", auto_fps))

	if show_panel:
		_build_panel()
	tc.weather_changed.connect(_on_weather_changed)
	set_quality(q, false)
	_on_weather_changed(int(tc.weather))
	_sync_panel()

func _process(delta: float) -> void:
	_glide(delta)
	_probe_tick(delta)
	_auto_quality(delta)

func _unhandled_key_input(event: InputEvent) -> void:
	var k: InputEventKey = event as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	match k.keycode:
		KEY_F1: set_quality(Quality.LOW)
		KEY_F2: set_quality(Quality.MEDIUM)
		KEY_F3: set_quality(Quality.HIGH)
		KEY_F4: set_time_frozen(tc.time_running)
		KEY_5: set_time_preset(0)
		KEY_6: set_time_preset(1)
		KEY_7: set_time_preset(2)
		KEY_8: set_time_preset(3)
		KEY_F5: set_weather_preset(0)
		KEY_F6: set_weather_preset(1)
		KEY_F7: set_weather_preset(2)
		KEY_F8: set_weather_preset(3)

# ------------------------------------------------------------------ 1. post-processing
func _setup_post_processing() -> void:
	if _env == null:
		return
	# ACES filmic. Exposure stays under Part 1's control (it animates tonemap_exposure).
	_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	_env.tonemap_white = tonemap_white

	# Colour grading: contrast / saturation + a 1D LUT (warm highlights, slightly cool shadows, green lift)
	_env.adjustment_enabled = true
	_env.adjustment_brightness = brightness
	_env.adjustment_contrast = contrast
	_env.adjustment_saturation = saturation
	_env.adjustment_color_correction = _make_grade_lut()

	# Subtle bloom
	_env.glow_enabled = true
	_env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	_env.glow_hdr_threshold = 0.95
	_env.glow_hdr_scale = 2.0
	_env.glow_bloom = bloom_amount
	_env.glow_strength = 0.9
	for i in range(0, 7):
		_env.set_glow_level(i, 1.0 if (i == 2 or i == 3 or i == 4) else 0.0)

	# SSAO values tuned for mobile-class GPUs (only used where the renderer supports SSAO)
	_env.ssao_radius = 1.1
	_env.ssao_intensity = 1.6
	_env.ssao_power = 1.6
	_env.ssao_detail = 0.4
	_env.ssao_light_affect = 0.15
	_env.ssao_ao_channel_affect = 0.4
	_env.ssao_enabled = false

func _make_grade_lut() -> GradientTexture1D:
	var offs := PackedFloat32Array()
	var cols := PackedColorArray()
	for i in range(9):
		var x: float = float(i) / 8.0
		var mid: float = sin(PI * x)
		var r: float = x + warmth * 0.45 * mid * x
		var g: float = x + green_lift * mid
		var b: float = x - warmth * x * x + 0.012 * mid * (1.0 - x)    # cool shadows, warm highlights
		offs.append(x)
		cols.append(Color(clampf(r, 0.0, 1.0), clampf(g, 0.0, 1.0), clampf(b, 0.0, 1.0), 1.0))
	var grad := Gradient.new()
	grad.offsets = offs
	grad.colors = cols
	var tex := GradientTexture1D.new()
	tex.gradient = grad
	tex.width = 256
	return tex

# ------------------------------------------------------------------ 2. quality presets
func _preset(level: int) -> Dictionary:
	# dist = shadow range in metres (shorter = sharper), split1..3 = cascade borders (fraction of dist)
	match level:
		Quality.LOW:
			return {"name": "Low", "bias": 0.12, "nbias": 2.5, "atlas": 2048,
				"mode": DirectionalLight3D.SHADOW_ORTHOGONAL, "dist": 24.0, "blur": 1.2,
				"split1": 0.25, "split2": 0.5, "split3": 0.75, "blend": false,
				"soft": RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW,
				"glow": 0.0, "msaa": Viewport.MSAA_DISABLED,
				"ssao": false, "ssao_q": RenderingServer.ENV_SSAO_QUALITY_VERY_LOW, "ssao_i": 0.0,
				"probe": false, "probe_lod": 8.0, "probe_refresh": 0.0}
		Quality.HIGH:
			return {"name": "High", "bias": 0.06, "nbias": 1.5, "atlas": 4096,
				"mode": DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS, "dist": 60.0, "blur": 1.3,
				"split1": 0.08, "split2": 0.22, "split3": 0.5, "blend": true,
				"soft": RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM,
				"glow": 0.55, "msaa": Viewport.MSAA_2X,
				"ssao": true, "ssao_q": RenderingServer.ENV_SSAO_QUALITY_MEDIUM, "ssao_i": 1.0,
				"probe": true, "probe_lod": 1.0, "probe_refresh": 5.0}
		_:
			return {"name": "Medium", "bias": 0.08, "nbias": 2.0, "atlas": 4096,
				"mode": DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS, "dist": 36.0, "blur": 1.2,
				"split1": 0.3, "split2": 0.5, "split3": 0.75, "blend": false,
				"soft": RenderingServer.SHADOW_QUALITY_SOFT_LOW,
				"glow": 0.35, "msaa": Viewport.MSAA_DISABLED,
				"ssao": true, "ssao_q": RenderingServer.ENV_SSAO_QUALITY_LOW, "ssao_i": 0.7,
				"probe": true, "probe_lod": 4.0, "probe_refresh": 0.0}

func set_quality(level: int, save: bool = true) -> void:
	quality = clampi(level, Quality.LOW, Quality.HIGH)
	var p: Dictionary = _preset(quality)

	# discrete settings: applied at once
	RenderingServer.directional_shadow_atlas_set_size(int(p["atlas"]), true)
	RenderingServer.directional_soft_shadow_filter_set_quality(int(p["soft"]))
	get_viewport().msaa_3d = int(p["msaa"])
	if _sun != null:
		_sun.shadow_enabled = true
		_sun.directional_shadow_mode = int(p["mode"])
		_sun.directional_shadow_split_1 = float(p["split1"])
		_sun.directional_shadow_split_2 = float(p["split2"])
		_sun.directional_shadow_split_3 = float(p["split3"])
		_sun.directional_shadow_blend_splits = bool(p["blend"])
		_sun.shadow_bias = float(p["bias"])
		_sun.shadow_normal_bias = float(p["nbias"])
	if _env != null:
		_env.ssao_enabled = ssao_supported and bool(p["ssao"])
		if ssao_supported:
			RenderingServer.environment_set_ssao_quality(int(p["ssao_q"]), true, 0.5, 2, 50.0, 300.0)
	_apply_probe(p)

	# continuous settings: glide there (no visible pop when switching)
	_tgt["shadow_dist"] = float(p["dist"])
	_tgt["shadow_blur"] = float(p["blur"])
	_tgt["glow"] = float(p["glow"])
	_tgt["ssao"] = float(p["ssao_i"])
	_dirty = true

	if _panel != null:
		_panel.set_selected("quality", quality)
	quality_changed.emit(quality)
	if save and persist_quality:
		_save()

func get_quality_name() -> String:
	return str(_preset(quality)["name"])

func set_auto_fps(on: bool) -> void:
	auto_fps = on
	_low_count = 0
	_cooldown = 6.0
	if _panel != null:
		_panel.set_auto_fps(on)
	if persist_quality:
		_save()

func _glide(delta: float) -> void:
	if not _dirty:
		return
	var k: float = 1.0 - exp(-smooth_speed * delta)
	var moving: bool = false
	for key in _tgt.keys():
		var c: float = float(_cur[key])
		var t: float = float(_tgt[key])
		c = lerpf(c, t, k)
		if absf(c - t) < 0.002:
			c = t
		else:
			moving = true
		_cur[key] = c
	_dirty = moving
	if _sun != null:
		_sun.directional_shadow_max_distance = float(_cur["shadow_dist"])
		_sun.shadow_blur = float(_cur["shadow_blur"])
	if _env != null:
		var g: float = float(_cur["glow"])
		_env.glow_enabled = g > 0.01
		_env.glow_intensity = g
		_env.ssao_intensity = 1.6 * float(_cur["ssao"])
		_env.adjustment_saturation = float(_cur["sat"])

func _apply_probe(p: Dictionary) -> void:
	if _probe == null:
		return
	_probe.visible = bool(p["probe"])
	_probe.enable_shadows = false
	_probe.mesh_lod_threshold = float(p["probe_lod"])
	_probe_interval = float(p["probe_refresh"])
	_probe_timer = 0.0
	if _probe.visible:
		refresh_probe()

func _probe_tick(delta: float) -> void:
	if _probe_interval <= 0.0 or _probe == null or not _probe.visible:
		return
	_probe_timer += delta
	if _probe_timer >= _probe_interval:
		_probe_timer = 0.0
		refresh_probe()

## Re-capture the reflection probe once (cheap: one cube render).
func refresh_probe() -> void:
	if _probe == null or not _probe.is_inside_tree() or _probe.has_meta("refreshing"):
		return
	_probe.set_meta("refreshing", true)      # same guard key as PBRMaterialHelper
	_probe.update_mode = ReflectionProbe.UPDATE_ALWAYS
	await get_tree().create_timer(0.5).timeout
	if is_instance_valid(_probe):
		_probe.update_mode = ReflectionProbe.UPDATE_ONCE
		_probe.remove_meta("refreshing")

func _auto_quality(delta: float) -> void:
	if not auto_fps:
		return
	_cooldown -= delta
	_fps_timer += delta
	if _fps_timer < 1.0:
		return
	_fps_timer = 0.0
	if _cooldown > 0.0:
		return
	if Engine.get_frames_per_second() < fps_floor:
		_low_count += 1
	else:
		_low_count = 0
	if _low_count >= 4 and quality > Quality.LOW:
		_low_count = 0
		_cooldown = 10.0
		set_quality(quality - 1, false)

# ------------------------------------------------------------------ 3. quick time / weather controls
func set_time_preset(idx: int) -> void:
	idx = clampi(idx, 0, TIME_HOURS.size() - 1)
	tc.set_time(float(TIME_HOURS[idx]))
	if _panel != null:
		_panel.set_selected("time", idx)
	if _probe != null and _probe.visible:
		refresh_probe()

## 0 Sunny, 1 Cloudy, 2 Rain, 3 Post-rain. Turns auto weather off so the choice sticks.
func set_weather_preset(w: int, instant: bool = true) -> void:
	w = clampi(w, 0, 3)
	tc.auto_weather = false
	tc.set_weather(w, true)
	if instant and instant_wetness and w != 1:
		tc.road_wetness = 1.0 if w >= 2 else 0.0    # dry vs. wet roads right away
		tc._publish_wetness(true)
	_sync_panel()
	if _probe != null and _probe.visible:
		refresh_probe()

func set_time_frozen(frozen: bool) -> void:
	tc.time_running = not frozen
	_sync_panel()

func _on_weather_changed(w: int) -> void:
	_tgt["sat"] = saturation * float(WEATHER_SAT[clampi(w, 0, 3)])
	_dirty = true
	if _panel != null:
		_panel.set_selected("weather", w)

# ------------------------------------------------------------------ panel glue
func _build_panel() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	_panel = load("res://scripts/saadox_panel.gd").new()
	layer.add_child(_panel)
	_panel.action.connect(_on_panel_action)

func _on_panel_action(group: String, idx: int) -> void:
	match group:
		"time":
			set_time_preset(idx)
		"weather":
			set_weather_preset(idx)
		"quality":
			if idx == 3:
				set_auto_fps(not auto_fps)
			else:
				set_quality(idx)
		"hdr":
			if idx == 1:
				tc.auto_weather = not tc.auto_weather
			elif idx == 2:
				tc.time_running = not tc.time_running
			_sync_panel()

func _sync_panel() -> void:
	if _panel == null:
		return
	_panel.set_toggle(1, bool(tc.auto_weather))
	_panel.set_toggle(2, not bool(tc.time_running))
	_panel.set_selected("weather", int(tc.weather))
	_panel.set_selected("quality", quality)
	_panel.set_auto_fps(auto_fps)

func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("gfx", "quality", quality)
	cf.set_value("gfx", "auto_fps", auto_fps)
	cf.save(SAVE_PATH)
