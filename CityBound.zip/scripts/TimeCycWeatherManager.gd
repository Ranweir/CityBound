extends Node
## TimeCycWeatherManager.gd  (Godot 4.3, GDScript)
## GTA SA "timecyc.dat" style 24h time cycle + dynamic weather + global road wetness.
##
## Scene nodes used (all optional - missing ones are created automatically):
##   WorldEnvironment  -> Environment (background = Sky) -> Sky -> ProceduralSkyMaterial
##   DirectionalLight3D (shadow enabled)  = sun by day, moon by night
##   Camera3D (any current camera) = rain follows it

signal weather_changed(new_weather: int)
signal road_wetness_changed(value: float)
signal hour_changed(hour: int)

enum Weather { CLEAR_SUNNY, OVERCAST, RAINY, POST_RAIN }

@export_group("Scene References")
@export var world_environment: WorldEnvironment
@export var sun_light: DirectionalLight3D
@export var create_missing_nodes: bool = true

@export_group("Time")
@export_range(0.0, 24.0, 0.01) var time_of_day: float = 9.0
@export var day_length_seconds: float = 720.0   ## real seconds for one full 24h day
@export var time_running: bool = true
@export var sunrise_hour: float = 6.0
@export var sunset_hour: float = 19.0
@export_range(0.0, 1.2, 0.01) var sun_tilt: float = 0.45   ## radians, moves the sun arc off the east-west line

@export_group("Weather")
@export var start_weather: Weather = Weather.CLEAR_SUNNY
@export var auto_weather: bool = true
@export var weather_blend_speed: float = 0.35   ## higher = faster weather transitions
@export var enable_rain_particles: bool = true

@export_group("Road Wetness (time constants, seconds)")
@export var wet_time_rain: float = 12.0         ## rain: wetness rises toward 1.0
@export var wet_time_post_rain: float = 45.0    ## post-rain: keeps rising toward 1.0 (puddles)
@export var dry_time_clear: float = 20.0        ## clear sunny: dries toward 0.0
@export var dry_time_overcast: float = 150.0    ## overcast: dries very slowly

@export_group("Look")
@export var fog_density_scale: float = 1.0       ## multiplies the time-of-day fog density

@export_group("Performance")
@export var update_interval: float = 0.2        ## sky/light/fog update rate (seconds)

## Global road wetness 0.0 (dry) .. 1.0 (soaked).
## Also published as global shader uniform "road_wetness" (use: global uniform float road_wetness;)
var road_wetness: float = 0.0
var weather: int = Weather.CLEAR_SUNNY

# Per-weather modifiers. gray = overcast desaturation, sun/amb = light multipliers,
# fog = fog density multiplier, expo = exposure multiplier, shadow = shadow opacity,
# disc = visibility of the sun disc, rain = rain intensity.
const WEATHER_PARAMS: Dictionary = {
	0: {"gray": 0.0,  "sun": 1.0,  "amb": 1.0,  "fog": 1.0, "expo": 1.0,  "shadow": 1.0, "disc": 1.0,  "rain": 0.0},
	1: {"gray": 0.65, "sun": 0.45, "amb": 0.92, "fog": 1.8, "expo": 0.97, "shadow": 0.35, "disc": 0.12, "rain": 0.0},
	2: {"gray": 0.88, "sun": 0.2,  "amb": 0.75, "fog": 3.2, "expo": 0.92, "shadow": 0.0, "disc": 0.0,  "rain": 1.0},
	3: {"gray": 0.35, "sun": 0.75, "amb": 0.95, "fog": 1.6, "expo": 1.0,  "shadow": 0.7, "disc": 0.55, "rain": 0.0},
}
const WEATHER_NAMES: Array = ["Clear", "Overcast", "Rain", "Post-rain"]

var _env: Environment = null
var _sky_mat: ProceduralSkyMaterial = null
var _keys: Array = []
var _wx: Dictionary = {}
var _accum: float = 0.0
var _weather_timer: float = 60.0
var _last_hour: int = -1
var _last_wet_sent: float = -1.0
var _rain: GPUParticles3D = null

# ------------------------------------------------------------------ lifecycle
func _ready() -> void:
	_build_keys()
	_ensure_nodes()
	_ensure_global_param()
	weather = start_weather
	_wx = (WEATHER_PARAMS[weather] as Dictionary).duplicate()
	if enable_rain_particles:
		_create_rain()
	_reset_weather_timer()
	_apply_visuals()
	_publish_wetness(true)

func _process(delta: float) -> void:
	if time_running and day_length_seconds > 0.0:
		time_of_day = fposmod(time_of_day + delta * 24.0 / day_length_seconds, 24.0)
	var h: int = int(time_of_day)
	if h != _last_hour:
		_last_hour = h
		hour_changed.emit(h)

	_update_weather_blend(delta)
	_update_auto_weather(delta)
	_update_wetness(delta)
	_update_rain()

	_accum += delta
	if _accum >= update_interval:
		_accum = 0.0
		_apply_visuals()

# ------------------------------------------------------------------ public API
func set_weather(new_weather: int, instant: bool = false) -> void:
	new_weather = clampi(new_weather, 0, 3)
	var changed: bool = new_weather != weather
	weather = new_weather
	if instant:
		_wx = (WEATHER_PARAMS[weather] as Dictionary).duplicate()
		_apply_visuals()
	_reset_weather_timer()
	if changed:
		weather_changed.emit(weather)

func set_time(hour: float) -> void:
	time_of_day = fposmod(hour, 24.0)
	_apply_visuals()

func get_time_string() -> String:
	var h: int = int(time_of_day)
	var m: int = int((time_of_day - float(h)) * 60.0)
	return "%02d:%02d" % [h, m]

func get_weather_name() -> String:
	return WEATHER_NAMES[weather]

# ------------------------------------------------------------------ setup
func _ensure_nodes() -> void:
	if world_environment == null and create_missing_nodes:
		world_environment = WorldEnvironment.new()
		world_environment.name = "WorldEnvironment"
		add_child(world_environment)
	if world_environment != null:
		_env = world_environment.environment
		if _env == null:
			_env = Environment.new()
			world_environment.environment = _env
		_env.background_mode = Environment.BG_SKY
		if _env.sky == null:
			_env.sky = Sky.new()
		if not (_env.sky.sky_material is ProceduralSkyMaterial):
			_env.sky.sky_material = ProceduralSkyMaterial.new()
		_sky_mat = _env.sky.sky_material as ProceduralSkyMaterial
		_env.sky.radiance_size = Sky.RADIANCE_SIZE_32          # cheap sky updates on mobile
		_env.sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
		_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		_env.fog_enabled = true
		_env.fog_sky_affect = 0.15
	if sun_light == null and create_missing_nodes:
		sun_light = DirectionalLight3D.new()
		sun_light.name = "Sun"
		sun_light.directional_shadow_max_distance = 60.0
		add_child(sun_light)
	if sun_light != null:
		sun_light.shadow_enabled = true

func _ensure_global_param() -> void:
	var found: bool = false
	for n in RenderingServer.global_shader_parameter_get_list():
		if str(n) == "road_wetness":
			found = true
	if not found:
		RenderingServer.global_shader_parameter_add("road_wetness", RenderingServer.GLOBAL_VAR_TYPE_FLOAT, 0.0)

func _create_rain() -> void:
	_rain = GPUParticles3D.new()
	_rain.name = "Rain"
	_rain.amount = 1400
	_rain.lifetime = 0.9
	_rain.local_coords = false
	_rain.visibility_aabb = AABB(Vector3(-20.0, -16.0, -20.0), Vector3(40.0, 18.0, 40.0))
	_rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(18.0, 0.2, 18.0)
	pm.direction = Vector3(0.0, -1.0, 0.0)
	pm.spread = 2.0
	pm.initial_velocity_min = 16.0
	pm.initial_velocity_max = 20.0
	pm.gravity = Vector3(0.0, -4.0, 0.0)
	_rain.process_material = pm
	var quad := QuadMesh.new()
	quad.size = Vector2(0.025, 0.7)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.8, 0.86, 1.0, 0.35)
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	quad.material = mat
	_rain.draw_pass_1 = quad
	_rain.emitting = false
	add_child(_rain)

# ------------------------------------------------------------------ time-of-day keyframes
func _key(h: float, top: String, hor: String, gh: String, gb: String, sun: String, sun_e: float, amb: String, amb_e: float, fog: String, fog_d: float, expo: float) -> Dictionary:
	return {"h": h, "top": Color(top), "hor": Color(hor), "gh": Color(gh), "gb": Color(gb),
		"sun": Color(sun), "sun_e": sun_e, "amb": Color(amb), "amb_e": amb_e,
		"fog": Color(fog), "fog_d": fog_d, "expo": expo}

func _build_keys() -> void:
	_keys = [
		#      hour   sky top    horizon   gnd hor   gnd bot   sun/moon  energy  ambient   energy  fog       density  exposure
		_key(0.0,  "#050a1c", "#0d1838", "#0d1838", "#05070d", "#8aa4ff", 0.22, "#1b2650", 0.50, "#0b1430", 0.010, 1.10),  # deep night
		_key(4.5,  "#080f26", "#1a2650", "#1a2650", "#06080f", "#8aa4ff", 0.20, "#202c5a", 0.50, "#141f44", 0.011, 1.10),  # pre-dawn
		_key(5.5,  "#2c3c78", "#ff9a68", "#cc8264", "#2a2630", "#ff9b5a", 0.35, "#5c5278", 0.60, "#d89c88", 0.013, 1.05),  # dawn
		_key(6.5,  "#4a82d4", "#ffd0a0", "#dcc2a2", "#5a6a55", "#ffbc85", 0.85, "#8fa4c8", 0.80, "#ecd8c6", 0.010, 1.00),  # sunrise
		_key(8.0,  "#3a84e0", "#bddcff", "#bdd2e2", "#5d7050", "#ffeccc", 1.05, "#a5bfe0", 0.95, "#cfe0f0", 0.007, 1.00),  # morning
		_key(12.0, "#2a78ea", "#cfe8ff", "#c6dbec", "#62785a", "#fffaf0", 1.30, "#b6cff0", 1.05, "#d2e4f6", 0.0055, 1.05), # bright noon
		_key(16.0, "#3680e0", "#c6defc", "#c0d4e6", "#5d7050", "#fff0d6", 1.15, "#aac4e6", 1.00, "#cfe0f0", 0.0065, 1.00), # afternoon
		_key(17.75, "#3b5cb4", "#ff9a50", "#dc8c58", "#4a4038", "#ffa860", 0.95, "#8e7e9c", 0.80, "#f0aa78", 0.010, 1.00), # golden sunset
		_key(18.75, "#2a3a84", "#ee6a62", "#a85a68", "#2a2230", "#ff7a5a", 0.50, "#5e5a86", 0.65, "#b86a78", 0.011, 1.00), # sunset glow
		_key(19.5, "#121c4a", "#5a4a8a", "#3a3868", "#12121e", "#8aa4ff", 0.20, "#2a3664", 0.55, "#2a3060", 0.011, 1.05),  # dusk
		_key(21.0, "#050a1c", "#0d1838", "#0d1838", "#05070d", "#8aa4ff", 0.22, "#1b2650", 0.50, "#0b1430", 0.010, 1.10),  # night
	]

func _sample_keys(h: float) -> Dictionary:
	var n: int = _keys.size()
	var next_i: int = -1
	for i in range(n):
		if float((_keys[i] as Dictionary)["h"]) > h:
			next_i = i
			break
	var a: Dictionary
	var b: Dictionary
	var h_a: float
	var h_b: float
	if next_i == -1:                      # after the last key: blend toward the first key of next day
		a = _keys[n - 1]
		b = _keys[0]
		h_a = float(a["h"])
		h_b = float(b["h"]) + 24.0
	else:
		a = _keys[maxi(next_i - 1, 0)]
		b = _keys[next_i]
		h_a = float(a["h"])
		h_b = float(b["h"])
	var t: float = clampf((h - h_a) / maxf(h_b - h_a, 0.001), 0.0, 1.0)
	t = smoothstep(0.0, 1.0, t)
	var out: Dictionary = {}
	for k in a.keys():
		if k == "h":
			continue
		var va = a[k]
		var vb = b[k]
		if va is Color:
			out[k] = (va as Color).lerp(vb as Color, t)
		else:
			out[k] = lerpf(float(va), float(vb), t)
	return out

# ------------------------------------------------------------------ applying everything
func _lum(c: Color) -> float:
	return c.r * 0.3 + c.g * 0.59 + c.b * 0.11

func _apply_visuals() -> void:
	if _env == null or _sky_mat == null:
		return
	var s: Dictionary = _sample_keys(time_of_day)
	var gray: float = float(_wx["gray"])
	var lh: float = _lum(s["hor"])

	# --- sky (overcast pulls colours toward a flat grey)
	var top: Color = (s["top"] as Color).lerp(Color(lh * 0.75, lh * 0.78, lh * 0.84), gray)
	var hor: Color = (s["hor"] as Color).lerp(Color(lh * 0.95, lh * 0.97, lh * 1.0), gray)
	var gh: Color = (s["gh"] as Color).lerp(Color(lh * 0.9, lh * 0.92, lh * 0.95), gray)
	_sky_mat.sky_top_color = top
	_sky_mat.sky_horizon_color = hor
	_sky_mat.ground_horizon_color = gh
	_sky_mat.ground_bottom_color = s["gb"]

	# --- sun (day) / moon (night) position
	var pos: Vector3 = _light_position(time_of_day)
	var fade: float = smoothstep(0.0, 0.05, pos.y)     # fade out as it touches the horizon
	if sun_light != null:
		sun_light.basis = Basis.looking_at(-pos, Vector3.UP)
		sun_light.light_color = (s["sun"] as Color).lerp(Color(0.85, 0.9, 1.0), gray * 0.6)
		sun_light.light_energy = float(s["sun_e"]) * float(_wx["sun"]) * fade
		sun_light.shadow_opacity = clampf(float(_wx["shadow"]), 0.0, 1.0)

	# --- sun disc in the sky: bigger near the horizon, hidden by clouds/rain
	var low: float = 1.0 - clampf(pos.y * 3.0, 0.0, 1.0)
	_sky_mat.sun_angle_max = maxf(0.1, 30.0 * float(_wx["disc"]) * (1.0 + low * 0.6))
	_sky_mat.sun_curve = 0.15

	# --- ambient, fog, exposure
	var amb: Color = s["amb"]
	_env.ambient_light_color = amb.lerp(Color(_lum(amb), _lum(amb), _lum(amb)), gray * 0.5)
	_env.ambient_light_energy = float(s["amb_e"]) * float(_wx["amb"])
	var fog: Color = s["fog"]
	_env.fog_light_color = fog.lerp(Color(lh * 0.9, lh * 0.93, lh * 0.98), gray)
	_env.fog_density = float(s["fog_d"]) * float(_wx["fog"]) * fog_density_scale
	_env.tonemap_exposure = float(s["expo"]) * float(_wx["expo"])

## Position of the light source in the sky. Sun arcs east->west between sunrise and sunset,
## the moon takes the same arc during the night.
func _light_position(h: float) -> Vector3:
	var a: float
	if h >= sunrise_hour and h < sunset_hour:
		a = (h - sunrise_hour) / (sunset_hour - sunrise_hour) * PI
	else:
		var night_len: float = 24.0 - (sunset_hour - sunrise_hour)
		var hh: float = h - sunset_hour
		if hh < 0.0:
			hh += 24.0
		a = hh / night_len * PI
	return Vector3(cos(a), sin(a) * cos(sun_tilt), sin(a) * sin(sun_tilt)).normalized()

# ------------------------------------------------------------------ weather logic
func _update_weather_blend(delta: float) -> void:
	var tgt: Dictionary = WEATHER_PARAMS[weather]
	var k: float = 1.0 - exp(-weather_blend_speed * delta)
	for key in tgt.keys():
		_wx[key] = lerpf(float(_wx[key]), float(tgt[key]), k)

func _reset_weather_timer() -> void:
	match weather:
		Weather.CLEAR_SUNNY:
			_weather_timer = randf_range(90.0, 180.0)
		Weather.OVERCAST:
			_weather_timer = randf_range(40.0, 80.0)
		Weather.RAINY:
			_weather_timer = randf_range(60.0, 120.0)
		_:
			_weather_timer = randf_range(40.0, 70.0)

func _update_auto_weather(delta: float) -> void:
	if not auto_weather:
		return
	_weather_timer -= delta
	if _weather_timer > 0.0:
		return
	var nxt: int = Weather.CLEAR_SUNNY
	match weather:
		Weather.CLEAR_SUNNY:
			nxt = Weather.OVERCAST
		Weather.OVERCAST:
			nxt = Weather.RAINY if randf() < 0.65 else Weather.CLEAR_SUNNY
		Weather.RAINY:
			nxt = Weather.POST_RAIN
		_:
			nxt = Weather.CLEAR_SUNNY if randf() < 0.8 else Weather.OVERCAST
	set_weather(nxt)

# ------------------------------------------------------------------ road wetness
func _update_wetness(delta: float) -> void:
	var target: float = 0.0
	var tau: float = dry_time_clear
	match weather:
		Weather.CLEAR_SUNNY:
			target = 0.0
			tau = dry_time_clear
		Weather.OVERCAST:
			target = 0.0
			tau = dry_time_overcast
		Weather.RAINY:
			target = 1.0
			tau = wet_time_rain
		Weather.POST_RAIN:
			target = 1.0
			tau = wet_time_post_rain
	road_wetness = lerpf(road_wetness, target, 1.0 - exp(-delta / maxf(tau, 0.01)))
	if absf(road_wetness - target) < 0.002:
		road_wetness = target
	_publish_wetness(false)

func _publish_wetness(force: bool) -> void:
	if force or absf(road_wetness - _last_wet_sent) > 0.004 or (road_wetness == 0.0 and _last_wet_sent != 0.0) or (road_wetness == 1.0 and _last_wet_sent != 1.0):
		_last_wet_sent = road_wetness
		RenderingServer.global_shader_parameter_set("road_wetness", road_wetness)
		road_wetness_changed.emit(road_wetness)

# ------------------------------------------------------------------ rain
func _update_rain() -> void:
	if _rain == null:
		return
	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam != null:
		_rain.global_position = cam.global_position + Vector3(0.0, 12.0, 0.0)
	var r: float = float(_wx["rain"])
	_rain.emitting = r > 0.03
	_rain.amount_ratio = clampf(r, 0.02, 1.0)
