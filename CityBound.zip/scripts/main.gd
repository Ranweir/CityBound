extends Node3D
# City Bound test map: hilly offroad terrain (see scripts/world_builder.gd) + time cycle / weather.

const Meta = preload("res://scripts/map_meta.gd")

var world = null
var player = null   # player.gd instance
var ui = null       # touch_ui.gd instance
var tc = null       # TimeCycWeatherManager instance
var cam_pivot: Node3D = null
var spring: SpringArm3D = null
var cam: Camera3D = null
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var hud: Label = null
var hud_timer: float = 0.0

func _ready() -> void:
	_make_timecyc()
	world = load("res://scripts/world_builder.gd").new()
	world.name = "World"
	add_child(world)
	_make_player()
	_make_camera()
	_make_ui()

func _make_timecyc() -> void:
	tc = load("res://scripts/TimeCycWeatherManager.gd").new()
	tc.name = "TimeCycWeatherManager"
	tc.time_of_day = 9.0
	tc.day_length_seconds = 720.0
	tc.fog_density_scale = 0.45
	add_child(tc)   # creates WorldEnvironment + sun + rain by itself
	if tc.sun_light != null:
		tc.sun_light.directional_shadow_max_distance = 90.0

func _on_debug(id: int) -> void:
	if id >= 0 and id <= 3:
		tc.set_weather(id)
	elif id == 4:
		tc.set_time(tc.time_of_day + 3.0)

func _make_player() -> void:
	player = load("res://scripts/player.gd").new()
	player.position = Meta.SPAWN + Vector3(0.0, 0.6, 0.0)
	add_child(player)
	cam_yaw = Meta.SPAWN_YAW
	player.model.rotation.y = cam_yaw + PI

func _make_camera() -> void:
	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam_pivot.global_position = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	spring = SpringArm3D.new()
	spring.spring_length = 4.2
	spring.margin = 0.25
	spring.collision_mask = 1
	cam_pivot.add_child(spring)
	spring.add_excluded_object(player.get_rid())
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 600.0
	spring.add_child(cam)
	cam.make_current()
	player.cam_pivot = cam_pivot

func _make_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = load("res://scripts/touch_ui.gd").new()
	layer.add_child(ui)
	player.ui = ui
	ui.debug_pressed.connect(_on_debug)
	hud = Label.new()
	hud.position = Vector2(20.0, 14.0)
	hud.add_theme_font_size_override("font_size", 22)
	hud.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hud.add_theme_constant_override("outline_size", 6)
	layer.add_child(hud)

func _process(delta: float) -> void:
	if ui == null or player == null:
		return
	var ld: Vector2 = ui.look_delta
	ui.look_delta = Vector2.ZERO
	if Input.is_key_pressed(KEY_1):
		tc.set_weather(0)
	elif Input.is_key_pressed(KEY_2):
		tc.set_weather(1)
	elif Input.is_key_pressed(KEY_3):
		tc.set_weather(2)
	elif Input.is_key_pressed(KEY_4):
		tc.set_weather(3)
	if Input.is_key_pressed(KEY_Q):
		ld.x -= 400.0 * delta
	if Input.is_key_pressed(KEY_E):
		ld.x += 400.0 * delta
	cam_yaw -= ld.x * 0.0045
	cam_pitch = clampf(cam_pitch - ld.y * 0.0045, -1.15, 0.45)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	var target: Vector3 = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.global_position = cam_pivot.global_position.lerp(target, 1.0 - exp(-16.0 * delta))
	hud_timer += delta
	if hud_timer > 0.4:
		hud_timer = 0.0
		hud.text = "FPS: %d   %s   %s   Wet: %d%%" % [Engine.get_frames_per_second(), tc.get_time_string(), tc.get_weather_name(), int(tc.road_wetness * 100.0)]
