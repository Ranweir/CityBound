extends Node3D
# Small open-world test map, built entirely from code (no extra assets needed).

const HALF: float = 80.0

var rng := RandomNumberGenerator.new()
var player = null   # player.gd instance
var ui = null
var cam_pivot: Node3D = null
var spring: SpringArm3D = null
var cam: Camera3D = null
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var hud: Label = null
var tc = null   # TimeCycWeatherManager instance
var hud_timer: float = 0.0

var m_grass: StandardMaterial3D
var m_asphalt: StandardMaterial3D
var m_concrete: StandardMaterial3D
var m_line: StandardMaterial3D
var m_trunk: StandardMaterial3D
var m_leaf: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_roof: StandardMaterial3D
var m_facades: Array = []

func _ready() -> void:
	rng.seed = 20241
	_make_timecyc()
	_make_materials()
	_build_world()
	_make_player()
	_make_camera()
	_make_ui()
	tc.road_wetness_changed.connect(_on_wetness)

# ---------------------------------------------------------------- environment
func _make_timecyc() -> void:
	tc = load("res://scripts/TimeCycWeatherManager.gd").new()
	tc.name = "TimeCycWeatherManager"
	tc.time_of_day = 9.0
	tc.day_length_seconds = 720.0
	add_child(tc)   # creates WorldEnvironment + sun + rain by itself

func _on_wetness(v: float) -> void:
	m_asphalt.albedo_color = Color(1, 1, 1).lerp(Color(0.55, 0.57, 0.62), v)
	m_asphalt.roughness = lerpf(0.95, 0.22, v)
	m_asphalt.metallic_specular = lerpf(0.5, 0.9, v)
	m_concrete.albedo_color = Color(1, 1, 1).lerp(Color(0.72, 0.74, 0.78), v)
	m_concrete.roughness = lerpf(0.95, 0.5, v)

func _on_debug(id: int) -> void:
	if id >= 0 and id <= 3:
		tc.set_weather(id)
	elif id == 4:
		tc.set_time(tc.time_of_day + 3.0)

# ---------------------------------------------------------------- textures / materials
func _noise_tex(base: Color, amount: float, size: int = 128) -> ImageTexture:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in range(size):
		for x in range(size):
			var n: float = rng.randf_range(-amount, amount)
			img.set_pixel(x, y, Color(clampf(base.r + n, 0.0, 1.0), clampf(base.g + n, 0.0, 1.0), clampf(base.b + n, 0.0, 1.0), 1.0))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

func _grass_tex() -> ImageTexture:
	var size: int = 128
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in range(size):
		for x in range(size):
			var n: float = rng.randf_range(-0.05, 0.05)
			var blot: float = sin(float(x) * 0.18) * sin(float(y) * 0.13) * 0.05
			img.set_pixel(x, y, Color(clampf(0.28 + n + blot, 0.0, 1.0), clampf(0.55 + n + blot, 0.0, 1.0), clampf(0.2 + n * 0.5, 0.0, 1.0), 1.0))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

func _facade_tex(wall: Color, glass: Color) -> ImageTexture:
	var size: int = 128
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in range(size):
		for x in range(size):
			var n: float = rng.randf_range(-0.03, 0.03)
			img.set_pixel(x, y, Color(clampf(wall.r + n, 0.0, 1.0), clampf(wall.g + n, 0.0, 1.0), clampf(wall.b + n, 0.0, 1.0), 1.0))
	for wy in range(2):
		for wx in range(2):
			var x0: int = wx * 64 + 14
			var y0: int = wy * 64 + 14
			for y in range(y0, y0 + 36):
				for x in range(x0, x0 + 36):
					var k: float = 1.0 - float(y - y0) / 36.0 * 0.35
					img.set_pixel(x, y, Color(glass.r * k, glass.g * k, glass.b * k, 1.0))
			for x in range(x0 - 2, x0 + 38):
				img.set_pixel(x, y0 - 2, wall.darkened(0.3))
				img.set_pixel(x, y0 + 36, wall.lightened(0.15))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

func _tri_mat(tex: Texture2D, tile_m: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	var s: float = 1.0 / tile_m
	m.uv1_scale = Vector3(s, s, s)
	m.roughness = 0.95
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	return m

func _flat_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	return m

func _make_materials() -> void:
	m_grass = _tri_mat(_grass_tex(), 4.0)
	m_asphalt = _tri_mat(_noise_tex(Color(0.2, 0.2, 0.22), 0.04), 6.0)
	m_concrete = _tri_mat(_noise_tex(Color(0.66, 0.65, 0.62), 0.05), 4.0)
	m_line = _flat_mat(Color(0.95, 0.95, 0.9))
	m_trunk = _flat_mat(Color(0.38, 0.26, 0.15))
	m_leaf = _flat_mat(Color(0.2, 0.5, 0.18))
	m_dark = _flat_mat(Color(0.08, 0.08, 0.09))
	m_roof = _flat_mat(Color(0.25, 0.25, 0.27))
	var glass := Color(0.35, 0.5, 0.65)
	var walls: Array = [Color(0.85, 0.78, 0.62), Color(0.7, 0.38, 0.3), Color(0.62, 0.64, 0.66), Color(0.8, 0.8, 0.74), Color(0.45, 0.55, 0.68)]
	for w in walls:
		m_facades.append(_tri_mat(_facade_tex(w, glass), 8.0))

# ---------------------------------------------------------------- helpers
func _box(pos: Vector3, size: Vector3, mat: Material, collide: bool = true, rot_deg: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation_degrees = rot_deg
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		body.add_child(cs)
	add_child(body)
	return body

func _cyl(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 10
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi

# ---------------------------------------------------------------- world
func _build_world() -> void:
	# ground
	_box(Vector3(0.0, -0.5, 0.0), Vector3(HALF * 2.0 + 10.0, 1.0, HALF * 2.0 + 10.0), m_grass)

	# roads (visual only) + sidewalks
	_box(Vector3(0.0, 0.015, 0.0), Vector3(HALF * 2.0, 0.03, 10.0), m_asphalt, false)
	_box(Vector3(0.0, 0.016, 0.0), Vector3(10.0, 0.03, HALF * 2.0), m_asphalt, false)
	var seg_len: float = HALF - 5.0
	var seg_c: float = 5.0 + seg_len * 0.5
	for sgn in [-1.0, 1.0]:
		for sgn2 in [-1.0, 1.0]:
			_box(Vector3(sgn * seg_c, 0.075, sgn2 * 6.5), Vector3(seg_len, 0.15, 3.0), m_concrete)
			_box(Vector3(sgn2 * 6.5, 0.075, sgn * seg_c), Vector3(3.0, 0.15, seg_len), m_concrete)

	# lane markings
	var i: float = -HALF + 4.0
	while i < HALF - 2.0:
		if absf(i) > 8.0:
			_box(Vector3(i, 0.04, 0.0), Vector3(3.0, 0.02, 0.25), m_line, false)
			_box(Vector3(0.0, 0.041, i), Vector3(0.25, 0.02, 3.0), m_line, false)
		i += 6.0
	# crosswalks
	for k in range(-4, 5):
		var o: float = float(k) * 1.1
		for sgn in [-1.0, 1.0]:
			_box(Vector3(o, 0.042, sgn * 7.0), Vector3(0.6, 0.02, 2.4), m_line, false)
			_box(Vector3(sgn * 7.0, 0.042, o), Vector3(2.4, 0.02, 0.6), m_line, false)

	# map border walls
	var wall_mat: Material = m_concrete
	_box(Vector3(0.0, 2.0, HALF + 1.0), Vector3(HALF * 2.0 + 6.0, 4.0, 2.0), wall_mat)
	_box(Vector3(0.0, 2.0, -HALF - 1.0), Vector3(HALF * 2.0 + 6.0, 4.0, 2.0), wall_mat)
	_box(Vector3(HALF + 1.0, 2.0, 0.0), Vector3(2.0, 4.0, HALF * 2.0 + 6.0), wall_mat)
	_box(Vector3(-HALF - 1.0, 2.0, 0.0), Vector3(2.0, 4.0, HALF * 2.0 + 6.0), wall_mat)

	# city blocks: three quadrants with buildings, the (+x, +z) quadrant is a park
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			if sx > 0.0 and sz > 0.0:
				continue
			for bi in range(3):
				for bj in range(2):
					var w: float = rng.randf_range(13.0, 17.0)
					var d: float = rng.randf_range(15.0, 19.0)
					var h: float = rng.randf_range(10.0, 28.0)
					var cx: float = sx * (24.0 + 22.0 * float(bi))
					var cz: float = sz * (24.0 + 26.0 * float(bj))
					var fm: Material = m_facades[rng.randi() % m_facades.size()]
					_box(Vector3(cx, h * 0.5, cz), Vector3(w, h, d), fm)
					_box(Vector3(cx, h + 0.15, cz), Vector3(w + 0.6, 0.3, d + 0.6), m_roof, false)
					_box(Vector3(cx + 2.0, h + 0.9, cz - 1.0), Vector3(2.5, 1.2, 2.0), m_roof, false)

	# park (+x, +z): trees, ramp, crates
	for t in range(16):
		var tx: float = rng.randf_range(14.0, 74.0)
		var tz: float = rng.randf_range(14.0, 74.0)
		_tree(Vector3(tx, 0.0, tz))
	_box(Vector3(34.0, 1.07, 30.0), Vector3(10.0, 0.3, 6.0), m_concrete, true, Vector3(0.0, 0.0, 14.0))
	_box(Vector3(46.0, 0.5, 30.0), Vector3(1.0, 1.0, 1.0), m_concrete)
	_box(Vector3(48.0, 1.0, 30.0), Vector3(2.0, 2.0, 2.0), m_concrete)
	_box(Vector3(51.0, 1.5, 30.0), Vector3(3.0, 3.0, 3.0), m_concrete)
	_box(Vector3(57.0, 0.25, 40.0), Vector3(3.0, 0.5, 1.0), m_concrete)
	_box(Vector3(59.0, 0.5, 40.0), Vector3(3.0, 1.0, 1.0), m_concrete)
	_box(Vector3(61.0, 0.75, 40.0), Vector3(3.0, 1.5, 1.0), m_concrete)

	# street trees + lamps along the sidewalks
	var p: float = -HALF + 12.0
	while p < HALF - 8.0:
		if absf(p) > 12.0:
			_tree(Vector3(p, 0.0, 9.0))
			_tree(Vector3(p, 0.0, -9.0))
			_lamp(Vector3(p + 6.0, 0.0, 7.2))
			_lamp(Vector3(p + 6.0, 0.0, -7.2))
		p += 12.0

	# parked cars on the roads
	_car(Vector3(-22.0, 0.0, 2.6), 0.0, Color(0.8, 0.12, 0.12))
	_car(Vector3(-40.0, 0.0, -2.6), 180.0, Color(0.15, 0.3, 0.75))
	_car(Vector3(18.0, 0.0, -2.6), 180.0, Color(0.9, 0.8, 0.15))
	_car(Vector3(36.0, 0.0, 2.6), 0.0, Color(0.85, 0.85, 0.88))
	_car(Vector3(2.6, 0.0, -24.0), 90.0, Color(0.1, 0.55, 0.3))
	_car(Vector3(-2.6, 0.0, 30.0), 270.0, Color(0.2, 0.2, 0.22))

func _tree(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_cyl(root, Vector3(0.0, 1.4, 0.0), 0.2, 2.8, m_trunk)
	var crown := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.7
	sm.height = 3.2
	sm.radial_segments = 8
	sm.rings = 4
	crown.mesh = sm
	crown.material_override = m_leaf
	crown.position = Vector3(0.0, 3.8, 0.0)
	root.add_child(crown)
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var cap := CylinderShape3D.new()
	cap.radius = 0.25
	cap.height = 2.8
	cs.shape = cap
	cs.position = Vector3(0.0, 1.4, 0.0)
	body.add_child(cs)
	root.add_child(body)

func _lamp(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_cyl(root, Vector3(0.0, 3.0, 0.0), 0.07, 6.0, m_dark)
	var bulb := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.6, 0.15, 0.3)
	bulb.mesh = bm
	var em := StandardMaterial3D.new()
	em.albedo_color = Color(1.0, 0.95, 0.7)
	em.emission_enabled = true
	em.emission = Color(1.0, 0.9, 0.6)
	em.emission_energy_multiplier = 1.5
	bulb.material_override = em
	bulb.position = Vector3(0.0, 6.0, 0.0)
	root.add_child(bulb)

func _car(pos: Vector3, yaw_deg: float, color: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation_degrees = Vector3(0.0, yaw_deg, 0.0)
	add_child(body)
	var paint := _flat_mat(color)
	paint.roughness = 0.35
	paint.metallic = 0.3
	var hull := MeshInstance3D.new()
	var hm := BoxMesh.new()
	hm.size = Vector3(4.3, 0.75, 1.85)
	hull.mesh = hm
	hull.material_override = paint
	hull.position = Vector3(0.0, 0.7, 0.0)
	body.add_child(hull)
	var cabin := MeshInstance3D.new()
	var cm := BoxMesh.new()
	cm.size = Vector3(2.3, 0.65, 1.65)
	cabin.mesh = cm
	cabin.material_override = _flat_mat(Color(0.15, 0.2, 0.28))
	cabin.position = Vector3(-0.2, 1.4, 0.0)
	body.add_child(cabin)
	for wx in [-1.4, 1.4]:
		for wz in [-0.95, 0.95]:
			_cyl(body, Vector3(wx, 0.35, wz), 0.35, 0.25, m_dark, Vector3(90.0, 0.0, 0.0))
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(4.3, 1.5, 1.85)
	cs.shape = bs
	cs.position = Vector3(0.0, 0.85, 0.0)
	body.add_child(cs)

# ---------------------------------------------------------------- player / camera / ui
func _make_player() -> void:
	player = load("res://scripts/player.gd").new()
	player.position = Vector3(0.0, 0.2, 0.0)
	add_child(player)

func _make_camera() -> void:
	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam_pivot.global_position = player.global_position + Vector3(0.0, 1.55, 0.0)
	spring = SpringArm3D.new()
	spring.spring_length = 4.2
	spring.margin = 0.25
	spring.collision_mask = 1
	cam_pivot.add_child(spring)
	spring.add_excluded_object(player.get_rid())
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 300.0
	spring.add_child(cam)
	cam.make_current()
	player.cam_pivot = cam_pivot

func _make_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = load("res://scripts/touch_ui.gd").new()
	layer.add_child(ui)
	player.ui = ui
	ui.debug_pressed.connect(_on_debug)
	ui.jiggle_changed.connect(_on_jiggle)
	hud = Label.new()
	hud.position = Vector2(20.0, 14.0)
	hud.add_theme_font_size_override("font_size", 22)
	hud.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hud.add_theme_constant_override("outline_size", 6)
	layer.add_child(hud)

func _on_jiggle(on: bool, amount: float) -> void:
	if player != null:
		player.set_jiggle(on, amount)

func _process(delta: float) -> void:
	if ui == null or player == null:
		return
	var ld: Vector2 = ui.look_delta
	ui.look_delta = Vector2.ZERO
	# keyboard/mouse-less fallback: Q/E rotate camera on PC
	if Input.is_key_pressed(KEY_1):
		tc.set_weather(0)
	elif Input.is_key_pressed(KEY_2):
		tc.set_weather(1)
	elif Input.is_key_pressed(KEY_3):
		tc.set_weather(2)
	elif Input.is_key_pressed(KEY_4):
		tc.set_weather(3)
	if Input.is_key_pressed(KEY_Q):
		ld.x -= 400.0 * delta
	if Input.is_key_pressed(KEY_E):
		ld.x += 400.0 * delta
	cam_yaw -= ld.x * 0.0045
	cam_pitch = clampf(cam_pitch - ld.y * 0.0045, -1.15, 0.45)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	var target: Vector3 = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.global_position = cam_pivot.global_position.lerp(target, 1.0 - exp(-16.0 * delta))
	hud_timer += delta
	if hud_timer > 0.4:
		hud_timer = 0.0
		hud.text = "FPS: %d   %s   %s   Wet: %d%%" % [Engine.get_frames_per_second(), tc.get_time_string(), tc.get_weather_name(), int(tc.road_wetness * 100.0)]
