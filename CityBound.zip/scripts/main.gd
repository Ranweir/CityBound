extends Node3D
# City Bound test map: hilly offroad terrain (see scripts/world_builder.gd) + time cycle / weather.

const MapBuilder = preload("res://scripts/map_builder.gd")

var world = null
var player = null   # player.gd instance
var car = null      # car.gd instance
var bike = null     # bike.gd instance
var vehicle = null  # the vehicle (car or bike) the player is driving right now, null = on foot
var look_idle: float = 10.0
var ui = null       # touch_ui.gd instance
var tc = null       # TimeCycWeatherManager instance
var cam_pivot: Node3D = null
var spring: SpringArm3D = null
var cam: Camera3D = null
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var cam_base_len: float = 4.2      # default camera distance of the current mode (on foot / car / bike)
var cam_zoom: float = 1.0          # user zoom multiplier (+ / - buttons on screen)
var hud: Label = null
var hud_timer: float = 0.0
var base_accel: Dictionary = {}   # vehicle -> accel / max_speed on dry ground (mud scales them)
var base_max: Dictionary = {}
var sink: Dictionary = {}
var surf: Dictionary = {}

func _ready() -> void:
	_make_timecyc()
	world = MapBuilder.new()
	world.name = "World"
	world.weather_manager = tc      # wetness / rain drive puddles + mud physics
	add_child(world)                # builds the map in its _ready()
	_make_player()
	_make_car()
	_make_bike()
	_make_camera()
	_make_ui()
	car.ui = ui
	bike.ui = ui

func _make_timecyc() -> void:
	tc = load("res://scripts/TimeCycWeatherManager.gd").new()
	tc.name = "TimeCycWeatherManager"
	tc.time_of_day = 16.6
	tc.day_length_seconds = 1080.0
	tc.fog_density_scale = 0.45
	add_child(tc)   # creates WorldEnvironment + sun + rain by itself
	if tc.sun_light != null:
		tc.sun_light.directional_shadow_max_distance = 90.0

func _on_debug(id: int) -> void:
	if id >= 0 and id <= 3:
		tc.set_weather(id)
	elif id == 4:
		tc.set_time(tc.time_of_day + 3.0)

func _make_player() -> void:
	player = load("res://scripts/player.gd").new()
	player.position = world.spawn_position
	add_child(player)
	cam_yaw = world.spawn_yaw
	player.model.rotation.y = cam_yaw + PI

func _make_car() -> void:
	car = load("res://scripts/car.gd").new()
	var fwd := Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw))
	car.position = world.get_safe_position(world.spawn_position + fwd * 5.5, 0.4)   # above ground AND water
	car.rotation.y = world.spawn_yaw
	car.world = world
	add_child(car)
	base_accel[car] = car.accel
	base_max[car] = car.max_speed
	sink[car] = 0.0

func _make_bike() -> void:
	# NRG-500 parked next to the F-150, a few metres to the right of the spawn point
	bike = load("res://scripts/bike.gd").new()
	var fwd := Vector3(-sin(world.spawn_yaw), 0.0, -cos(world.spawn_yaw))
	var right: Vector3 = fwd.cross(Vector3.UP)
	bike.position = world.get_safe_position(world.spawn_position + fwd * 3.0 + right * 3.2, 0.4)
	bike.rotation.y = world.spawn_yaw
	bike.world = world
	add_child(bike)
	base_accel[bike] = bike.accel
	base_max[bike] = bike.max_speed
	sink[bike] = 0.0

# the closest vehicle the player is allowed to get into (null = none in range)
func _nearest_vehicle():
	var best = null
	var best_d: float = 1.0e9
	for v in [car, bike]:
		if v == null:
			continue
		var d: float = player.global_position.distance_to(v.global_position)
		if d < v.enter_range and d < best_d:
			best = v
			best_d = d
	return best

func _on_action() -> void:
	if vehicle != null:
		_exit_vehicle()
	else:
		var v = _nearest_vehicle()
		if v != null:
			_enter_vehicle(v)

func _enter_vehicle(v) -> void:
	vehicle = v
	v.driven = true
	if v == bike:
		player.start_riding(bike)        # rider sits on the bike
	else:
		player.set_active(false)
	spring.add_excluded_object(v.get_rid())
	cam_base_len = 8.5 if v == car else 5.8
	cam_pitch = -0.22
	ui.jump_pressed = false

func _exit_vehicle() -> void:
	var v = vehicle
	vehicle = null
	v.driven = false
	var left: Vector3 = -v.forward_vector().cross(Vector3.UP)
	if v == bike:
		player.stop_riding()
	else:
		player.set_active(true)
	player.global_position = v.global_position + left * (1.5 if v == bike else 2.7) + Vector3(0.0, 0.8, 0.0)
	player.model.rotation.y = v.heading + PI
	spring.remove_excluded_object(v.get_rid())
	cam_base_len = 4.2
	cam_pitch = -0.28
	ui.jump_pressed = false

func _make_camera() -> void:
	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam_pivot.global_position = player.global_position + Vector3(0.0, 1.55, 0.0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	spring = SpringArm3D.new()
	spring.spring_length = 4.2
	spring.margin = 0.25
	spring.collision_mask = 1
	cam_pivot.add_child(spring)
	spring.add_excluded_object(player.get_rid())
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 600.0
	spring.add_child(cam)
	cam.make_current()
	player.cam_pivot = cam_pivot

func _make_vignette() -> void:
	# soft dark corners (cheap: one transparent gradient, no screen reads)
	var vl := CanvasLayer.new()
	vl.layer = 0
	add_child(vl)
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	gr.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0.6)])
	var gt := GradientTexture2D.new()
	gt.gradient = gr
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 64
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	vl.add_child(tr)

func _make_ui() -> void:
	_make_vignette()
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = load("res://scripts/touch_ui.gd").new()
	layer.add_child(ui)
	player.ui = ui
	ui.debug_pressed.connect(_on_debug)
	ui.action_pressed.connect(_on_action)
	hud = Label.new()
	hud.position = Vector2(20.0, 14.0)
	hud.add_theme_font_size_override("font_size", 22)
	hud.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hud.add_theme_constant_override("outline_size", 6)
	layer.add_child(hud)

func _physics_process(delta: float) -> void:
	if car == null or bike == null or world == null:
		return
	for v in [car, bike]:
		var s: Dictionary = world.get_surface_state_at(v.global_position)
		var trac: float = s["traction_multiplier"]
		v.accel = base_accel[v] * lerpf(0.5, 1.0, trac)
		v.max_speed = base_max[v] * lerpf(0.55, 1.0, trac)
		v.speed *= maxf(0.0, 1.0 - float(s["drag_factor"]) * delta)       # mud / water drag
		sink[v] = lerpf(float(sink[v]), float(s["sink_amount"]), 1.0 - exp(-5.0 * delta))
		if v.visual != null:
			v.visual.position.y = -float(sink[v])                           # body sinks into mud
		if v == vehicle or (vehicle == null and v == car):
			surf = s

func _process(delta: float) -> void:
	if ui == null or player == null:
		return
	var ld: Vector2 = ui.look_delta
	ui.look_delta = Vector2.ZERO
	if Input.is_key_pressed(KEY_1):
		tc.set_weather(0)
	elif Input.is_key_pressed(KEY_2):
		tc.set_weather(1)
	elif Input.is_key_pressed(KEY_3):
		tc.set_weather(2)
	elif Input.is_key_pressed(KEY_4):
		tc.set_weather(3)
	if Input.is_key_pressed(KEY_Q):
		ld.x -= 400.0 * delta
	if Input.is_key_pressed(KEY_E):
		ld.x += 400.0 * delta
	if ld.length() > 0.5:
		look_idle = 0.0
	else:
		look_idle += delta
	if ui.zoom_dir != 0.0:
		cam_zoom = clampf(cam_zoom * exp(ui.zoom_dir * 0.9 * delta), 0.35, 2.5)     # hold + / - to move the camera
	spring.spring_length = cam_base_len * cam_zoom
	cam_yaw -= ld.x * 0.0045
	cam_pitch = clampf(cam_pitch - ld.y * 0.0045, -1.15, 0.45)
	var target: Vector3 = player.global_position + Vector3(0.0, 1.55, 0.0)
	if vehicle != null:
		target = vehicle.global_position + Vector3(0.0, 2.2 if vehicle == car else 1.7, 0.0)
		if absf(vehicle.speed) > 1.5 and look_idle > 1.2:
			var want: float = vehicle.heading if vehicle.speed > 0.0 else vehicle.heading + PI
			cam_yaw = lerp_angle(cam_yaw, want, 1.0 - exp(-1.8 * delta))
		ui.action_label = "EXIT"
	else:
		ui.action_label = "ENTER" if _nearest_vehicle() != null else ""
	ui.vehicle_mode = vehicle != null           # driving: arrow buttons instead of the joystick
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0.0)
	cam_pivot.global_position = cam_pivot.global_position.lerp(target, 1.0 - exp(-16.0 * delta))
	hud_timer += delta
	if hud_timer > 0.4:
		hud_timer = 0.0
		hud.text = "[v8 look]  FPS: %d   %s   %s   Wet: %d%%" % [Engine.get_frames_per_second(), tc.get_time_string(), tc.get_weather_name(), int(tc.road_wetness * 100.0)]
		if vehicle != null:
			hud.text += "   %d km/h" % int(vehicle.speed_kmh())
			if not surf.is_empty():
				hud.text += "   mud %d cm  water %d cm" % [int(float(surf["mud_depth"]) * 100.0), int(float(surf["water_depth"]) * 100.0)]
